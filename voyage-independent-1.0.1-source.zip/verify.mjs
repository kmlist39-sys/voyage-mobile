import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {analysisDirectory,packageDirectory} from './paths.mjs';
const suites=fs.readdirSync(packageDirectory).filter(n=>n.endsWith('.test.mjs')).sort();
const run=spawnSync(process.execPath,['--test','--test-reporter=tap',...suites],{cwd:packageDirectory,encoding:'utf8',maxBuffer:16*1024*1024});
fs.writeFileSync(path.join(analysisDirectory,'tests.tap'),run.stdout+(run.stderr||''));
const number=key=>Number(run.stdout.match(new RegExp('^# '+key+' (\\d+)','m'))?.[1]||0);
const result={executedAt:new Date().toISOString(),node:process.version,suites:suites.length,tests:number('tests'),passed:number('pass'),failed:number('fail'),skipped:number('skipped'),exitCode:run.status,
scope:['Extracted Korean data and 24,737 script instructions','Original-function differential fixtures for dice, new-game placement, navigation, supplies, combat, economics and script arithmetic','Independent navigation, trading, supply/unloading, shipyard, recruitment, appointments, equipment, contracts, gambling, battle, spoils and save/restore','Six original story endings with test-supplied travel, fame and battle prerequisites','Seven royal quest families, debt collection and actual A* sea travel','All 130 port arrivals and 889 building paths'],
limits:['Tests of story endings supply progression prerequisites; these are not six complete human playthroughs.','NPC global routing and offscreen combat use independent pathfinding and scheduling; they are not instruction-identical to the DOS runtime.','Original-function comparisons validate recorded inputs only, not every possible game state.','All 101 town layouts were reviewed in an overview gallery; exhaustive dialogue and form bounds were checked in a browser harness. This does not cover every device.','Android emulator and responsive UI observations are recorded separately in manual-verification.json.'],
command:'node --test --test-reporter=tap '+suites.join(' ')};
fs.writeFileSync(path.join(analysisDirectory,'verification.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));if(run.status!==0){console.error(run.stdout,run.stderr);process.exit(1)}

