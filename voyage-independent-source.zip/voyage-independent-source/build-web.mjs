import fs from 'node:fs';import path from 'node:path';
const root=import.meta.dirname,dest=path.join(root,'web');
fs.cpSync(root+'/core',dest+'/core',{recursive:true});fs.cpSync(root+'/app',dest,{recursive:true});fs.copyFileSync(root+'/supply-model.mjs',dest+'/supply-model.mjs');
for(const name of ['messages','initial-state','ships','goods','discoveries','items','ports','sailors','markets','town-maps','wind-current'])fs.copyFileSync(root+'/analysis/data/'+name+'.json',dest+'/data/'+name+'.json');
for(let i=0;i<7;i++)fs.copyFileSync(root+'/analysis/stories/SNR'+i+'.json',dest+'/data/SNR'+i+'.json');
for(let i=0;i<3;i++)fs.copyFileSync(root+'/analysis/data/world-'+i+'.bin',dest+'/data/world-'+i+'.bin');
console.log('Updated web/. Art and sanitized presentation maps are included in web/.');
