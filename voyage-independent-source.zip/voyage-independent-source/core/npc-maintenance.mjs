// Ship choices and monthly allowances decoded in game-details/fleets.md.
const M=[[[8,7,5],[9,8,7],[9,9,8]],[[8,7,7],[9,8,7],[9,9,9]],[[8,5,5],[9,8,8],[11,9,9]],[[12,5,5],[9,8,5],[9,8,8]],[[3,4,4],[3,3,4],[9,9,3]],[[8,5,1],[9,8,5],[9,9,9]],[[8,8,12],[10,9,8],[10,9,9]]];
const C=[[[19,19,18],[20,21,19],[20,20,20]],[[19,19,18],[20,21,19],[20,20,20]],[[19,18,18],[20,19,19],[20,20,20]],[[13,9,8],[10,10,9],[10,10,10]],[[21,21,18],[20,20,21],[20,20,20]],[[9,9,8],[10,10,9],[10,10,10]],[[19,19,18],[20,20,19],[20,20,20]]];
const V=[[[9,9,8],[10,10,9],[10,10,10]],[[9,9,8],[10,10,9],[10,10,10]],[[9,9,8],[11,11,9],[11,11,11]],[[9,9,8],[10,10,9],[10,10,10]],[[3,3,8],[9,3,8],[10,10,9]],[[9,9,8],[10,10,9],[10,10,10]],[[8,12,12],[10,10,8],[10,10,10]]];
const floor=Math.floor;
function active(h,f,i){return (h.get(8,f,43+9*i+8)&48)===16;}
function count(h,f){let n=0;for(let i=0;i<10;i++)if(active(h,f,i))n++;return n;}
function strength(h,f){let n=0;for(let i=0;i<10;i++)if(active(h,f,i))n+=h.get(8,f,43+9*i+2);h.set(8,f,40,Math.min(255,floor((n+4)/5)));return n;}
function ship(h,data,f,i,type,gun){const m=data.ships[type],a=43+i*9;h.set(8,f,a,h.get(10,40+type,21,2),2);[m.durability,m.durability,m.tacking,m.power,h.get(10,40+type,20),40+type,16|gun].forEach((n,j)=>h.set(8,f,a+2+j,n));}
export function monthlyNpcMaintenance(h,data,random){
 const own=h.fleetId(),events=[];
 for(let nation=0;nation<7;nation++){
  const profit=h.get(0,nation,0,2),tier=profit>=1000?2:profit>=500?1:0;
  for(const [ids,table,allowance] of [[[1,2,3,4],M,floor(profit/50)+5],[[5,6],C,floor(profit/75)+5],[[7,8,9],V,30]]){
   let remaining=allowance;
   for(const n of ids){const f=nation*10+n;if(f===own||h.get(8,f,41)&1)continue;
    for(let i=0;i<10&&remaining;i++)if(!active(h,f,i)){ship(h,data,f,i,table[nation][tier][random(3)],(n<5?4:1)+random(3));remaining--;}
    strength(h,f);
   }
  }
 }
 // All rival protagonists and designated rival captains receive at most one
 // ship per month. Matching or stronger fleets grow on a one-in-three roll.
 const playerStrength=strength(h,own),rank=h.get(1,h.state.protagonist,13);
 for(let id=0;id<120;id++){
  const f=h.get(3,id,44),position=f%10;if(id===h.state.protagonist||f>=70||f===own)continue;
  if(id>=6&&(!(h.get(3,id,47)&4)||!(h.get(3,id,49)&32)||h.get(3,id,46)!==1||(f<60&&position>=1&&position<=4)))continue;
  if(strength(h,f)>=playerStrength&&random(3)!==0)continue;
  const kind=id<3?id:id<5?0:id===5?3:position>=7?2:1,type=[[14,9],[21,20],[14,10],[11,9]][kind][rank<5?0:1];
  let slot=Array.from({length:10},(_,i)=>i).find(i=>!active(h,f,i));
  if(slot===undefined)slot=Array.from({length:10},(_,i)=>i).sort((a,b)=>h.get(8,f,43+a*9+7)-h.get(8,f,43+b*9+7))[0];
  ship(h,data,f,slot,type,1+random(3));strength(h,f);
 }
 for(const id of [0,1,2,3,4,5,60])if(id!==h.state.protagonist){
  for(const [level,stats] of [[36,[28,29,30,31]],[37,[28,32,33]]]){const old=h.get(3,id,level),target=h.get(3,h.state.protagonist,level);if(old>=target)continue;const next=Math.min(100,level===36?target+1+random(2):old+random(2)+floor((target-old)/2)+1);h.set(3,id,level,next);for(let i=old;i<next;i++)for(const stat of stats)h.set(3,id,stat,Math.min(100,h.get(3,id,stat)+random(stat===28?3:5)));}
 }
 // Existing unemployed captains can resume command. Generic sailor creation is
 // deliberately outside this pass; it must not recycle story recruits.
 for(let f=1;f<70;f++){
  if(f%10===0||f===own||h.get(8,f,41)&1||count(h,f)<4+random(2)||random(2)!==0)continue;
  const nation=floor(f/10),id=Array.from({length:114},(_,i)=>i+6).find(id=>h.get(3,id,44)===255&&(h.get(3,id,49)&32)&&!(h.get(3,id,49)&16)&&(nation===6?(h.get(3,id,47)&3)>=2:(h.get(3,id,49)&7)===nation));
  if(id===undefined)continue;const capital=[0,1,2,29,8,33][nation===6?(h.get(3,id,49)&7)%6:nation],p=data.ports[capital];
  h.set(3,id,44,f);h.set(3,id,45,255);h.set(3,id,46,1);h.set(8,f,42,id);h.set(8,f,0,p.x,2);h.set(8,f,2,p.y,2);h.set(8,f,27,0);h.set(8,f,28,capital);h.set(8,f,38,capital);h.set(8,f,39,5+random(10));h.set(8,f,41,49);h.set(8,f,36,floor(h.get(0,nation,0,2)/10)+1+random(3),2);for(let j=29;j<=33;j++)h.set(8,f,j,255);h.set(8,f,34,0,2);events.push({type:'FLEET_RELAUNCHED',fleet:f,captain:id});
 }
 return events;
}
