import test from 'node:test';import assert from 'node:assert/strict';
import {data} from './game-fixtures.mjs';import {VoyageGame} from './core/game.mjs';import {townPath,townWalkable} from './core/world.mjs';
let cid=0;const cmd=(g,type,rest={})=>g.command({id:'c'+(++cid),type,...rest});
export function dialogue(g){let count=0;while(g.state.wait){assert.ok(++count<300,'dialogue terminates');const r=g.state.wait;cmd(g,'STORY',{action:r.type==='MENU'?'CHOOSE':r.type==='YES_NO'?'ANSWER':'CONTINUE',choice:0,yes:true});}}
export function startErnst(){const g=new VoyageGame(data);g.start(3,{},123);dialogue(g);cmd(g,'LEAVE');cmd(g,'GO',{building:3});for(let i=0;g.state.town.path.length&&i<2000;i++)g.updateTown(.1);cmd(g,'ENTER',{building:3});dialogue(g);return g;}
function visit(g,building){cmd(g,'LEAVE');cmd(g,'GO',{building});for(let i=0;g.state.town.path.length&&i<2000;i++)g.updateTown(.1);cmd(g,'ENTER',{building});dialogue(g);}
test('130 ports have valid sea access; every town building is reachable from the original harbor',()=>{
 let total=0;for(const p of data.ports){assert.ok(data.world.nearest(p.x,p.y),p.name+' sea');const b=p.buildings.find(b=>b.id===3),map=data.townMaps[Math.min(p.id,100)],lim=data.walkLimits[p.tileset],start={x:b.x,y:b.y+1};assert.ok(townWalkable(map,lim,start.x,start.y),p.name+' arrival');for(const target of p.buildings){const path=townPath(map,lim,start,{x:target.x,y:target.y+1});assert.ok(path,p.name+' / '+target.name);total++;}}assert.equal(total,889);
});
test('Independent game plays opening, walks to facilities, recruits once, loads/unloads and leaves port',()=>{
 const g=startErnst();assert.equal(g.director.state.personal.section,1);assert.equal(g.ships.length,1);assert.equal(g.host.gold(),5000);visit(g,1);cmd(g,'RECRUIT',{quantity:15});assert.equal(g.ships[0].crew,15);assert.throws(()=>cmd(g,'RECRUIT',{quantity:15}));visit(g,3);cmd(g,'AUTO_SUPPLY');assert.equal(g.ships[0].water,g.ships[0].food);assert.ok(g.ships[0].water>0);cmd(g,'SUPPLY',{slot:0,kind:'food',mode:'unload',quantity:1});cmd(g,'SUPPLY',{slot:0,kind:'food',mode:'load',quantity:'MAX'});cmd(g,'SAIL');assert.equal(g.state.mode,'sea');const before={...g.state.sea};cmd(g,'COURSE',{port:29});for(let i=0;i<12;i++)g.tickSea();assert.ok(before.x!==g.state.sea.x||before.y!==g.state.sea.y);assert.ok(data.world.navigable(g.state.sea.x,g.state.sea.y));
});
test('Save restore and exact touch command duplicate are atomic across economy and story',()=>{
 const g=startErnst(),save=g.snapshot(),copy=new VoyageGame(data,JSON.parse(JSON.stringify(save)));assert.deepEqual(copy.snapshot(),save);const action={id:'one-supply',type:'AUTO_SUPPLY'};g.command(action);const first=g.snapshot();assert.equal(g.command(action),false);assert.deepEqual(g.snapshot(),first);assert.throws(()=>g.command({id:'bad',type:'SUPPLY',slot:0,kind:'food',mode:'load',quantity:999999}));assert.deepEqual(g.snapshot(),first);
});
test('Route planning crosses the North Sea without land tiles and stays deterministic after save',()=>{
 const g=startErnst();visit(g,1);cmd(g,'RECRUIT',{quantity:10});visit(g,3);cmd(g,'AUTO_SUPPLY');cmd(g,'SAIL');cmd(g,'COURSE',{port:29});assert.ok(g.state.sea.route.length);for(const step of g.state.sea.route)assert.ok(data.world.navigable(step.x,step.y));const restored=new VoyageGame(data,JSON.parse(JSON.stringify(g.snapshot())));for(let i=0;i<100&&!g.state.wait;i++){g.tickSea();restored.tickSea();}assert.deepEqual(restored.snapshot(),g.snapshot());
});
