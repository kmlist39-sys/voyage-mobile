import fs from 'node:fs';import path from 'node:path';import {analysisDirectory} from './paths.mjs';
import {GameRecords} from './core/game-records.mjs';import {StoryVM,createStoryState,storySeed} from './core/story-vm.mjs';
const read=f=>JSON.parse(fs.readFileSync(path.join(analysisDirectory,f)));
export const data={initial:read('data/initial-state.json'),ships:read('data/ships.json'),goods:read('data/goods.json'),discoveries:read('data/discoveries.json'),ports:read('data/ports.json')};
export const programs=Array.from({length:7},(_,i)=>read(`stories/SNR${i}.json`));
export class StoryPlayer{
 constructor(id){this.id=id;this.host=new GameRecords(data);this.host.setProtagonist(id);this.state=createStoryState();this.transcript=[];this.routes=[];}
 visit(selector,qualifier,{tick,choice=0,yes=true,duel=140}={}){
  if(selector<130)this.host.state.port=selector;if(tick!==undefined)this.host.state.calendar.tick=tick;
  if(selector===161||selector===162)this.state.variables[60]=qualifier;
  let vm=new StoryVM(programs[this.id+1],this.state,this.host);if(!vm.start(selector,qualifier,storySeed(this.host.state.calendar,this.host.captain(this.id))))return null;
  const start={selector,qualifier,section:this.state.section,subsection:this.state.subsection};let waits=0;
  for(;;){const result=vm.run();if(result.type==='COMPLETE'){this.state=vm.snapshot();this.routes.push({...start,waits,after:[this.state.section,this.state.subsection],control:result.control});return result;}
   if(++waits>1000)throw new Error('Story interaction did not finish');
   for(const panel of result.panels??[])for(const message of panel.messages){const m=programs[this.id+1].messages[message];if(!m)throw new Error('Missing message '+message);this.transcript.push({message,character:panel.character,body:this.host.format(m.body,vm.state.variables),label:this.host.format(m.speakerLabel??'',vm.state.variables)});}
   // Restore both world and continuation at every input boundary.
   this.host=new GameRecords(data,JSON.parse(JSON.stringify(this.host.snapshot())));vm=new StoryVM(programs[this.id+1],JSON.parse(JSON.stringify(vm.snapshot())),this.host);
   const command={id:`${this.routes.length}-${waits}`,revision:result.revision,type:result.type==='MENU'?'CHOOSE':result.type==='YES_NO'?'ANSWER':result.type==='DUEL'?'DUEL_RESULT':'CONTINUE',choice,yes,balance:duel};vm.answer(command);
  }
 }
}
export function openingRuns(){
 const players=Array.from({length:6},(_,i)=>new StoryPlayer(i));
 const sequences=[[[0,7],[0,1],[0,7,{tick:66}],[0,10],[0,2],[0,3],[160,1],[160,3]],[[1,7],[1,1],[1,7],[1,1],[1,3],[160,1]],[[29,5],[29,2],[29,3],[29,1],[29,3],[160,1],[1,1],[1,3],[160,1]],[[33,7],[33,3]],[[8,3],[8,1],[0,7],[0,3]],[[2,2],[2,1],[2,3],[2,8],[2,2],[160,1]]];
 for(let i=0;i<6;i++)for(const [selector,qualifier,options] of sequences[i])players[i].visit(selector,qualifier,options);
 return players;
}
if(process.argv[1]&&path.resolve(process.argv[1])===path.resolve(import.meta.filename)){
 const summaries=openingRuns().map(p=>({id:p.id,name:p.host.captain(p.id).firstName,section:p.state.section,subsection:p.state.subsection,gold:p.host.gold(),ships:p.host.ships().map(s=>({name:s.name,type:s.type,crew:s.crew,water:s.water,food:s.food,captain:s.captain?.id})),mates:p.host.mates(),dialogueLines:p.transcript.length,unresolved:p.transcript.filter(t=>/\$[drns]/.test(t.body)),routes:p.routes}));
 fs.writeFileSync(path.join(analysisDirectory,'story-opening-runs.json'),JSON.stringify({scope:'Independent story interpreter + record mutation with all input boundaries saved/restored. Sailing, physical building entry, rendered UI and ordinary systems are outside this script test.',summaries},null,2));
 console.log(JSON.stringify(summaries.map(({routes,unresolved,...p})=>({...p,unresolved:unresolved.length})),null,2));
}
