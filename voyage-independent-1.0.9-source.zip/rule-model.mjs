// Analysis reference model only. This is not the completed remake.
// Korean MAIN.EXE 0x35FE1–0x361AA, manually compared through RETF.
// Calls and referenced record layouts must still receive differential runtime tests.
const u8=n=>n&255,u16=n=>n&65535,s16=n=>(n<<16)>>16;
const trunc=n=>Math.trunc(n);
export function legacyLoadFactor(load,capacity){
 if(!Number.isInteger(load)||load<0||!Number.isInteger(capacity)||capacity<=0)throw new RangeError('Invalid load or capacity');
 // IMUL followed by CWD discards the product's high word. The subsequent
 // minimum is UNSIGNED. These are observed instructions, not recommended design.
 return Math.min(150,u16(trunc(s16(-100*load)/capacity)+180));
}
export function intendedLoadFactor(load,capacity){
 if(!Number.isInteger(load)||load<0||!Number.isInteger(capacity)||capacity<=0)throw new RangeError('Invalid load or capacity');
 return Math.max(0,Math.min(150,180-trunc(100*load/capacity)));
}
export function shipSpeed(ship,captain,wind,heading,table,{legacyOverflow=true}={}){
 for(const n of [heading,wind.direction])if(!Number.isInteger(n)||n<0||n>7)throw new RangeError('Invalid heading');
 if(ship.minimumCrew<=0||ship.capacity<=0)throw new RangeError('Invalid ship model');
 const row=Math.abs(wind.direction-heading),windSpeed=ship.oared?Math.max(3,wind.speed):wind.speed;
 let speed=u8(trunc(s16(table[row][ship.sailType]*ship.power*windSpeed)/150));
 const nav=Math.min(100,trunc(ship.navigationPercent*ship.crew/ship.minimumCrew));
 speed=u8(trunc(nav*speed/100));
 speed=u8(trunc(speed*(legacyOverflow?legacyLoadFactor(ship.load,ship.capacity):intendedLoadFactor(ship.load,ship.capacity))/100));
 speed=u8(Math.min(30,speed+trunc(speed*captain.navigationLevel/10)));
 speed=u8(Math.min(40,trunc(speed*captain.seamanship/75)));
 if(row>=3&&row<=5)speed=u8(trunc(ship.tacking*speed/100));
 return speed;
}
export function fleetSpeed(ships,wind,heading,table,options){
 if(!ships.length)return 0;
 if(wind.speed===0&&!ships.some(s=>s.oared))return 0;
 return Math.max(2,Math.min(...ships.map(s=>shipSpeed(s,s.captain,wind,heading,table,options))));
}
export function windRegion(x,y,month,data){
 if(!Number.isInteger(x)||x<0||x>=2160||!Number.isInteger(y)||y<0||y>=1080||!Number.isInteger(month)||month<1||month>12)throw new RangeError('Invalid map position or month');
 const region=Math.floor(y/72)*30+Math.floor(x/72);
 return {region,wind:data.tables[month>=4&&month<=9?0:1][region],current:data.tables[2][region]};
}
// A command contract demonstrating direct selection. It deliberately has no
// DOM, frame capture, DOS memory, key codes, keyboard queue or emulator dependency.
export function selectCommand(state,actionId){
 const action=state.actions.find(a=>a.id===actionId);
 if(!action)throw new Error('Unknown action');
 if(!action.enabled)return {state,result:{ok:false,reason:action.reason}};
 return {state:{...state,selectedAction:actionId},result:{ok:true,actionId}};
}
