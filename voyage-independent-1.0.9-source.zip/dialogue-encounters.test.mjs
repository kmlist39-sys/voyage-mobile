import test from 'node:test';
import assert from 'node:assert/strict';
import {data} from './game-fixtures.mjs';
import {VoyageGame} from './core/game.mjs';
import {patrons} from './core/port-services.mjs';
import {createBattlePractice} from './core/battle-practice.mjs';
import {advanceRealtime} from './core/realtime-battle.mjs';
import {random} from './core/random.mjs';
let id=0;
const command=(g,type,args={})=>g.command({id:'dialogue-test-'+ ++id,type,...args});
function finishStory(g){for(let i=0;g.state.wait&&i<300;i++){const w=g.state.wait;command(g,'STORY',{action:w.type==='MENU'?'CHOOSE':w.type==='YES_NO'?'ANSWER':'CONTINUE',choice:0,yes:true});}assert.equal(g.state.wait,null);}
export function fixture(){const g=new VoyageGame(data);g.start(3,{},123);finishStory(g);g.state.building=3;g.host.setGold(10000);g.host.writeShip({...g.ships[0],water:400,food:400,crew:15});return g;}
function hostile(){const g=fixture();command(g,'SAIL');finishStory(g);const f=15,h=g.host,s=g.state.sea;h.set(8,f,0,s.x,2);h.set(8,f,2,s.y,2);h.set(8,f,41,1);h.set(8,f,27,4);h.set(8,f,28,g.captain.id);s.cooldown=0;return g;}
test('Every available pub and inn patron responds with their own name; rumors rotate and survive save',()=>{
 const g=fixture();let count=0;for(let port=0;port<100;port++)for(const building of [1,4]){g.host.state.port=port;g.state.building=building;for(const sailor of patrons(g,building)){command(g,'SAILOR_TALK',{sailor,topic:'greeting'});assert.match(g.state.sailorReply.text,new RegExp(g.host.captain(sailor).firstName));assert.equal(g.state.sailorReply.sailor,sailor);command(g,'SAILOR_TALK',{sailor,topic:'rumor'});const first=g.state.sailorReply.text;command(g,'SAILOR_TALK',{sailor,topic:'rumor'});assert.notEqual(g.state.sailorReply.text,first);count++;}}
 assert(count>30);assert.deepEqual(new VoyageGame(data,g.snapshot()).state.sailorReply,g.state.sailorReply);
});
test('Absent sailors reject atomically; prayer repeats acknowledge without reroll; donation reports exact deduction',()=>{
 const g=fixture(),before=g.snapshot();assert.throws(()=>command(g,'SAILOR_TALK',{sailor:119,topic:'greeting'}));assert.deepEqual(g.snapshot(),before);
 g.state.building=10;command(g,'PRAY');assert.match(g.state.message,/기도를 올렸/);const luck=g.captain.luck,rng=g.state.rng;command(g,'PRAY');assert.equal(g.captain.luck,luck);assert.equal(g.state.rng,rng);assert.match(g.state.message,/이미 마쳤/);
 command(g,'DONATE',{amount:2000});assert.equal(g.host.gold(),8000);assert.match(g.state.message,/2,000.*8,000/);const after=g.snapshot();assert.throws(()=>command(g,'DONATE',{amount:9000}));assert.deepEqual(g.snapshot(),after);
});
test('Hostile NPC approach pauses before battle; pending encounter survives save and blocks sailing commands',()=>{
 let g=hostile();g.host.state.calendar.tick=1;g.moveNpcFleets();assert.equal(g.state.encounter?.fleet,15);assert.equal(g.state.mode,'sea');assert.equal(g.state.battle,null);
 g=new VoyageGame(data,g.snapshot());const before=g.snapshot();for(let i=0;i<50;i++)g.tickSea();assert.deepEqual(g.snapshot(),before);assert.throws(()=>command(g,'HEADING',{heading:2}));assert.deepEqual(g.snapshot(),before);
 command(g,'ENCOUNTER_REPLY',{action:'fight'});finishStory(g);assert.equal(g.state.encounter,null);assert.equal(g.state.mode,'battle');
});
for(const escaped of [true,false])test('Encounter flee '+(escaped?'success resumes with cooldown':'failure waits for battle confirmation'),()=>{
 const g=hostile();g.requestHostileEncounter(15);for(let seed=1;;seed++){if((random({rng:seed},100)<g.state.encounter.chance)===escaped){g.state.rng=seed;break;}}
 const hp=g.ships[0].durability;command(g,'ENCOUNTER_REPLY',{action:'flee'});assert.equal(g.state.encounter.phase,escaped?'escaped':'pursuit');assert.equal(g.state.mode,'sea');assert.equal(g.ships[0].durability,hp);
 assert.throws(()=>command(g,'ENCOUNTER_REPLY',{action:'flee'}));command(g,'ENCOUNTER_REPLY',{action:'continue'});finishStory(g);
 assert.equal(g.state.encounter,null);assert.equal(g.state.mode,escaped?'sea':'battle');if(escaped){assert.equal(g.state.sea.cooldown,144);assert.equal(g.requestHostileEncounter(15),false);}
});
test('All four open sea edges automatically escape only while deliberately sailing outward',()=>{
 for(const [x,y,dx,dy] of [[1.3,24,-1,0],[49.7,24,1,0],[20,1.3,0,-1],[20,45.7,0,1]]){let s=createBattlePractice(data).state.battle;Object.assign(s.units[0],{x,y,angle:Math.atan2(dy,dx)});s.units[1].shot=0;
 assert.equal(advanceRealtime(s,.1,{}).state.phase,'active');assert.equal(advanceRealtime(s,.1,{x:-dx,y:-dy}).state.phase,'active');
 for(let t=0;t<100&&s.phase==='active';t++)s=advanceRealtime(s,.05,{x:dx,y:dy}).state;
 assert.equal(s.outcome,3);assert.equal(s.units[0].left,true);assert.equal(s.units[0].durability,10000);assert.deepEqual(advanceRealtime(s,.5,{fire:true}).state,s);
 }
});
test('Reaching land near an edge does not escape; edge escape settles a real battle and restores sailing',()=>{
 let s=createBattlePractice(data).state.battle;Object.assign(s.units[0],{x:3,y:24,angle:Math.PI});for(let y=0;y<s.height;y++)s.terrain[y*s.width+2]=1;s.units[1].shot=0;for(let t=0;t<100;t++)s=advanceRealtime(s,.05,{x:-1,y:0}).state;assert.equal(s.phase,'active');
 const g=hostile();g.beginBattle(15);const b=g.state.battle,p=b.units.find(u=>u.id===b.player);b.terrain.fill(0);Object.assign(p,{x:1,y:24,angle:Math.PI});g.updateBattle(.1,{x:-1,y:0});finishStory(g);assert.equal(g.state.mode,'sea');assert.equal(g.state.sea.cooldown,144);assert.equal(g.state.notice.title,'전장 이탈 성공');assert(g.ships[0].durability>0);command(g,'NOTICE_ACK');assert.equal(g.state.notice,null);
});
