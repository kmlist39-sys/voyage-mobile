package kr.voyage.independent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import java.io.*;
import java.util.*;
public final class VoyageActivity extends Activity {
 private WebView game;
 private static final String ORIGIN="https://voyage.local";
 @Override public void onCreate(Bundle saved){super.onCreate(saved);game=new WebView(this);game.setBackgroundColor(0xff102b31);setContentView(game);WebSettings settings=game.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMediaPlaybackRequiresUserGesture(false);settings.setSupportZoom(false);game.setWebChromeClient(new WebChromeClient());
  game.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){String host=request.getUrl().getHost(),path=request.getUrl().getPath();if(!"voyage.local".equals(host)||path==null||path.contains(".."))return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));if(path.equals("/"))path="/index.html";String mime=path.endsWith(".html")?"text/html":path.endsWith(".mjs")||path.endsWith(".js")?"text/javascript":path.endsWith(".json")?"application/json":path.endsWith(".css")?"text/css":path.endsWith(".png")?"image/png":path.endsWith(".webp")?"image/webp":path.endsWith(".jpg")?"image/jpeg":"application/octet-stream";
    try{return new WebResourceResponse(mime,"UTF-8",200,"OK",Collections.singletonMap("Cache-Control","no-cache"),getAssets().open("game"+path));}catch(IOException e){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !"voyage.local".equals(request.getUrl().getHost());}
  });game.loadUrl(ORIGIN+"/index.html");
 }
 @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
 @Override public void onBackPressed(){game.evaluateJavascript("window.onVoyageBack&&window.onVoyageBack()",null);}
 @Override protected void onPause(){game.evaluateJavascript("window.persistVoyage&&window.persistVoyage()",null);game.onPause();super.onPause();}
 @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();}
 @Override protected void onDestroy(){if(game!=null)game.destroy();super.onDestroy();}
}
