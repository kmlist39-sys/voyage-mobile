import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {analysisDirectory} from './paths.mjs';
import {initializeDiscoveries} from './core/discovery-start.mjs';
const oracle=JSON.parse(fs.readFileSync(path.join(analysisDirectory,'oracle/new-game.json')));
const candidates=oracle.baseDiscoveries.map((raw,id)=>({id,contentId:raw[4],flags:raw[6],untouched:raw.slice(0,4).concat(raw[5])}));
test('All six protagonist starting ports are traced separately from unfinished introduction outcomes',()=>{
 const a=JSON.parse(fs.readFileSync(path.join(analysisDirectory,'new-game-audit.json')));
 assert.deepEqual(a.profiles.map(p=>p.portId),[0,1,29,33,8,2]);assert.deepEqual(a.profiles.map(p=>p.fleetId),[0,10,30,50,40,20]);
 assert.ok(a.profiles.every(p=>p.playableStartingMoneyVerified===false&&p.playableStartingShipsVerified===false));
 assert.equal(a.checks.length,9);assert.equal(a.sourceSha256,oracle.sourceSha256);assert.equal(a.templateSha256,oracle.templateSha256);
});
test('64 discovery initializations match Korean machine code with identical recorded random draws',()=>{
 assert.equal(oracle.sourceSha256,'1718bbbbcdd938dfe44403d9bd5254dfc02d431217dea39ae5fb3fcde1597747');assert.equal(oracle.cases.length,64);
 for(const c of oracle.cases){
  let at=0;const actual=initializeDiscoveries(candidates,n=>{assert.equal(n,98);return c.rngValues[at++];});
  assert.equal(actual.randomDraws,c.rngValues.length);assert.equal(at,c.rngValues.length);
  actual.discoveries.forEach((d,i)=>{assert.equal(d.contentId,c.discoveries[i][4]);assert.equal(d.flags,c.discoveries[i][6]);assert.deepEqual(d.untouched,c.discoveries[i].slice(0,4).concat(c.discoveries[i][5]));});
  assert.deepEqual(actual.treasureItems.map(t=>t.discoveryId),c.treasureItemLocations);
  assert.deepEqual(actual.treasureItems.map(t=>t.itemId),[80,81,82,83,84,85,86,87,88,89]);
 }
});
test('New-game discovery placement selects 50 ordinary sites and 10 distinct unselected treasure sites',()=>{
 for(const c of oracle.cases){
  let at=0;const r=initializeDiscoveries(candidates,()=>c.rngValues[at++]);
  assert.equal(r.discoveries.slice(0,98).filter(d=>!(d.flags&0x80)).length,50);
  assert.equal(new Set(r.treasureItems.map(t=>t.discoveryId)).size,10);
  for(const t of r.treasureItems){assert.ok(r.discoveries[t.discoveryId].flags&0x80);assert.equal(r.discoveries[t.discoveryId].contentId,t.discoveryContentId);}
  assert.deepEqual(r.discoveries.slice(98),candidates.slice(98));
 }
});
test('Broken random sources fail in bounded work without changing input definitions',()=>{
 const before=structuredClone(candidates);
 assert.throws(()=>initializeDiscoveries(candidates,()=>0),/한도/);
 for(const value of [-1,98,NaN,0.5])assert.throws(()=>initializeDiscoveries(candidates,()=>value),/범위/);
 assert.deepEqual(candidates,before);
});
