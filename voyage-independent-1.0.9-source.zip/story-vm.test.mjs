import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {analysisDirectory} from './paths.mjs';import {StoryVM,createStoryState,auditStoryOpcodes,findStoryRoute} from './core/story-vm.mjs';
const read=f=>JSON.parse(fs.readFileSync(path.join(analysisDirectory,f))),programs=Array.from({length:7},(_,i)=>read(`stories/SNR${i}.json`)),oracle=read('oracle/story.json');
test('All 24737 decoded instructions have explicit opcode handlers',()=>{assert.deepEqual(auditStoryOpcodes(programs).unsupported,[]);assert.equal(Object.values(auditStoryOpcodes(programs).counts).reduce((a,b)=>a+b),24737);});
test('1000 complete original VM arithmetic, indirect write, branch and RNG programs match',()=>{
 for(const c of oracle.cases){const memory=c.memory.slice(),s=createStoryState();Object.assign(s,{active:true,pc:0,flags:c.flags,random:c.seed});s.variables.splice(0,16,...c.variables);s.variables[0]={group:0,offset:0};
  const host={read:(r,w)=>memory[r.offset]|(w===2?memory[r.offset+1]<<8:0),write:(r,v,w)=>{memory[r.offset]=v&255;if(w===2)memory[r.offset+1]=v>>8&255;}};
  const p={storyScriptId:1,sections:[{instructions:c.instructions}],messages:[]},vm=new StoryVM(p,s,host);assert.equal(vm.run().type,'COMPLETE');
  assert.deepEqual(vm.state.variables.slice(1,16),c.result.variables.slice(1),JSON.stringify(c));assert.deepEqual(memory,c.result.memory);assert.equal(vm.state.flags,c.result.flags);assert.equal(vm.state.random,c.result.seed);
 }
});
function synthetic(hexes){let at=0;const instructions=hexes.map(rawHex=>{const i={offset:at,endOffset:at+rawHex.length/2,rawHex,opcode:parseInt(rawHex.slice(0,2),16)};at=i.endOffset;return i;});return {storyScriptId:1,sections:[{routes:[{selector:0,qualifier:1,destinationOffset:0}],instructions}],messages:[{body:'대화입니다.'},{body:'예\n아니요\n생각할 시간'}]};}
test('Conversation and explicit menu choices survive serialization and reject stale or duplicate input',()=>{
 const p=synthetic(['c001','cc0006','c80000','c7','c9000001','2c0101','f1','f2']),vm=new StoryVM(p,createStoryState(),{});assert.ok(vm.start(0,1,0));const first=vm.run();assert.equal(first.type,'DIALOGUE');
 const restored=new StoryVM(p,JSON.parse(JSON.stringify(vm.snapshot())),{});assert.deepEqual(restored.run(),first);assert.throws(()=>restored.answer({type:'CONTINUE',revision:0}));
 restored.answer({id:'continue-1',type:'CONTINUE',revision:first.revision});const menu=restored.run();assert.deepEqual(menu.options,['예','아니요','생각할 시간']);
 assert.equal(restored.answer({id:'continue-1',type:'CONTINUE',revision:first.revision}),false);assert.throws(()=>restored.answer({id:'bad',type:'CHOOSE',choice:3,revision:menu.revision}));
 restored.answer({id:'choose-1',type:'CHOOSE',choice:2,revision:menu.revision});assert.equal(restored.run().type,'COMPLETE');assert.equal(restored.state.variables[0],2);assert.equal(restored.state.section,1);assert.equal(restored.state.flags,0);
});
test('Routes prioritize exact contexts, wildcard contexts, and chapter-specific route tables',()=>{
 const p=programs[1],s=createStoryState();assert.equal(findStoryRoute(p,s,0,7).destinationOffset,94);assert.equal(findStoryRoute(p,s,0,8).qualifier,255);
 s.subsection=1;assert.equal(findStoryRoute(p,s,160,3).destinationOffset,2170);assert.equal(findStoryRoute(p,s,0,1),null);
});
test('All six ending opcodes produce a named ending wait, then complete with no external executable',()=>{
 for(let ending=0;ending<6;ending++){const p=synthetic(['f4'+ending.toString(16).padStart(2,'0')]);let recorded=null;const vm=new StoryVM(p,createStoryState(),{ending:id=>recorded=id});vm.start(0,1,0);const e=vm.run();assert.equal(e.type,'ENDING');assert.equal(recorded,ending);vm.answer({type:'CONTINUE',revision:e.revision});assert.equal(vm.run().type,'COMPLETE');}
});
