import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {World} from './core/world.mjs';
const base=new URL('./analysis/',import.meta.url),read=n=>JSON.parse(fs.readFileSync(new URL(n,base)));
export const data={navigation:read('data/navigation-graph.json'),initial:read('data/initial-state.json'),ships:read('data/ships.json'),goods:read('data/goods.json'),discoveries:read('data/discoveries.json'),items:read('data/items.json'),ports:read('data/ports.json'),sailors:read('data/sailors.json'),markets:read('data/markets.json'),programs:Array.from({length:7},(_,i)=>read(`stories/SNR${i}.json`)),townMaps:read('data/town-maps.json').maps.map(m=>new Uint8Array(Buffer.from(m.dataBase64,'base64'))),walkLimits:read('data/walk-limits.json'),wind:read('data/wind-current.json')};
data.worldParts=Array.from({length:3},(_,i)=>new Uint8Array(fs.readFileSync(new URL(`data/world-${i}.bin`,base))));data.world=new World(data.worldParts);
