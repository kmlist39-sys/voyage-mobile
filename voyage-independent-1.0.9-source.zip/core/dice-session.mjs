import {resolveDice,dicePayout,nextDiceStarter} from './dice-rules.mjs';

// A pure, serializable game state. Animation, sound and touch dispatch belong
// to the presentation layer and never delay or determine game commands.
const PHASES=['betting','offer','turn','settled','closed'];
const MAX_GOLD=0x7fffffff;
const fail=message=>{throw new RangeError(message)};
const integer=(n,min,max)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
const freshHand=()=>({dice:[],rolls:0,held:[],pending:[],finished:false});
export function createDiceSession({gold,seed=1}={}){
 if(!integer(gold,0,MAX_GOLD)||!integer(seed,1,0xffffffff))fail('소지금 또는 난수 시드가 올바르지 않습니다.');
 return {version:1,revision:0,phase:gold>=10?'betting':'closed',gold,rng:seed,round:1,starter:1,
  turn:1,turnsCompleted:0,stake:0,proposal:0,hands:[freshHand(),freshHand(),freshHand()],result:null,receipts:[]};
}
function random(s,n){
 // New deterministic RNG: original frame/BIOS-dependent randomness is not a
 // runtime dependency. Rejection avoids modulo bias; state survives saves.
 const limit=Math.floor(0xffffffff/n)*n;let x;
 do{x=s.rng;x^=x<<13;x^=x>>>17;x^=x<<5;s.rng=x>>>0;x=s.rng-1;}while(x>=limit);
 return x%n;
}
function draw(s,hand){
 if(hand.rolls===0)hand.dice=Array.from({length:5},(_,id)=>({id,face:random(s,6)+1}));
 else for(const die of hand.dice)if(!hand.held.includes(die.id))die.face=random(s,6)+1;
 // Keep stable ids when sorting so a selected die never changes identity.
 hand.dice.sort((a,b)=>a.face-b.face||a.id-b.id);hand.rolls++;
}
function finish(s,events){
 const hand=s.hands[s.turn];hand.finished=true;s.turnsCompleted++;
 events.push({type:'turn-finished',participant:s.turn});
 if(s.turnsCompleted===3){
  s.result=resolveDice(s.hands.map(h=>h.dice.map(d=>d.face)));
  s.result.stake=s.stake;s.result.payout=dicePayout(s.stake,s.result.winners);
  s.gold=Math.min(MAX_GOLD,s.gold+s.result.payout);s.result.net=s.result.payout-s.stake;
  s.starter=nextDiceStarter(s.starter,s.result.winners);s.phase='settled';
  events.push({type:'settled',...s.result,gold:s.gold});
 }else s.turn=(s.turn+1)%3;
}
function commitStake(s,amount,events){
 s.stake=Math.min(amount,500,s.gold);s.gold-=s.stake;s.proposal=0;s.phase='turn';
 events.push({type:'stake-paid',amount:s.stake,gold:s.gold});
}
export function diceActions(s){
 const act=(type,label,extra={})=>({type,label,...extra});
 if(s.phase==='betting')return [act('BET','판돈 걸기',{min:10,max:Math.min(500,s.gold)}),act('EXIT','주점으로 돌아가기')];
 if(s.phase==='offer')return [act('ACCEPT','제안 수락',{amount:Math.min(s.proposal,500,s.gold)}),act('REFUSE','판돈 협상'),act('EXIT','도박 취소')];
 if(s.phase==='settled')return [...(s.gold>=10?[act('NEXT_ROUND','다음 판')]:[]),act('EXIT','주점으로 돌아가기')];
 if(s.phase==='turn'&&s.turn!==0)return [act('ADVANCE','상대 차례 진행')];
 if(s.phase==='turn'){
  const h=s.hands[0];return [act('ROLL',h.rolls?'선택하지 않은 주사위 굴리기':'주사위 굴리기'),
   ...(h.rolls?[act('TOGGLE_HOLD','남길 주사위 선택',{dieIds:h.dice.filter(d=>!h.held.includes(d.id)).map(d=>d.id)}),act('FINISH_TURN','이 패로 확정')]:[])];
 }
 return [];
}
export function applyDiceCommand(state,command){
 // Repeated touch deliveries cannot pay twice. Late events carry an old
 // revision and are rejected even after their receipt leaves the small cache.
 if(!command||typeof command.id!=='string'||!command.id.length||command.id.length>128)return {ok:false,state,events:[],error:'명령 식별자가 필요합니다.'};
 if(state.receipts.includes(command.id))return {ok:true,duplicate:true,state,events:[]};
 if(command.revision!==state.revision)return {ok:false,state,events:[],error:'이미 처리된 화면의 입력입니다.'};
 const s=structuredClone(state),events=[];
 try{
  if(!diceActions(s).some(a=>a.type===command.type))fail('지금은 사용할 수 없는 행동입니다.');
  const h=s.hands[s.turn];
  switch(command.type){
   case 'BET':{
    const amount=command.amount;if(!integer(amount,10,Math.min(500,s.gold)))fail('판돈 범위를 확인하세요.');
    s.stake=amount;
    if(amount<200&&random(s,4)!==0){
     const raised=amount+Math.trunc(amount*(random(s,amount<100?10:5)+1)/10);
     s.proposal=raised;s.phase='offer';events.push({type:'offer',amount:s.proposal,payable:Math.min(s.proposal,500,s.gold)});break;
    }
    commitStake(s,amount,events);break;
   }
   case 'ACCEPT':commitStake(s,s.proposal,events);break;
   case 'REFUSE':{
    let amount=s.stake;
    if(random(s,3)!==0)amount=random(s,2)!==0?s.proposal:Math.trunc((s.stake+s.proposal)/2);
    commitStake(s,amount,events);break;
   }
   case 'TOGGLE_HOLD':{
    const id=command.dieId;
    if(!integer(id,0,4)||h.held.includes(id))fail('이미 보관한 주사위는 다시 굴릴 수 없습니다.');
    h.pending=h.pending.includes(id)?h.pending.filter(x=>x!==id):[...h.pending,id];
    events.push({type:'hold-selection',dieId:id,selected:h.pending.includes(id)});break;
   }
   case 'ROLL':
    h.held.push(...h.pending);h.pending=[];
    if(h.held.length===5){finish(s,events);break;}
    draw(s,h);events.push({type:'rolled',participant:0,roll:h.rolls,dice:structuredClone(h.dice)});
    if(h.rolls===3)finish(s,events);break;
   case 'FINISH_TURN':h.pending=[];finish(s,events);break;
   case 'ADVANCE':
    while(h.rolls<3){
     draw(s,h);events.push({type:'rolled',participant:s.turn,roll:h.rolls,dice:structuredClone(h.dice)});
     const counts=Array(7).fill(0);h.dice.forEach(d=>counts[d.face]++);
     for(const d of h.dice)if(counts[d.face]>1&&!h.held.includes(d.id))h.held.push(d.id);
     if(h.held.length===5)break;
    }
    finish(s,events);break;
   case 'NEXT_ROUND':
    s.round++;s.phase='betting';s.turn=s.starter;s.turnsCompleted=0;s.stake=0;s.proposal=0;s.result=null;s.hands=[freshHand(),freshHand(),freshHand()];break;
   case 'EXIT':s.phase='closed';events.push({type:'closed',gold:s.gold});break;
  }
  s.revision++;s.receipts=[...s.receipts,command.id].slice(-64);
  validateDiceSession(s);
  return {ok:true,state:s,events};
 }catch(e){return {ok:false,state,events:[],error:e.message};}
}
export function validateDiceSession(s){
 if(!s||s.version!==1||!PHASES.includes(s.phase)||!integer(s.revision,0,Number.MAX_SAFE_INTEGER)||!integer(s.round,1,Number.MAX_SAFE_INTEGER)||!integer(s.gold,0,MAX_GOLD)||!integer(s.rng,1,0xffffffff))fail('저장된 도박 상태가 올바르지 않습니다.');
 if(!integer(s.starter,0,2)||!integer(s.turn,0,2)||!integer(s.turnsCompleted,0,3)||!integer(s.stake,0,500)||!integer(s.proposal,0,500))fail('저장된 판돈 또는 차례가 올바르지 않습니다.');
 if(!Array.isArray(s.receipts)||s.receipts.length>64||new Set(s.receipts).size!==s.receipts.length||s.receipts.some(x=>typeof x!=='string'||!x.length||x.length>128))fail('저장된 명령 기록이 올바르지 않습니다.');
 if(!Array.isArray(s.hands)||s.hands.length!==3)fail('참가자 데이터가 올바르지 않습니다.');
 for(const h of s.hands){
  if(!h||!integer(h.rolls,0,3)||typeof h.finished!=='boolean'||!Array.isArray(h.dice)||h.dice.length!==(h.rolls?5:0))fail('주사위 개수 또는 횟수가 올바르지 않습니다.');
  if(new Set(h.dice.map(d=>d.id)).size!==h.dice.length||h.dice.some(d=>!integer(d.id,0,4)||!integer(d.face,1,6)))fail('주사위 값이 올바르지 않습니다.');
  for(const ids of [h.held,h.pending])if(!Array.isArray(ids)||new Set(ids).size!==ids.length||ids.some(id=>!h.dice.some(d=>d.id===id)))fail('보관한 주사위가 올바르지 않습니다.');
  if(h.pending.some(id=>h.held.includes(id))||h.finished&&!h.rolls)fail('보관 또는 확정 상태가 올바르지 않습니다.');
 }
 if(s.hands.filter(h=>h.finished).length!==s.turnsCompleted)fail('차례 완료 수가 일치하지 않습니다.');
 if(s.phase==='betting'&&(s.gold<10||s.stake||s.proposal||s.turnsCompleted||s.hands.some(h=>h.rolls)))fail('베팅 상태가 올바르지 않습니다.');
 if(s.phase==='offer'&&(s.stake<10||s.stake>s.gold||s.proposal<=s.stake||s.turnsCompleted||s.hands.some(h=>h.rolls)))fail('협상 상태가 올바르지 않습니다.');
 if(s.phase==='turn'&&(s.stake<10||s.proposal||s.turnsCompleted===3||s.turn!==(s.starter+s.turnsCompleted)%3||s.hands[s.turn].finished))fail('진행 차례가 올바르지 않습니다.');
 if(s.phase==='turn')for(let i=0;i<3;i++){
  const h=s.hands[(s.starter+i)%3];
  if(h.finished!==(i<s.turnsCompleted)||(i>s.turnsCompleted&&h.rolls)||(i===s.turnsCompleted&&(h.rolls===3||s.turn!==0&&h.rolls)))fail('저장된 참가자 차례가 일치하지 않습니다.');
 }
 if(s.phase==='closed'&&s.turnsCompleted>0&&s.turnsCompleted<3)fail('진행 중인 판이 종료 상태로 저장되었습니다.');
 if(s.turnsCompleted===3){
  const expected=resolveDice(s.hands.map(h=>h.dice.map(d=>d.face))),payout=dicePayout(s.stake,expected.winners);
  if(!s.result||s.result.resultCode!==expected.resultCode||JSON.stringify(s.result.winners)!==JSON.stringify(expected.winners)||JSON.stringify(s.result.scores)!==JSON.stringify(expected.scores)||s.result.stake!==s.stake||s.result.payout!==payout||s.result.net!==payout-s.stake)fail('정산 결과가 일치하지 않습니다.');
 }else if(s.result!==null||s.phase==='settled')fail('미완료 판에 정산 결과가 있습니다.');
 return s;
}
export function saveDiceSession(state){validateDiceSession(state);return JSON.stringify(state);}
export function restoreDiceSession(json){if(typeof json!=='string'||json.length>50000)fail('저장 데이터 크기가 올바르지 않습니다.');return validateDiceSession(JSON.parse(json));}
