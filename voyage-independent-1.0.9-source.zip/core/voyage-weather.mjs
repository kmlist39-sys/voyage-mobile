import {random} from './random.mjs';
export function regionWeather(x,y,month,tables){const index=Math.floor(y/72)*30+Math.floor(x/72);return {index,wind:tables[month>=4&&month<=9?0:1][index],current:tables[2][index]};}
export function createWeather(){return {wind:{speed:0,direction:0},current:{speed:0,direction:0},anomaly:null,balmDays:0};}
export function weatherCheck(state,region,ships,{ashore=false,officers=[],protagonist}={}){
 const s=structuredClone(state),next=structuredClone(ships),events=[],roll=n=>random(s,n);s.current={speed:region.current.speed,direction:region.current.direction};
 if(s.anomaly){
  const a=s.anomaly;if(a.pending){a.pending=false;a.announcedToday=true;events.push({type:'WEATHER_BEGAN',kind:a.kind});}
  if(a.kind==='storm'){
   s.wind.speed=7;if(!ashore)for(const ship of next){let d=Math.min(10,Math.floor((100-ship.captain.seamanship)/(Math.floor(ship.captain.navigationLevel/5)+3))+1)+roll(2);if(ship.stormWeak)d*=5;ship.durability=Math.max(0,ship.durability-d);ship.power=Math.max(0,ship.power-Math.floor(d/2));ship.tacking=Math.max(0,ship.tacking-Math.floor(d/2));ship.maximumDurability=Math.max(Math.floor(ship.modelDurability/4),ship.maximumDurability-1);events.push({type:ship.durability?'STORM_DAMAGE':'SHIP_SUNK',ship:ship.slot,damage:d});}
   if(!a.announcedToday&&(roll(8)===0||!(region.wind.anomalyFlags&2))){s.anomaly=null;events.push({type:'WEATHER_ENDED',kind:a.kind});}
  }else if(a.kind==='calm'){
   if(!a.announcedToday&&roll(20)===0&&region.wind.speed!==0){s.anomaly=null;events.push({type:'WEATHER_ENDED',kind:a.kind});}s.wind.speed=0;
  }else if(a.kind==='fog'&&!a.announcedToday&&(roll(30)===0||!(region.wind.anomalyFlags&2))){s.anomaly=null;events.push({type:'WEATHER_ENDED',kind:a.kind});}
 }else{
  s.wind={speed:Math.min(7,region.wind.speed+roll(2)),direction:(region.wind.direction+(roll(3)-1)*Math.floor(roll(5)/4)+8)%8};
  if(region.wind.anomalyFlags&2){const luck=Math.max(protagonist.luck,...officers.map(c=>c.luck)),figurehead=next.length?Math.floor(next.reduce((n,s)=>n+s.figurehead,0)/next.length):0;
   if(luck+50<roll(155)&&roll(11)>figurehead){
    if(region.wind.anomalyFlags&1)for(const ship of next)if(ship.captain.id!==protagonist.id){const die=roll(100);if(die>ship.captain.luck&&(ship.captain.status&0xc0)===0xc0){ship.missing=true;events.push({type:'SHIP_MISSING',ship:ship.slot});break;}}
    const type=region.current.anomalyFlags;let kind=null;
    if(type===1){if(roll(7)+3>=s.wind.speed&&s.balmDays===0)kind='storm';}
    else if(type===2){if(roll(6)>=s.wind.speed)kind='calm';}
    else if(type===3&&roll(10)===0&&roll(6)>=s.wind.speed)kind='fog';
    if(kind){s.anomaly={kind,pending:true,announcedToday:false};const advisor=officers.toSorted((a,b)=>b.intuition-a.intuition)[0];if(advisor&&roll(100)<=advisor.intuition)events.push({type:'WEATHER_WARNING',kind,captain:advisor.id,knowledge:advisor.knowledge});}
   }
  }
 }
 return {weather:s,ships:next,events};
}
export function illnessPass(state,ships,protagonist,inventory){const s={...state},next=structuredClone(ships),events=[],roll=n=>random(s,n);
 if(!s.rats&&s.daysAtSea>30&&!inventory.includes(25)&&roll(Math.floor(protagonist.navigationLevel/5)+2)===0&&roll(105)>protagonist.luck){s.rats=true;events.push({type:'RATS'});}
 if(s.rats)for(const ship of next)ship.food=Math.max(0,ship.food-10);
 if(!s.scurvy&&s.daysAtSea>60&&roll(105)>protagonist.luck){s.scurvy=true;events.push({type:'SCURVY'});}
 if(s.scurvy)for(const ship of next){const loss=Math.min(ship.crew,Math.floor((100-ship.captain.knowledge)/5)+roll(2));ship.crew-=loss;if(loss)events.push({type:'CREW_LOST',ship:ship.slot,count:loss,cause:'scurvy'});}
 return {state:s,ships:next,events};
}
