// A serializable interpreter for decoded story instructions. It evaluates game
// records and explicit actions; it never executes x86 or synthesizes input.
const u16=x=>x&65535,s16=x=>(x<<16)>>16,isRef=x=>x&&typeof x==='object'&&'group'in x;
const bytes=hex=>Uint8Array.from(hex.match(/../g),x=>parseInt(x,16));
const word=(b,i)=>(b[i]<<8)|b[i+1];
const ACTIONS=new Set([0xc0,0xc3,0xc4,0xc7,0xc8,0xc9,0xca,0xcb,0xcc,0xcd,0xd0,0xd1,0xd4,0xdc,0xe2,0xe3,0xe4,0xe6,0xe7,0xe8,0xe9,0xea,0xeb,0xec,0xed,0xee,0xf0,0xf1,0xf2,0xf4,0xf8,0xf9,0xfa,0xfb,0xfe]);
export function storyRandom(state,bound){const next=(Math.imul(state,0x5d588b65)+1)>>>0;return bound===0?{state,result:0}:{state:next,result:((next>>>8)&0x7fff)%bound};}
export function storySeed({year,month,day,tick},captain,shared=false){return ((Math.imul(Math.imul(year-1501,month-1),captain.navigationLevel+captain.navigationExperience)+day-1+(shared?0:tick))<<8)>>>0;}
export function findStoryRoute(program,state,selector,qualifier){
 const section=program.sections[state.section];if(!section)return null;
 const routes=state.subsection===0?section.routes:section.entryRouteTables[state.subsection-1]?.routes;
 if(!routes)return null;
 const selectors=[selector];if(selector<(program.storyScriptId===0?130:100))selectors.push(0xa3);
 for(const s of selectors){const r=routes.find(r=>r.selector===s&&r.qualifier===qualifier)??routes.find(r=>r.selector===s&&r.qualifier===255);if(r)return r;}
 return null;
}
export function createStoryState(){return {section:0,subsection:0,flags:0,variables:Array(256).fill(0),random:0,pc:null,active:false,pending:null,panels:[],currentPanel:null,control:1,advanceSection:false,advanceSubsection:false,string:'',revision:0,lastCommand:null};}
function numeric(value){if(!Number.isInteger(value))throw new TypeError('Numeric story operand required');return value;}
function flag(s,index){return !!(s.flags&(1<<(index&31)));}
function setFlag(s,index,value){s.flags=(value?s.flags|(1<<(index&31)):s.flags&~(1<<(index&31)))>>>0;}
export function auditStoryOpcodes(programs){
 const counts={},unsupported=[];
 for(const p of programs)for(const s of p.sections)for(const i of s.instructions){counts[i.opcodeHex]=(counts[i.opcodeHex]??0)+1;if(i.opcode>=192&&!ACTIONS.has(i.opcode))unsupported.push({script:p.storyScriptId,section:s.id,offset:i.offset,opcode:i.opcodeHex});}
 return {counts,unsupported};
}
const programMaps=new WeakMap();
export class StoryVM{
 constructor(program,state,host){this.program=program;this.state=structuredClone(state);this.host=host;this.events=[];if(!programMaps.has(program))programMaps.set(program,program.sections.map(s=>new Map(s.instructions.map(i=>[i.offset,i]))));this.maps=programMaps.get(program);}
 start(selector,qualifier,seed){const s=this.state;if(s.active)throw new Error('Story interaction still active');const route=findStoryRoute(this.program,s,selector,qualifier);if(!route)return false;
  Object.assign(s,{pc:route.destinationOffset,active:true,pending:null,panels:[],currentPanel:null,control:1,advanceSection:false,advanceSubsection:false,random:seed>>>0});s.revision++;return true;
 }
 read(ref,width){if(!isRef(ref))throw new TypeError('Story record reference required');return this.host.read(ref,width);}
 write(ref,value,width){if(!isRef(ref))throw new TypeError('Story record reference required');this.host.write(ref,value,width);}
 value(mode,operand,width){const v=this.state.variables[operand];if(mode===0)return v;if(mode===1)return this.read(v,width);if(mode===3)return operand;throw new Error('Unsupported operand mode '+mode);}
 panel(){let p=this.state.panels.find(p=>p.id===this.state.currentPanel);if(!p){p={id:0,character:null,messages:[]};this.state.panels.push(p);this.state.currentPanel=0;}return p;}
 snapshot(){return structuredClone(this.state);}
 finish(){const s=this.state;if(s.advanceSubsection){s.subsection++;if(this.program.storyScriptId===6&&s.section===2&&s.subsection===3){
   // Korean SNR6's decoy route leaves variable 10 pointing at Catalina's
   // fleet Y coordinate (0x1396..0x1432), overwriting the voyage counter.
   // Restore its intended counter role before the six voyage-day-5 checks.
   s.variables[10]=0;
  }}if(s.advanceSection){s.section=this.program.storyScriptId===0?0:s.section+1;s.subsection=0;s.flags=0;}s.active=false;s.pc=null;s.pending=null;s.panels=[];s.currentPanel=null;s.revision++;return {type:'COMPLETE',control:s.control};}
 block(type,details={}){const s=this.state;s.revision++;s.pending={type,...details,revision:s.revision};return structuredClone(s.pending);}
 answer(command){
  const s=this.state;if(command.id&&s.lastCommand===command.id)return false;
  const p=s.pending;if(!p||command.revision!==p.revision)throw new Error('Expired story choice');
  if(p.type==='DIALOGUE'&&command.type!=='CONTINUE')throw new Error('Continue required');
  if(p.type==='YES_NO'){if(command.type!=='ANSWER'||typeof command.yes!=='boolean')throw new Error('Yes/No required');setFlag(s,p.flag,command.yes);}
  if(p.type==='MENU'){if(command.type!=='CHOOSE'||!Number.isInteger(command.choice)||command.choice<0||command.choice>=p.options.length)throw new Error('Invalid menu choice');s.variables[p.variable]=command.choice;}
  if(p.type==='DUEL'){if(command.type!=='DUEL_RESULT'||!Number.isInteger(command.balance)||command.balance<0||command.balance>200)throw new Error('Invalid duel result');this.host.duelBalance=command.balance;}
  if(p.type==='ENDING'&&command.type!=='CONTINUE')throw new Error('Continue required');
  s.lastCommand=command.id??null;s.pending=null;this.panel().messages=[];
  if(p.type==='ENDING')this.finish();return true;
 }
 run(limit=20000){
  const s=this.state;if(s.pending)return structuredClone(s.pending);if(!s.active)return {type:'COMPLETE',control:s.control};
  for(let step=0;step<limit;step++){
   const i=this.maps[s.section]?.get(s.pc);if(!i)throw new Error(`Missing story instruction ${this.program.storyScriptId}:${s.section}:${s.pc}`);
   const b=bytes(i.rawHex),op=i.opcode;s.pc=i.endOffset;
   if(op<0x40){
    const dst=(op>>4)&3,src=(op>>2)&3,w=op&3,width=w===1?1:2;
    if(src===3&&w===3){if(b[2]===0){if(dst!==1)throw new Error('Invalid string assignment');this.host.writeText(s.variables[b[1]],s.string);}else{s.variables[b[1]]=u16(numeric(this.host.system(b[2])));}continue;}
    const v=src===3?(b.length===4?word(b,2):b[2]):this.value(src,b[2],width);
    if(dst===0)s.variables[b[1]]=isRef(v)?{...v}:numeric(v)&(width===1?255:65535);
    else if(dst===1)this.write(s.variables[b[1]],numeric(v),width);
    else if(dst===2)setFlag(s,b[1],v);else throw new Error('Invalid assignment destination');
   }else if(op<0x80){
    const dst=(op>>4)&1,src=(op>>2)&3,operation=op&0x23,ref=s.variables[b[1]],left=dst?this.read(ref,1):ref,right=numeric(this.value(src,b[2],src===1?1:2));
    if(isRef(left)){if(dst||![0,1].includes(operation))throw new Error('Invalid record reference arithmetic');s.variables[b[1]]={...left,offset:left.offset+(operation===0?right:-right)};continue;}
    const n=numeric(left);let value;
    switch(operation){case 0:value=n+right;break;case 1:value=n-right;break;case 2:value=n*right;break;case 3:if(!right)throw new Error('Story division by zero');value=Math.floor(n/right);break;case 32:value=n|right;break;case 33:value=n&right;break;case 34:value=n>>>(right&7);break;case 35:value=n<<(right&7);break;default:throw new Error('Unknown arithmetic');}
    if(dst)this.write(ref,u16(value),1);else s.variables[b[1]]=u16(value);
   }else if(op<0xc0){
    let take;if(op===0xac||op===0xad)take=flag(s,b[1])===(op===0xac);
    else {const number=v=>isRef(v)?this.host.numericReference(v):numeric(v),left=number(this.value((op>>4)&3,b[1],2)),right=number(this.value((op>>2)&3,b[2],2));take=[left!==right,left===right,left<right,left>right][op&3];}
    if(take)s.pc=i.branchDestinationOffset;
   }else switch(op){
    case 0xc0:{const previous=this.state.panels.find(p=>p.id===s.currentPanel);if(previous)previous.messages=[];let p=s.panels.find(p=>p.id===b[1]);if(!p){if(s.panels.length===2)s.panels.shift();p={id:b[1],character:null,messages:[]};s.panels.push(p);}p.messages=[];s.currentPanel=p.id;break;}
    case 0xc3:s.panels.pop();s.currentPanel=s.panels.at(-1)?.id??null;break;
    case 0xc4:s.panels=[];s.currentPanel=null;this.events.push({type:'CLOSE_DIALOGUE'});break;
    case 0xcc:this.panel().character=word(b,1);break;
    case 0xcd:this.panel().character=numeric(s.variables[b[1]]);break;
    case 0xc8:{const p=this.panel();if(p.lastEnd!==i.offset)p.messages=[];p.messages.push(word(b,1));p.lastEnd=i.endOffset;break;}
    case 0xc7:return this.block('DIALOGUE',{panels:structuredClone(s.panels)});
    case 0xc9:{const options=this.program.messages[word(b,2)]?.body.split('\n').filter(Boolean);if(!options?.length)throw new Error('Empty story menu');return this.block('MENU',{variable:b[1],options,panels:structuredClone(s.panels)});}
    case 0xe9:return this.block('YES_NO',{flag:b[1],panels:structuredClone(s.panels)});
    case 0xca:this.events.push({type:'MUSIC',track:b[1]});break;
    case 0xcb:this.events.push({type:'STORY_ART',script:this.program.storyScriptId,art:b[5],sourceX:word(b,1),sourceY:word(b,3)});break;
    case 0xdc:case 0xd0:s.variables[b[1]]=this.host.reference(b[2],op===0xdc?b[3]:numeric(s.variables[b[3]])&255,b[4]);break;
    case 0xd1:this.host.course(numeric(s.variables[b[1]])&255);break;
    case 0xd4:s.string=this.program.messages[word(b,1)]?.body;if(s.string===undefined)throw new Error('Missing story string');break;
    case 0xe2:this.host.loadGoods(numeric(s.variables[b[1]])&255,numeric(s.variables[b[2]]));break;
    case 0xe3:s.variables[b[2]]=u16(this.host.unloadGoods(numeric(s.variables[b[1]])&255,numeric(s.variables[b[2]])));break;
    case 0xe4:this.host.setGold(s16(numeric(s.variables[b[1]])));break;
    case 0xe6:this.host.setGold(this.host.gold()+s16(numeric(s.variables[b[1]])));break;
    case 0xe7:this.host.setGold(Math.max(0,this.host.gold()-s16(numeric(s.variables[b[1]]))));break;
    case 0xea:s.variables[b[1]]=Math.floor(this.host.gold()/10000);break;
    case 0xeb:{const r=storyRandom(s.random,word(b,2));s.random=r.state;s.variables[b[1]]=r.result;break;}
    case 0xec:s.random=(s16(numeric(s.variables[b[1]]))<<8)>>>0;break;
    case 0xed:s.variables[b[1]]=(s.random>>>8)&65535;break;
    case 0xee:s.variables[b[1]]=u16(this.host.freeCargo());break;
    case 0xe8:return this.block('DUEL',{sailor:b[1]});
    case 0xf0:s.advanceSubsection=true;break;
    case 0xf1:s.advanceSection=true;break;
    case 0xf2:return this.finish();
    case 0xf4:this.host.ending(b[1]);return this.block('ENDING',{ending:b[1]});
    case 0xf8:s.control=0;break;
    case 0xf9:this.host.createPendingShip(b[1]);break;
    case 0xfa:this.host.commissionShip(this.program.messages[word(b,2)]?.body??'');break;
    case 0xfb:this.host.joinSailor(b[1]);break;
    case 0xfe:s.pc=i.branchDestinationOffset;break;
    default:throw new Error('Unimplemented story opcode '+i.opcodeHex);
   }
  }
  throw new Error(`Story instruction budget exceeded at ${s.pc}; progress preserved for diagnosis`);
 }
}
