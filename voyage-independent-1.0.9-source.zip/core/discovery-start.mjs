// Independent new-game discovery/treasure placement. Input fields keep all
// existing bits; reserved records 98 and 99 are untouched by this initializer.
export function initializeDiscoveries(candidates,random){
 if(!Array.isArray(candidates)||candidates.length!==100||candidates.some(c=>!Number.isInteger(c.flags)||c.flags<0||c.flags>255||!Number.isInteger(c.contentId)||c.contentId<0||c.contentId>255))throw new RangeError('발견물 후보 데이터가 올바르지 않습니다.');
 const discoveries=structuredClone(candidates),treasureItems=[];let draws=0;
 const next=()=>{if(++draws>10000)throw new Error('발견물 배치 난수 한도를 초과했습니다.');const n=random(98);if(!Number.isInteger(n)||n<0||n>=98)throw new RangeError('난수 범위가 올바르지 않습니다.');return n;};
 for(let i=0;i<98;i++)discoveries[i].flags|=0x80;
 for(let chosen=0;chosen<50;){const d=discoveries[next()];if(d.flags&0x80){d.flags&=0x7f;chosen++;}}
 if(discoveries.slice(0,98).filter(d=>(d.flags&0x80)&&d.contentId<90).length<10)throw new RangeError('보물 배치 후보가 부족합니다.');
 for(let placed=0;placed<10;){
  const index=next(),d=discoveries[index];
  if((d.flags&0x80)&&d.contentId<90){d.contentId=90+placed;treasureItems.push({itemId:80+placed,discoveryId:index,discoveryContentId:d.contentId});placed++;}
 }
 return {discoveries,treasureItems,randomDraws:draws};
}
