import {StoryVM,createStoryState,storySeed} from './story-vm.mjs';
export class StoryDirector{
 constructor(programs,host,state){this.programs=programs;this.host=host;this.state=state?structuredClone(state):{shared:createStoryState(),personal:createStoryState(),queue:[],active:null,control:1,events:[],completed:null};}
 snapshot(){return structuredClone(this.state);}
 start(kind,selector,qualifier){
  if(this.state.active||this.state.queue.length)throw new Error('대화가 진행 중입니다.');
  this.state.control=1;this.state.completed=null;this.state.shared.variables[63]=0;this.state.personal.variables[63]=0;
  const task=(script)=>({script,selector,qualifier,kind});
  if(kind==='building')this.state.queue=[task('shared'),task('personal')];
  else if(kind==='before-battle'||kind==='after-battle'){this.state.shared.variables[60]=qualifier;this.state.personal.variables[60]=qualifier;this.state.queue=[task('personal'),task('shared')];}
  else if(kind==='voyage-day')this.state.queue=[task('personal')];
  else throw new Error('Invalid story trigger');
  return this.run();
 }
 jobs(){const s=this.state.shared;if(s.section!==0)return {active:true,section:s.section,reportPort:s.variables[16],destination:s.variables[17],goods:s.variables[18],quantity:s.variables[19],deadline:s.variables[24]};return {active:false,offers:s.variables.slice(0,3).map((type,row)=>({row,type,label:['화물 운송','상품 구입','서신 전달','해적 토벌','채무 징수'][type]}))};}
 chooseJob(row){
  if(this.state.active||this.state.queue.length)throw new Error('대화가 진행 중입니다.');const s=this.state.shared;
  if(s.section!==0||!Number.isInteger(row)||row<0||row>2)throw new Error('의뢰를 선택해 주세요.');
  const type=this.host.state.port>=42?2:s.variables[row];if(!Number.isInteger(type)||type<0||type>4)throw new Error('조합의 의뢰 목록을 먼저 확인해 주세요.');
  s.subsection=type+1;s.variables[8]=s.variables[3+row];s.variables[6]=0;s.variables[63]=0;
  this.state.control=1;this.state.queue=[{script:'shared',selector:this.host.state.port,qualifier:6,kind:'job-offer'}];return this.run();
 }
 audience(){
  if(this.state.active||this.state.queue.length)throw new Error('대화가 진행 중입니다.');const s=this.state.shared,port=this.host.state.port;
  this.state.control=1;this.state.queue=[];
  if(s.section===0&&(s.flags&(1<<17))&&s.variables[30]>=6&&s.variables[30]<=12){s.section=s.variables[30];s.subsection=0;this.state.queue.push({script:'shared',selector:port,qualifier:5,kind:'royal-initialize'});}
  else this.state.queue.push({script:'shared',selector:port,qualifier:5,kind:'audience'});
  this.state.queue.push({script:'personal',selector:port,qualifier:21,kind:'audience'},{script:'shared',selector:port,qualifier:21,kind:'audience'});return this.run();
 }
 vm(){const task=this.state.active;return new StoryVM(this.programs[task.script==='shared'?0:this.host.state.protagonist+1],this.state[task.script],this.host);}
 run(){
  for(let count=0;count<10;count++){
   if(!this.state.active){const task=this.state.queue.shift();if(!task)return {type:'COMPLETE',control:this.state.control};
    if(task.kind==='building'&&task.script==='personal'&&this.state.shared.variables[63])continue;
    if(task.kind==='before-battle'&&!this.state.control){this.state.queue=[];return {type:'COMPLETE',control:0};}
    this.state.active=task;const vm=this.vm();if(!vm.start(task.selector,task.qualifier,storySeed(this.host.state.calendar,this.host.captain(this.host.state.protagonist),task.script==='shared'))){this.state.active=null;continue;}this.state[task.script]=vm.snapshot();
   }
   const task=this.state.active,vm=this.vm(),result=vm.run();this.state[task.script]=vm.snapshot();this.state.events.push(...vm.events);
   if(result.type!=='COMPLETE')return {...result,script:task.script,scriptId:task.script==='shared'?0:this.host.state.protagonist+1};
   this.state.control&=result.control;
   if(task.kind==='job-offer'){this.state.shared.section=this.state.shared.variables[6];this.state.shared.subsection=0;}
   this.state.active=null;this.state.completed=task;
  }
  throw new Error('Story trigger queue exceeded');
 }
 answer(command){if(!this.state.active)throw new Error('대기 중인 대화가 없습니다.');const vm=this.vm();vm.answer(command);this.state[this.state.active.script]=vm.snapshot();return this.run();}
 takeEvents(){const events=this.state.events;this.state.events=[];return events;}
}
