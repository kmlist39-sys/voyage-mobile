import {hullBlocked,DIRECTIONS} from './navigation-rules.mjs';
export class World {
 constructor(parts){if(parts.length!==3||parts.some(p=>p.length!==720*1080))throw new Error('세계 지도 데이터가 손상되었습니다.');this.parts=parts;this.water=new Map();}
 tile(x,y){if(y<0||y>=1080)return 255;x=(Math.floor(x)+2160)%2160;return this.parts[Math.floor(x/720)][Math.floor(y)*720+x%720];}
 navigable(x,y){return y>=0&&y<1079&&!hullBlocked(x,y,(a,b)=>this.tile(a,b));}
 nearest(x,y,radius=16){for(let r=0;r<=radius;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++)if(Math.max(Math.abs(dx),Math.abs(dy))===r&&this.navigable(x+dx,y+dy))return {x:(x+dx+2160)%2160,y:y+dy};return null;}
 route(start,end,{limit=600000}={}){
  const goal=this.nearest(end.x,end.y);if(!goal)return null;const origin=this.nearest(Math.round(start.x),Math.round(start.y));if(!origin)return null;
  const key=(x,y)=>y*2160+x,source=key(origin.x,origin.y),target=key(goal.x,goal.y),score=new Map([[source,0]]),parent=new Map(),closed=new Set(),heap=[];
  const heuristic=(x,y)=>{const dx=Math.abs(x-goal.x);return Math.max(Math.min(dx,2160-dx),Math.abs(y-goal.y));};
  const push=(id,f)=>{let i=heap.length;heap.push({id,f});while(i){const p=(i-1)>>1;if(heap[p].f<=f)break;heap[i]=heap[p];i=p;heap[i]={id,f};}};
  const pop=()=>{const first=heap[0],last=heap.pop();if(heap.length){let i=0;heap[0]=last;for(;;){let a=i*2+1;if(a>=heap.length)break;let b=a+1,j=b<heap.length&&heap[b].f<heap[a].f?b:a;if(heap[j].f>=last.f)break;heap[i]=heap[j];i=j;heap[i]=last;}}return first.id;};
  push(source,heuristic(origin.x,origin.y));
  while(heap.length&&closed.size<limit){const id=pop();if(closed.has(id))continue;if(id===target){const path=[];let p=id;while(p!==source){const prev=parent.get(p);path.push({x:p%2160,y:Math.floor(p/2160),heading:prev.heading});p=prev.id;}return path.reverse();}closed.add(id);const x=id%2160,y=Math.floor(id/2160);
   for(let heading=0;heading<8;heading++){const [dx,dy]=DIRECTIONS[heading],nx=(x+dx+2160)%2160,ny=y+dy,n=key(nx,ny);if(closed.has(n)||!this.navigable(nx,ny))continue;if(dx&&dy&&(!this.navigable(nx,y)||!this.navigable(x,ny)))continue;const g=score.get(id)+(dx&&dy?1.414:1);if(g<(score.get(n)??Infinity)){score.set(n,g);parent.set(n,{id,heading});push(n,g+heuristic(nx,ny));}}
  }return null;
 }
}
export function townWalkable(map,limits,x,y){x=Math.floor(x);y=Math.floor(y);if(x<0||y<0||x>=95||y>=95)return false;const a=map[(y+1)*96+x],b=map[(y+1)*96+x+1];return a<limits[2]&&(b<limits[1]||b>=limits[2]&&b<limits[3]);}
export function townPath(map,limits,start,target){
 const key=p=>Math.round(p.y)*96+Math.round(p.x),source=key(start),end=key(target),queue=[source],prev=new Map([[source,null]]);
 for(let j=0;j<queue.length;j++){const n=queue[j];if(n===end){const path=[];let p=n;while(p!==source){path.push({x:p%96,y:Math.floor(p/96)});p=prev.get(p);}return path.reverse();}const x=n%96,y=Math.floor(n/96);for(const [dx,dy] of [[0,-1],[1,0],[0,1],[-1,0]]){const nx=x+dx,ny=y+dy,id=ny*96+nx;if(!prev.has(id)&&townWalkable(map,limits,nx,ny)){prev.set(id,n);queue.push(id);}}}return null;
}
