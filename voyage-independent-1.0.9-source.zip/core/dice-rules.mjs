// Independent game rules. No original executable, emulator, DOM, or key input.
// Korean rules: pair-count ranking; face 1 highest; lower pair compared first
// except a pair of ones. Original uninitialized/wrong-result branches are fixed.
const labels={0:'족보 없음',1:'원페어',2:'투페어',3:'트리플',4:'풀하우스',6:'포카드',10:'다섯 같은 눈'};
export function evaluateDice(faces){
 if(!Array.isArray(faces)||faces.length!==5||faces.some(d=>!Number.isInteger(d)||d<1||d>6))throw new RangeError('주사위는 1~6의 눈 다섯 개여야 합니다.');
 const counts=Array(7).fill(0);for(const face of faces)counts[face]++;
 const groups=counts.map((count,face)=>({face,count,strength:face===1?6:face-1})).filter(g=>g.count);
 const category=groups.reduce((sum,g)=>sum+g.count*(g.count-1)/2,0);
 let tiebreak=[];
 if(category===10||category===6||category===3)tiebreak=[groups.find(g=>g.count>=3).strength];
 else if(category===4)tiebreak=[groups.find(g=>g.count===3).strength,groups.find(g=>g.count===2).strength];
 else if(category===2||category===1)tiebreak=groups.filter(g=>g.count===2).map(g=>g.strength);
 return {category,name:labels[category],tiebreak};
}
export function compareScores(a,b){
 for(const [x,y] of [[a.category,b.category],...a.tiebreak.map((x,i)=>[x,b.tiebreak[i]])]){if(x!==y)return x>y?1:-1;}
 return 0;
}
export function compareDice(a,b){return compareScores(evaluateDice(a),evaluateDice(b));}
export function resolveDice(hands){
 if(!Array.isArray(hands)||hands.length!==3)throw new RangeError('참가자는 세 명입니다.');
 const scores=hands.map(evaluateDice);let best=0;
 for(let i=1;i<3;i++)if(compareScores(scores[i],scores[best])>0)best=i;
 const winners=scores.flatMap((s,i)=>compareScores(s,scores[best])===0?[i]:[]);
 const resultCode={'0':0,'1':1,'2':2,'1,2':3,'0,1,2':4,'0,1':5,'0,2':6}[winners.join(',')];
 return {scores,winners,resultCode};
}
export function dicePayout(stake,winners){
 if(!Number.isSafeInteger(stake)||stake<10||stake>500)throw new RangeError('판돈은 10~500입니다.');
 if(!Array.isArray(winners)||!winners.length||new Set(winners).size!==winners.length||winners.some(i=>![0,1,2].includes(i)))throw new RangeError('승자 목록이 올바르지 않습니다.');
 return winners.includes(0)?Math.trunc(3*stake/winners.length):0;
}
export function nextDiceStarter(current,winners){
 if(![0,1,2].includes(current)||!winners.length)throw new RangeError('차례가 올바르지 않습니다.');
 for(let step=0;step<3;step++){const candidate=(current+step)%3;if(winners.includes(candidate))return candidate;}
 throw new RangeError('승자가 없습니다.');
}
