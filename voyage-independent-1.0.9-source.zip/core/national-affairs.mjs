// Record fields are the Korean save layout. Rules: sphere-of-influence.md,
// friendship.md and buildings.md. No original executable is used at runtime.
const floor=Math.floor;
export const NATIONS=['포르투갈','에스파냐','오스만','잉글랜드','이탈리아','네덜란드','해적'];
export function refreshAllegiance(h){for(let p=0;p<100;p++){let c=6;for(let n=0;n<6;n++)if(h.get(13,p,8+n)>=75)c=n;h.set(12,p,19,(h.get(12,p,19)&248)|c);}}
export function sphere(h,data,nation){
 const groups=Array.from({length:8},()=>({economy:0,industry:0,ports:[],active:false,power:0}));
 for(const p of data.ports.slice(0,100)){const flags=h.get(12,p.id,19);if((flags&7)!==nation)continue;const g=groups[p.region];g.economy=(g.economy+h.get(13,p.id,0,2)*(flags&8?2:1))&65535;g.industry=(g.industry+h.get(13,p.id,4,2))&65535;g.ports.push(p.id);}
 const has=i=>groups[i].industry>=300;groups.forEach((g,i)=>{g.active=has(i)&&(i===3?(has(2)||has(4)):i>=5?Array.from({length:i-3},(_,j)=>j+4).every(has):true);g.power=g.active?floor(g.economy/[4,3,3,2,3,1,1,1][i]):0;});return groups;
}
export function monthlyNationalAffairs(h,data,rng){
 const own=h.state.protagonist,nation=h.get(3,own,49)&7,rank=h.get(1,own,13);
 if([4,10].includes(h.state.calendar.month))for(let i=0;i<20;i++){const item=h.get(6,0,63+i);if(item>=35&&item<=40)h.set(6,0,63+i,255);}
 let total=0;for(let n=0;n<6;n++){const power=sphere(h,data,n).reduce((s,g)=>s+g.power,0);h.set(0,n,0,power,2);total+=power;}h.set(0,6,0,floor(total/6),2);
 for(let n=0;n<7;n++){
  const profit=h.get(0,n,0,2),friend=h.get(1,own,6+n);let target=n===6?0:6,score=n===6?-Infinity:Infinity;
  for(let m=0;m<(n===6?6:7);m++){if(m===n)continue;const s=n===6?(100-h.get(0,n,11+m))*h.get(0,m,0,2):floor(h.get(0,m,0,2)*h.get(0,n,11+m)/100);if(n===6?s>score:s<score){score=s;target=m;}}
  if(100+rng(n===6?50:180-h.get(0,n,9))<Math.abs(200-friend)&&nation!==n)target=7;h.set(0,n,2,target);
  let mode;if(n===6)mode=target===7?7:8;else{const other=h.get(0,target===7?nation:target,0,2);mode=h.get(0,n,9)>rng(other>=profit?120:90)?(other>profit?4:5):rng(3);}h.set(0,n,3,mode);
  if(n<6){let eligible=[];for(let tries=0;tries<4&&!eligible.length;tries++){const t=target===7?nation:target;eligible=data.ports.slice(0,100).filter(p=>{const c=h.get(12,p.id,19)&7;return mode===0||mode===6?c===6:mode===1?c===n&&p.id!==h.get(0,n,10):mode===2?p.id>=75&&p.id<=92:mode===3?c===nation&&p.id!==h.get(0,nation,10):c===t&&p.id!==h.get(0,t,10);});if(!eligible.length)mode=mode===0?1:mode===1?2:0;}
   let selected;for(let round=0;selected===undefined&&round<100;round++)for(const p of eligible)if(rng(5)===0)selected=p.id;h.set(0,n,3,mode);h.set(0,n,4,selected??eligible[0]?.id??255);
  }
  if(friend>=130){const x=rank*profit;h.set(0,n,5,Math.min(100,h.get(0,n,5)+floor(x/3000)));h.set(0,n,6,Math.min(100,h.get(0,n,6)+floor(x/1000)));h.set(0,n,7,Math.min(7,floor(x/4000)));h.set(0,n,8,Math.min(255,h.get(0,n,8)+Math.min(10,floor(x/4000))));}else if(friend<70){for(const f of [5,6,8])h.set(0,n,f,0);h.set(0,n,7,255);}
 }
}
export function permitPrice(rank,own){return 10000*(own?(rank<6?7-rank:0):11-rank);}
export function grantDocument(h,nation,kind){
 const own=h.state.protagonist,rank=h.get(1,own,13),same=(h.get(3,own,49)&7)===nation,item=(kind==='permit'?35:29)+nation,inventory=h.inventory();
 if(nation>=6)throw new Error('국가의 왕궁을 방문해 주세요.');if(inventory.includes(item))throw new Error('이미 가지고 있는 문서입니다.');const slot=inventory.indexOf(255);if(slot<0)throw new Error('소지품 공간이 부족합니다.');
 let price=0;if(kind==='permit')price=permitPrice(rank,same);else{const fame=[0,2,4].map(f=>h.get(1,own,f,2));if(!same||fame[1]<1000||fame[1]<Math.max(fame[0],fame[2]))throw new Error('자국 왕궁에서 해적 명성 1,000 이상, 다른 명성 이상이어야 합니다.');}
 if(h.gold()<price)throw new Error('금화가 부족합니다.');h.setGold(h.gold()-price);h.set(6,0,63+slot,item);return {item,price};
}
export function collectRoyalGold(h,nation){if((h.get(3,h.state.protagonist,49)&7)!==nation)throw new Error('자국 왕궁에서 지원을 받을 수 있습니다.');const amount=h.get(0,nation,5)*1000;if(!amount)throw new Error('현재 받을 수 있는 지원금이 없습니다.');if(h.gold()+amount>600000000)throw new Error('소지금 한도를 초과합니다.');h.setGold(h.gold()+amount);h.set(0,nation,5,0);return amount;}
export const LESSONS=[{bit:16,port:10,name:'천문 항법',stats:{seamanship:80,knowledge:70,intuition:70}},{bit:4,port:35,name:'포술',stats:{leadership:75,knowledge:65,courage:80}}];
export function lessonPrice(charm){return Math.min(60000,100*(floor(5000/(floor(charm/5)+1))+200));}
export function learnSkill(h,port){const lesson=LESSONS.find(l=>l.port===port),c=h.captain(h.state.protagonist);if(!lesson)throw new Error('기술을 가르치는 저택을 방문해 주세요.');if(c.skills&lesson.bit)throw new Error('이미 배운 기술입니다.');if(Object.entries(lesson.stats).some(([key,n])=>c[key]<n))throw new Error('기술을 배우기 위한 능력이 부족합니다.');const price=lessonPrice(c.charm);if(h.gold()<price)throw new Error('금화가 부족합니다.');h.setGold(h.gold()-price);h.set(3,c.id,48,c.skills|lesson.bit);return lesson.name;}
