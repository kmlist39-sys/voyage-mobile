import {cargoUsed} from './economy.mjs';
const clamp=(v,a,b)=>Math.max(a,Math.min(v,b)),word=(a,n)=>a[n]|a[n+1]<<8;
export class GameRecords{
 constructor(data,state){this.data=data;this.state=state?structuredClone(state):{format:1,groups:structuredClone(data.initial.groups),calendar:{...data.initial.calendar},protagonist:0,port:0,text:{},ending:null,duelBalance:100,courses:{}};}
 snapshot(){return structuredClone(this.state);}
 numericReference(ref){const bases=[4358,4582,4666,4674,10674,11094,11604,null,11698,21008,22478,24104,24404,27004,30704,32368,32392,33092];const base=ref.group==='reserve'?22208:bases[ref.group];if(base===undefined||base===null)throw new Error('이 참조는 수치로 비교할 수 없습니다.');return (base+ref.offset)&65535;}
 reference(group,index,field){
  if(!Number.isInteger(index)||index<0||!Number.isInteger(field)||field<0)throw new RangeError('Invalid story record');
  if(group===7)return index<10?{group:8,offset:this.fleetId()*133+43+index*9+field}:{group:'reserve',offset:(index-10)*9+field};
  if(group===18)return {group:'discoveryText',offset:field,index};
  if(group===19)return {group:'goodsNames',offset:field,index};
  const g=this.state.groups[group];if(!g||index>=g.count&&![2,6].includes(group))throw new RangeError(`Record ${group}:${index} is out of range`);
  return {group,offset:([2,6].includes(group)?0:index*g.stride)+field};
 }
 checked(ref,width){const a=this.state.groups[ref.group]?.bytes;if(!a||ref.offset<0||ref.offset+width>a.length)throw new RangeError(`Invalid record field ${JSON.stringify(ref)}`);return a;}
 read(ref,width=1){if(ref.group==='goodsNames')return {group:'goodsText',index:ref.index,offset:0};const a=this.checked(ref,width);return width===1?a[ref.offset]:word(a,ref.offset);}
 write(ref,value,width=1){const a=this.checked(ref,width);a[ref.offset]=value&255;if(width===2)a[ref.offset+1]=value>>8&255;}
 get(group,index,field,width=1){return this.read(this.reference(group,index,field),width);}
 set(group,index,field,value,width=1){this.write(this.reference(group,index,field),value,width);}
 textKey(ref){return `${ref.group}:${ref.index??''}:${ref.offset}`;}
 writeText(ref,text){if(typeof text!=='string'||!ref)throw new TypeError('Invalid text write');this.checked(ref,1);this.state.text[this.textKey(ref)]=text;}
 readText(ref){
  if(ref.group==='goodsNames'||ref.group==='goodsText')return this.data.goods[ref.index]?.name??'';
  if(ref.group==='discoveryText')return this.data.discoveries[ref.index]?.name??'';
  if(this.state.text[this.textKey(ref)]!==undefined)return this.state.text[this.textKey(ref)];
  const a=this.checked(ref,1),end=a.indexOf(0,ref.offset);return new TextDecoder('euc-kr').decode(Uint8Array.from(a.slice(ref.offset,end<0?a.length:end)));
 }
 fleetId(){return this.get(3,this.state.protagonist,44);}
 captain(id){const b=(field)=>this.get(3,id,field);return {id,firstName:this.readText(this.reference(3,id,0)),lastName:this.readText(this.reference(3,id,13)),leadership:b(28),seamanship:b(29),knowledge:b(30),intuition:b(31),courage:b(32),swordplay:b(33),charm:b(34),luck:b(35),navigationLevel:b(36),battleLevel:b(37),navigationExperience:this.get(3,id,38,2),battleExperience:this.get(3,id,40,2),duty:b(46),skills:b(48),status:b(49)};}
 gold(){return (this.get(2,0,0,2)+this.get(2,0,2,2)*65536)>>>0;}
 setGold(value){const gold=clamp(Math.trunc(value),0,600000000);this.set(2,0,0,gold,2);this.set(2,0,2,gold>>>16,2);}
 get duelBalance(){return this.state.duelBalance;}
 set duelBalance(n){this.state.duelBalance=n;}
 system(id){const c=this.state.calendar;switch(id){case 1:return Math.floor(this.get(8,this.fleetId(),0,2)/24)+90*Math.floor(this.get(8,this.fleetId(),2,2)/24);case 2:return c.year-1501;case 3:return c.month-1;case 4:return c.day-1;case 5:return this.state.port;case 6:return this.state.duelBalance;case 7:return c.tick;default:throw new Error('Unknown system selector '+id);}}
 setProtagonist(id,{firstName,lastName,luck=50}={}){
  if(!Number.isInteger(id)||id<0||id>5)throw new RangeError('주인공을 선택해 주세요.');this.state.protagonist=id;this.set(2,0,7,id);
  this.set(3,id,35,clamp(luck,0,100));const fleet=this.fleetId();this.state.port=this.get(8,fleet,38);this.set(3,id,45,this.state.port);this.set(12,this.state.port,19,this.get(12,this.state.port,19)|0x50);
  this.set(8,fleet,41,0x31);this.set(8,fleet,26,8);
  if(firstName)this.writeText(this.reference(3,id,0),firstName);if(lastName)this.writeText(this.reference(3,id,13),lastName);
 }
 inventory(){return Array.from({length:20},(_,i)=>this.get(6,0,63+i));}
 mates(){return Array.from({length:30},(_,i)=>this.get(6,0,3+i)).filter(n=>n!==255);}
 ship(slot){
  if(slot<0||slot>=40)throw new RangeError('Invalid ship slot');const status=this.get(7,slot,8);if((status&0x30)!==0x10&&(status&0x30)!==0x20)return null;
  const instance=this.get(7,slot,7),type=this.get(10,instance,18),model=this.data.ships[type],captainId=this.get(9,slot,27),captain=captainId<120?this.captain(captainId):null;
  const supplies={water:this.get(9,slot,0,2),food:this.get(9,slot,2,2),lumber:this.get(9,slot,4,2),shot:this.get(9,slot,6,2),goods:Array.from({length:5},(_,i)=>({id:this.get(9,slot,22+i),quantity:this.get(9,slot,12+i*2,2)}))};
  const flags=this.get(10,instance,19);
  return {slot,instance,type,active:(status&0x30)===0x10,pending:(status&0x30)===0x20,name:this.readText(this.reference(10,instance,0)),crew:this.get(7,slot,0,2),durability:this.get(7,slot,2),maximumDurability:this.get(7,slot,3),tacking:this.get(7,slot,4),power:this.get(7,slot,5),guns:this.get(7,slot,6),gunType:status&7,gunSpace:this.get(10,instance,20),bunks:this.get(10,instance,21,2),capacity:model.capacity,maximumCargo:this.get(10,instance,23,2),sailType:model.sailType,minimumCrew:model.minimumCrew,oared:!(flags&16),stormWeak:!(flags&64),modelDurability:model.durability,captain,health:this.get(9,slot,28),figurehead:this.get(9,slot,29),lookoutPercent:this.get(9,slot,8),navigationPercent:this.get(9,slot,9),combatPercent:100-this.get(9,slot,8)-this.get(9,slot,9),load:cargoUsed(supplies),...supplies};
 }
 ships(){return Array.from({length:10},(_,i)=>this.ship(i)).filter(s=>s?.active);}
 writeShip(s){
  for(const [key,off,width] of [['crew',0,2],['durability',2,1],['maximumDurability',3,1],['tacking',4,1],['power',5,1],['guns',6,1]])if(s[key]!==undefined)this.set(7,s.slot,off,s[key],width);
  for(const [key,off,width] of [['water',0,2],['food',2,2],['lumber',4,2],['shot',6,2],['lookoutPercent',8,1],['navigationPercent',9,1],['health',28,1],['figurehead',29,1]])if(s[key]!==undefined)this.set(9,s.slot,off,s[key],width);
  if(s.goods)for(let i=0;i<5;i++){this.set(9,s.slot,22+i,s.goods[i].id);this.set(9,s.slot,12+i*2,s.goods[i].quantity,2);}
  const actual=this.ship(s.slot);this.set(9,s.slot,10,cargoUsed(actual),2);
 }
 freeCargo(){return this.ships().reduce((n,s)=>n+Math.max(0,s.maximumCargo-s.load),0);}
 loadGoods(id,quantity){
  if(!this.data.goods[id])throw new Error('Unknown quest goods');const ships=this.ships(),changes=[];let left=quantity;
  for(const s of ships){const i=s.goods.findIndex(g=>g.id===id),slot=i>=0?i:s.goods.findIndex(g=>g.id===255);if(slot<0)continue;const n=Math.min(left,Math.max(0,s.maximumCargo-s.load));s.goods[slot]={id,quantity:(i>=0?s.goods[slot].quantity:0)+n};left-=n;changes.push(s);if(!left)break;}
  if(left)throw new Error('퀘스트 화물을 실을 공간이 부족합니다.');changes.forEach(s=>this.writeShip(s));
 }
 unloadGoods(id,quantity){const ships=this.ships(),available=ships.reduce((n,s)=>n+s.goods.reduce((a,g)=>a+(g.id===id?g.quantity:0),0),0);if(!quantity)return available;let left=Math.min(quantity,available),removed=left;
  for(const s of ships){for(const g of s.goods)if(g.id===id){const n=Math.min(left,g.quantity);g.quantity-=n;left-=n;if(!g.quantity)g.id=255;}this.writeShip(s);if(!left)break;}return removed;
 }
 createPendingShip(type){
  const model=this.data.ships[type];if(!model)throw new Error('Unknown ship model');let slot=-1,instance=-1;
  for(let i=0;i<10;i++)if(!this.ship(i)){slot=i;break;}for(let i=0;i<40;i++)if(this.get(10,i,18)===255){instance=i;break;}
  if(slot<0||instance<0)throw new Error('새 배를 받을 공간이 없습니다.');
  const stats=[0,0,Math.floor(model.durability*.9),Math.floor(model.durability*.9),model.tacking,model.power,0,instance,0x20];stats.forEach((v,i)=>this.set(7,slot,i,v));
  for(let i=0;i<30;i++)this.set(9,slot,i,0);this.set(9,slot,8,25);this.set(9,slot,9,50);this.set(9,slot,27,this.state.port|128);this.set(9,slot,28,100);for(let i=0;i<5;i++)this.set(9,slot,22+i,255);
  for(let i=19;i<23;i++)this.set(10,instance,i,this.get(10,type+40,i));this.set(10,instance,18,type);
  this.set(10,instance,23,model.capacity-this.get(10,instance,20)-this.get(10,instance,21,2),2);this.set(13,this.state.port,35,0);
  return slot;
 }
 commissionShip(name,requestedSlot){
  const slot=Array.from({length:10},(_,i)=>this.ship(i)).find(s=>s?.pending&&(requestedSlot===undefined||s.slot===requestedSlot)&&this.get(9,s.slot,27)===(this.state.port|128));if(!slot)throw new Error('이 항구에서 인수할 배가 없습니다.');
  const id=this.state.protagonist,assigned=Array.from({length:10},(_,i)=>this.get(9,i,27)).includes(id),captain=!assigned?id:this.mates().find(n=>this.get(3,n,46)>2);
  if(captain===undefined)throw new Error('선장을 배치할 항해사가 없습니다.');
  this.set(9,slot.slot,27,captain);this.set(7,slot.slot,8,(this.get(7,slot.slot,8)&~32)|16);this.set(3,captain,46,captain===id?1:2);this.set(13,this.state.port,35,255);this.writeText(this.reference(10,slot.instance,0),name);
 }
 joinSailor(id){if(id===this.state.protagonist||this.mates().includes(id))return;const slot=Array.from({length:30},(_,i)=>i).find(i=>this.get(6,0,3+i)===255);if(slot===undefined)throw new Error('항해사 정원이 찼습니다.');
  this.set(6,0,3+slot,id);this.set(3,id,46,6);this.set(3,id,44,this.fleetId());this.set(3,id,45,this.state.port);
 }
 course(id){
  const order=this.get(8,id,27),target=this.get(8,id,28);let x,y;
  if(order<=3||order===9){x=this.get(12,target,0,2);y=this.get(12,target,2,2);}else{const fleet=order===4?this.fleetId():this.get(3,target,44);x=this.get(8,fleet,0,2);y=this.get(8,fleet,2,2);}
  this.set(8,id,4,x,2);this.set(8,id,6,y,2);this.state.courses[id]={order,target,x,y};
 }
 ending(id){this.state.ending={kind:'story',id};}
 format(text,variables){const p=this.captain(this.state.protagonist);return text.replace(/\$([ns])|\$([dr])([0-9]{2})/g,(token,name,kind,index)=>{
  if(name)return name==='n'?p.firstName:p.lastName;
  const v=variables[Number(index)];if(kind==='d')return Number.isInteger(v)?String(v):token;
  return v&&typeof v==='object'?this.readText(v):token;
 });}
}
