export function random(state,bound){
 if(!Number.isInteger(bound)||bound<0)throw new RangeError('Invalid random bound');if(bound===0)return 0;
 if(!Number.isInteger(state.rng)||state.rng<1||state.rng>0xffffffff)throw new RangeError('Invalid random state');
 const limit=Math.floor(0xffffffff/bound)*bound;let x;
 do{x=state.rng;x^=x<<13;x^=x>>>17;x^=x<<5;state.rng=x>>>0;x=state.rng-1;}while(x>=limit);
 return x%bound;
}
export function validateCommand(state,command){
 if(!command||typeof command.id!=='string'||!command.id)throw new TypeError('A command ID is required');
 if(state.receipts?.includes(command.id))return false;
 if(command.revision!==state.revision)throw new Error('이전 화면의 입력입니다.');return true;
}
export function commitCommand(state,id){state.revision++;state.receipts=[...(state.receipts??[]),id].slice(-128);}
