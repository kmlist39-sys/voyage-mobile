const distance=(a,b)=>Math.hypot(Math.min(Math.abs(a.x-b.x),2160-Math.abs(a.x-b.x)),a.y-b.y);
export class NavigationGraph {
 constructor(world,graph){this.world=world;this.graph=graph;this.attachments=new Map();this.routes=new Map();}
 attach(point){const pos=this.world.nearest(point.x,point.y);if(!pos)return null;const key=pos.y*2160+pos.x;if(this.attachments.has(key))return this.attachments.get(key);let result=null;
  for(const n of this.graph.nodes.map(n=>({n,d:distance(n,pos)})).sort((a,b)=>a.d-b.d).slice(0,12)){const route=this.world.route(pos,n.n,{limit:12000});if(route){result={id:n.n.id,path:[pos,...route]};break;}}
  if(this.attachments.size>512)this.attachments.clear();this.attachments.set(key,result);return result;
 }
 route(from,to){if(!this.graph)return this.world.route(from,to,{limit:20000});if(distance(from,to)<40){const direct=this.world.route(from,to,{limit:6000});if(direct)return direct;}
  const a=this.attach(from),b=this.attach(to);if(!a||!b)return null;const cache=a.id+':'+b.id;let ids=this.routes.get(cache);
  if(!ids){const scores=new Map([[a.id,0]]),parent=new Map(),open=new Set([a.id]),closed=new Set();while(open.size){let id=-1,score=Infinity;for(const n of open)if(scores.get(n)<score){id=n;score=scores.get(n);}open.delete(id);if(id===b.id)break;closed.add(id);for(const next of this.graph.nodes[id].edges){if(closed.has(next))continue;const edge=this.graph.edges[[id,next].sort((x,y)=>x-y).join(':')],s=score+edge.length;if(s<(scores.get(next)??Infinity)){scores.set(next,s);parent.set(next,id);open.add(next);}}}
   if(!scores.has(b.id))return null;ids=[b.id];while(ids[0]!==a.id)ids.unshift(parent.get(ids[0]));this.routes.set(cache,ids);}
  const route=[...a.path];for(let i=1;i<ids.length;i++){const x=ids[i-1],y=ids[i],edge=this.graph.edges[[x,y].sort((m,n)=>m-n).join(':')],list=x<y?edge:[...edge].reverse();route.push(...list.slice(1).map(k=>({x:k%2160,y:Math.floor(k/2160)})));}route.push(...[...b.path].reverse().slice(1));return route.slice(1).map((p,i,all)=>{const prev=i?all[i-1]:from,dx=p.x-prev.x,dy=p.y-prev.y;return {...p,heading:heading(dx,dy)};});
 }
}
function heading(dx,dy){dx=Math.sign(Math.abs(dx)>1080?-dx:dx);dy=Math.sign(dy);return [[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1]].findIndex(([x,y])=>x===dx&&y===dy);}
export {distance as seaDistance};
