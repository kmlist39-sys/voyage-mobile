export function generateSailor(h,data,id,nation,personality,rng){
 const names=data.sailors.filter(c=>(c.status&7)===nation),pool=names.length?names:data.sailors.slice(79),first=pool[rng(pool.length)]?.firstName??'항해사',last=pool[rng(pool.length)]?.lastName??'';
 let unique=first;for(let i=0;i<120;i++)if(i!==id&&h.captain(i).firstName===unique&&h.captain(i).lastName===last)unique=first+' '+(id+1);
 h.writeText(h.reference(3,id,0),unique);h.writeText(h.reference(3,id,13),last);h.set(3,id,26,0xc000|rng(0x3fff),2);
 for(let off=28;off<=35;off++)h.set(3,id,off,60+rng(35));for(const off of [36,37])h.set(3,id,off,Math.min(100,Math.max(8+rng(5),h.get(3,id,off)+2+rng(4))));h.set(3,id,38,0,2);h.set(3,id,40,0,2);h.set(3,id,42,20+rng(16));h.set(3,id,43,0);h.set(3,id,44,255);h.set(3,id,45,rng(42));h.set(3,id,46,0);h.set(3,id,47,rng(16)*16+personality);h.set(3,id,48,rng(16));h.set(3,id,49,nation|32);return id;
}
export function monthlySailors(h,data,rng){for(let id=6;id<120;id++){if(h.mates().includes(id))continue;const status=h.get(3,id,49);if(!(status&32)){if(rng(3)===0)generateSailor(h,data,id,rng(6),rng(3),rng);}else if(!(status&64)&&h.get(3,id,44)===255&&h.get(3,id,45)<100&&rng(3)===0)h.set(3,id,45,Math.max(0,Math.min(96,h.get(3,id,45)+rng(5)-2)));}}
