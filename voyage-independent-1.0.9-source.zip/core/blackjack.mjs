import {random,validateCommand,commitCommand} from './random.mjs';
export function cardTotal(cards){let sum=0,aces=0;for(const n of cards){const r=n%13;if(r===0){sum+=11;aces++;}else sum+=Math.min(10,r+1);}while(sum>21&&aces){sum-=10;aces--;}return sum;}
export function cardBonus(cards){if(cardTotal(cards)>21)return 1;const sorted=cards.toSorted((a,b)=>a-b),r=cards.map(n=>n%13);if(cards.length===2&&r.includes(0)&&r.some(n=>n>=10))return cards.includes(0)&&cards.includes(10)?6:3;if(cards.length===3&&(r.every(n=>n===6)||cardTotal(cards)===21&&sorted[1]===sorted[0]+1&&sorted[2]===sorted[1]+1))return 4;if(cards.length>=5)return 4;return 2;}
export function createBlackjack({gold,seed=1}){const s={version:1,revision:0,receipts:[],rng:seed,gold,round:0,phase:'betting',stake:0,deck:[],player:[],dealer:[],result:null};deal(s);return s;}
function deal(s){s.round++;s.deck=Array.from({length:52},(_,i)=>i);for(let i=0;i<208;i++){const a=random(s,52),b=random(s,52);[s.deck[a],s.deck[b]]=[s.deck[b],s.deck[a]];}s.player=[s.deck.pop()];s.dealer=[s.deck.pop()];s.stake=0;s.phase=s.gold>=10?'betting':'closed';s.result=null;}
function settle(s){while(cardTotal(s.dealer)<17&&s.dealer.length<6)s.dealer.push(s.deck.pop());const a=cardTotal(s.player),b=cardTotal(s.dealer),won=a<=21&&(b>21||a>b),factor=cardBonus(won?s.player:s.dealer),before=s.gold;
 if(won)s.gold=Math.min(600000000,s.gold+s.stake*factor);else s.gold=Math.max(0,s.gold-s.stake*Math.max(0,factor-2));s.result={won,player:a,dealer:b,net:s.gold-before-s.stake,multiplier:factor};s.phase='settled';}
export function blackjackCommand(state,c){if(!validateCommand(state,c))return state;const s=structuredClone(state);
 if(c.type==='EXIT'&&['betting','settled','closed'].includes(s.phase))s.phase='closed';
 else if(s.phase==='betting'&&c.type==='BET'){if(!Number.isInteger(c.amount)||c.amount<10||c.amount>Math.min(500,s.gold))throw new Error('판돈은 10~500 금화입니다.');s.stake=c.amount;s.gold-=s.stake;s.player.push(s.deck.pop());s.dealer.push(s.deck.pop());s.phase='choice';}
 else if(s.phase==='choice'&&c.type==='HIT'){s.player.push(s.deck.pop());if(cardTotal(s.player)>21||s.player.length>=7)settle(s);}
 else if(s.phase==='choice'&&c.type==='STAND')settle(s);
 else if(s.phase==='settled'&&c.type==='NEXT')deal(s);else throw new Error('지금 선택할 수 없는 카드 행동입니다.');commitCommand(s,c.id);return s;}
