import {movementCost,turningRate,movementPoints,GUNS} from './combat-rules.mjs';
export const HEX_DIRECTIONS=[[0,-1],[1,-1],[1,0],[0,1],[-1,1],[-1,0]];
export function axial({x,y}){return {q:x,r:y-(x-(x&1))/2};}
export function offset({q,r}){return {x:q,y:r+(q-(q&1))/2};}
export function hexStep(p,direction){const a=axial(p),d=HEX_DIRECTIONS[direction];if(!d)throw new RangeError('Invalid hex heading');return offset({q:a.q+d[0],r:a.r+d[1]});}
export function hexDistance(a,b){a=axial(a);b=axial(b);const q=b.q-a.q,r=b.r-a.r;return Math.max(Math.abs(q),Math.abs(r),Math.abs(q+r));}
export function broadside(source,target,heading){
 const a=axial(source),b=axial(target),q=b.q-a.q,r=b.r-a.r;if(!q&&!r)return false;
 for(const side of [1,4]){const u=HEX_DIRECTIONS[(heading+side)%6],v=HEX_DIRECTIONS[(heading+side+1)%6],det=u[0]*v[1]-u[1]*v[0];const n=(q*v[1]-r*v[0])/det,m=(u[0]*r-u[1]*q)/det;if(n>=0&&m>=0)return true;}return false;
}
export function attackKind(source,target){
 if(source.side===target.side||source.team===target.team||source.left||target.left||source.crew<=0||target.crew<=0||source.durability<=0||target.durability<=0)return null;
 const distance=hexDistance(source,target);if(distance===1)return 'boarding';
 return source.shot>0&&source.guns>0&&distance>=2&&distance<=(GUNS[source.gunType]?.range??0)&&broadside(source,target,source.heading)?'cannon':null;
}
export function plotCourse(unit,directions,{width=52,height=48,wind,units=[],land=()=>false}={}){
 if(!Array.isArray(directions)||directions.length>10)throw new RangeError('이동 경로는 10칸까지 지정할 수 있습니다.');
 let position={x:unit.x,y:unit.y},heading=unit.heading,charge=unit.turnCharge??0,remaining=movementPoints({...unit.captain,power:unit.power,wind:wind.speed});const path=[];
 const rate=turningRate({...unit.captain,tacking:unit.tacking});
 for(const direction of directions){
  if(!Number.isInteger(direction)||direction<0||direction>5)throw new RangeError('Invalid hex heading');const delta=(direction-heading+6)%6;
  if(![0,1,5].includes(delta))throw new RangeError('한 번에 60도씩 방향을 바꿀 수 있습니다.');
  charge=Math.min(100,charge+rate);if(delta&&charge<50)throw new RangeError('방향을 바꾸려면 더 전진해야 합니다.');
  const gap=Math.abs(direction-wind.direction),weight=Math.min(gap,6-gap)+1,cost=movementCost({power:unit.power,tacking:unit.tacking,heading,direction,weight});
  if(cost>remaining)throw new RangeError('이동력이 부족합니다.');const next=hexStep(position,direction);
  if(next.x<0||next.y<0||next.x>=width||next.y>=height||land(next.x,next.y)||units.some(u=>u.id!==unit.id&&!u.left&&u.durability>0&&u.x===next.x&&u.y===next.y))throw new RangeError('이 칸으로 이동할 수 없습니다.');
  remaining-=cost;if(delta)charge=0;heading=direction;position=next;path.push({...position,heading,remaining,turnCharge:charge});
 }
 return {...position,heading,remaining,turnCharge:charge,path};
}
export function reachableCourses(unit,board){
 const routes=new Map(),seen=new Map(),queue=[[]];let visits=0;
 while(queue.length){if(++visits>20000)throw new Error('Battle reachability budget exceeded');const directions=queue.shift(),p=plotCourse(unit,directions,board),key=`${p.x},${p.y}`;
  if(directions.length&&(!routes.has(key)||routes.get(key).remaining<p.remaining))routes.set(key,{...p,directions});
  const exact=`${key},${p.heading},${p.turnCharge}`;if((seen.get(exact)??-1)>=p.remaining)continue;seen.set(exact,p.remaining);
  if(directions.length===10)continue;
  for(const d of [p.heading,(p.heading+1)%6,(p.heading+5)%6]){const list=[...directions,d];try{plotCourse(unit,list,board);queue.push(list);}catch(e){if(!(e instanceof RangeError))throw e;}}
 }
 return [...routes.values()];
}
