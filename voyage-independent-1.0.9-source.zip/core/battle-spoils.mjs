import {hexDistance} from './battle-grid.mjs';
import {distance} from './realtime-battle.mjs';
export function battleSpoils(battle,host,models,draw){const fleet=battle.fleet,player=battle.units.find(u=>u.id===battle.player),survivors=battle.units.filter(u=>u.team===1&&u.main&&u.durability>0&&!u.left),candidates=survivors.filter(u=>(battle.realtime?distance(player,u):hexDistance(player,u))<=12);const result={fleet,candidates:structuredClone(candidates),supplies:{water:0,food:0,lumber:0,shot:0},goods:{id:host.get(8,fleet,33),quantity:host.get(8,fleet,34,2)},gold:(host.get(8,fleet,36,2)+1)*100,item:host.get(8,fleet,29)};
 if(!candidates.length){result.goods.quantity=0;return result;}
 const capacity=candidates.reduce((n,u)=>n+host.get(10,40+u.type,23,2),0);
 if(result.goods.id<46)result.goods.quantity=Math.floor(result.goods.quantity*candidates.length/Math.max(1,survivors.length));
 else if(fleet%10>=1&&fleet%10<=4&&draw(2)===0){const ordinary=draw(10)!==0;result.goods={id:(ordinary?10:26)+draw(ordinary?6:7),quantity:ordinary?Math.floor(capacity/5):Math.floor(Math.floor(capacity/4)/5)};}else result.goods={id:255,quantity:0};
 const share=Math.floor(result.goods.quantity/candidates.length);for(const u of candidates){const shot=Math.max(0,u.shot),free=Math.max(0,host.get(10,40+u.type,23,2)-shot-share);result.supplies.water+=Math.floor((30+draw(5))*free/100);result.supplies.food+=Math.floor((30+draw(5))*free/100);result.supplies.lumber+=Math.floor((2+draw(2))*free/100);result.supplies.shot+=shot;}
 return result;
}
export function captureShip(host,loot,slot,name){const candidate=loot.candidates.find(u=>u.slot===slot);if(!candidate)throw new Error('나포할 배를 선택해 주세요.');name=String(name??'').trim().slice(0,30);if(!name)throw new Error('배 이름을 입력해 주세요.');const free=host.mates().find(id=>!host.ships().some(s=>s.captain.id===id));if(free===undefined)throw new Error('선장으로 배치할 항해사가 없습니다.');const port=host.state.port,constructionDays=host.get(13,0,35);host.state.port=0;let assigned;try{assigned=host.createPendingShip(candidate.type);host.commissionShip(name,assigned);}finally{host.state.port=port;host.set(13,0,35,constructionDays);}
 const ship=host.ship(assigned);host.writeShip({...ship,crew:Math.min(Math.floor(candidate.crew/10),ship.bunks),durability:candidate.durability,maximumDurability:candidate.maximumDurability,tacking:candidate.tacking,power:candidate.power,guns:candidate.guns,health:60});host.set(7,assigned,8,16|candidate.gunType);loot.candidates=loot.candidates.filter(s=>s.slot!==slot);return host.ship(assigned);
}

