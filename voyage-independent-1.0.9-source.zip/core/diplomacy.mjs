const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function diplomaticClass(h,target){const home=h.get(3,h.state.protagonist,49)&7;if(home>=6||target>=6||!h.inventory().includes(29+home))return 0;const r=h.get(0,home,11+target);let c=1;if(r<=40)c=2;if(h.get(0,target,18+home)&16)c=3;if(h.get(0,home,2)===target)c=4;if(r>=60)c=5;if(h.get(0,home,18+target)&32)c=6;return c;}
export function battleDiplomacy(g,fleet,outcome,rng){if(![2,4,6,8].includes(outcome))return;const h=g.host,own=g.captain.id,home=g.nation,target=Math.floor(fleet/10);if(target===6){if(home<6)h.set(1,own,6+home,Math.min(200,h.get(1,own,6+home)+5+rng(5)));return;}if(home>=6)return;
 const relation=Math.max(0,h.get(0,home,11+target)-3-rng(5));h.set(0,home,11+target,relation);h.set(0,target,11+home,relation);const cls=diplomaticClass(h,target),mult=[1,1,2,3,4,-1,-1][cls],scale=[30,30,10,6,3,90,60][cls];h.set(1,own,6+target,Math.max(0,h.get(1,own,6+target)-Math.floor(scale*(10+rng(5))/30)));
 if(home!==target)h.set(1,own,6+home,clamp(h.get(1,own,6+home)+mult*(5+rng(5)),0,200));else{const next=Math.max(0,h.get(1,own,6+home)-10-rng(5));h.set(1,own,6+home,next);if(next<=40||next<=70&&g.rank){h.set(1,own,13,0);const q=g.director.state.shared;q.section=0;q.subsection=0;q.flags&=~(7<<16);if(next<=40){h.set(3,own,49,(g.captain.status&248)|6);g.log('조국에서 추방당했습니다. 작위를 잃었습니다.');}else g.log('불명예로 작위를 박탈당했습니다.');}}
}
export function hostileEntry(g,building,rng){const nation=g.port.controller;if(nation>=6||![0,1,2,4,5,6,8,9,11].includes(building))return false;const h=g.host,own=g.captain.id,friend=h.get(1,own,6+nation),palace=building===5;if(palace?friend>80||rng(100)<=friend:friend>=80||rng(3)!==0||rng(100)<=friend+20)return false;
 const c=g.captain,escape=c.swordplay+Math.floor(c.swordplay*c.battleLevel/100)>=rng(150);if(!escape){h.setGold(Math.trunc(h.gold()/(palace?5:4)));if(palace)g.balance=Math.trunc(g.balance/5);h.set(1,own,6+nation,palace?100:Math.min(200,friend+20));}
 g.state.building=null;g.log(escape?'적대국의 추격을 피해 무사히 빠져나왔습니다.':palace?'왕궁에서 체포되어 소지금과 은행 잔액의 4/5를 압수당했습니다.':'적대 세력에 붙잡혀 소지금의 3/4를 잃었습니다.');return true;
}
export function monthlyRelations(h,rng){
 for(let i=0;i<6;i++)for(let j=0;j<6;j++){const r=h.get(0,i,11+j),a=h.get(0,i,0,2),b=h.get(0,j,0,2),tier=a>b*2?0:b>a*2?1:a>b?2:3,flags=h.get(0,i,18+j)&48,band=r<=30?0:r<=70?1:2;let value;
  if(flags&32)value=[[0,1,0,1],[6,1,6,0],[6,6,6,6]][band][tier];else if(flags&16)value=band===0?3:tier===0?4:band===1&&tier!==2||band===2&&tier===1?3:rng(100)<r?3:0;
  else if(band===0)value=[0,5,1,5][tier];else if(band===1)value=30+rng(tier===0||tier===2?20:10)>r?2:0;else value=tier===0?2:tier===1?1:rng(100)>r?2:0;h.set(0,i,18+j,flags|value);
  if((flags|value)===1){const next=Math.min(110,h.get(0,j,11+i)+3+rng(5));h.set(0,i,11+j,next);h.set(0,j,11+i,next);}
 }
}
