const floor=Math.floor;
const integer=(n,min,max)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
function fields(p,limits){for(const [key,max] of Object.entries(limits))if(!integer(p[key],0,max))throw new RangeError('Invalid combat field '+key);}
export function movementPoints(p){fields(p,{power:100,seamanship:100,navigationLevel:100,wind:8});const a=floor(p.power*p.wind*8/150)+20,b=floor(a*p.seamanship/100);return Math.max(10,Math.min(25,b+floor(p.navigationLevel*b/15)));}
export function turningRate(p){fields(p,{tacking:100,seamanship:100,navigationLevel:100});const a=floor(p.tacking*p.seamanship/200);return Math.min(100,a+floor(p.navigationLevel*a/15));}
export function movementCost(p){fields(p,{power:100,tacking:100,weight:4,heading:5,direction:5});return p.heading===p.direction?floor(p.power*p.weight/100)+5:p.weight>=3?10-floor(5*p.tacking/100):5;}
export function boardingFactor({swordplay,battleLevel,primary=true}){fields({swordplay,battleLevel},{swordplay:100,battleLevel:100});return floor((floor(swordplay*battleLevel/100)+floor(swordplay/2))*(primary?3:2)/3);}
export function boardingKills(p,random,{legacyOverflow=true}={}){
 fields(p,{crew:500,combatPercent:100,boardingFactor:150,swordplay:100});
 const fighting=floor((p.crew+random(10))*p.combatPercent/100),x=floor(p.boardingFactor*fighting/100),product=x*(50+random(floor(p.swordplay/2)));
 return Math.max(1,Math.min(50,floor((legacyOverflow?product&65535:product)/100)));
}
export function cannonDamage(p,random){
 fields(p,{crew:500,combatPercent:100,guns:150,leadership:100,battleLevel:100,swordplay:100,firepower:200});
 const ownLevel=p.ownBattleLevel??p.battleLevel;
 if(!integer(ownLevel,0,100))throw new RangeError('Invalid captain level');
 const ability=floor(p.battleLevel*p.leadership/100)+floor(p.leadership/2);
 const guns=Math.min(floor(p.guns/2),floor(floor(p.crew*p.combatPercent/100)/2));
 const y=floor(guns*p.firepower/10),z=floor(Math.ceil(y/(p.gunnery?20:40))*ability/100)&65535;
 const power=floor(z*(50+random(floor(p.swordplay/2)))/100),cap=50+random(floor(ownLevel/2));
 return Math.max(1,Math.min(power,cap));
}
export const GUNS=[{name:'없음',range:0,strength:0},{name:'캐논',range:3,strength:20},{name:'데미캐논',range:2,strength:14},{name:'캐논 페드로',range:2,strength:10},{name:'컬버린',range:5,strength:10},{name:'데미컬버린',range:5,strength:4},{name:'세이커',range:2,strength:4},{name:'캐로네이드',range:5,strength:20}];
export function firepower(type,distance){const g=GUNS[type];return g&&integer(distance,2,g.range)?g.strength*(12-distance):0;}
export function duelDamage(p,random,{legacyNegation=true}={}){
 fields(p,{swordplay:100,battleLevel:100,defenderLevel:100,weapon:40,family:3,armor:70,attack:2,defense:2,previousAttack:2,previousDefense:2});
 const base=floor(p.swordplay/2)+floor(p.swordplay*p.battleLevel/50);
 const scale=25*p.attack+(p.weapon>=1?50:0)+(p.family===p.attack+1?p.weapon:0);
 const power=floor(floor((base+p.weapon)*(4-p.previousAttack)/4)*scale/100);
 const defense=p.armor+Math.min(p.defenderLevel,20)+5*(2-p.defense);
 const damage=Math.min(50,Math.trunc((100-defense)*power/100))+random(floor(p.battleLevel/2));
 let negation=2*(2*p.defense+5)*(4-p.previousDefense)-floor(p.armor/2);
 negation=legacyNegation?negation&65535:Math.max(0,negation);
 return negation>=random(100)?0:damage;
}
export function npcDuelEquipment(navigationLevel,battleLevel){
 fields({navigationLevel,battleLevel},{navigationLevel:100,battleLevel:100});
 const armor=navigationLevel<8?20:navigationLevel<16?30:40;
 let weapon,family;
 if(battleLevel<16){weapon=battleLevel<8?15:20;family=2;}
 else if(battleLevel<24){weapon=25;family=0;}
 else {const n=navigationLevel%3;weapon=n===2?30:25;family=n===0?1:3;}
 return {armor,weapon,family};
}
export function npcDuelMove({attacking,family,armor},roll){
 if(!integer(roll,0,9))throw new RangeError('Invalid move roll');
 const [low,high]=attacking?([[3,6],[6,7],[2,7],[2,3]][family]??[3,6]):armor>=60?[6,7]:armor>=20?[2,7]:[2,3];
 return roll<low?0:roll>high?2:1;
}
export function challengeChance(playerCrew,enemyCrew,luck){
 fields({playerCrew,enemyCrew,luck},{playerCrew:500,enemyCrew:500,luck:100});
 return playerCrew>=enemyCrew?1:luck===0?0:Math.max(0,(luck-(enemyCrew-playerCrew))/luck);
}
