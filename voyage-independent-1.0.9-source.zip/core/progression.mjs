const floor=Math.floor;
export function experienceThreshold(level){return 30*Math.min(level,18)**2;}
export function voyageExperience(days,duty){return duty>=1&&duty<=3?2*Math.min(days,70)**2:Math.min(days,100)**2;}
export function gainExperience(captain,type,amount,random){
 if(!['navigation','battle'].includes(type)||!Number.isInteger(amount)||amount<0)throw new RangeError('Invalid experience award');
 const next={...captain},level=type+'Level',xp=type+'Experience';let gained=0;next[xp]=(next[xp]+amount)&65535;
 while(next[xp]>=experienceThreshold(next[level])){const threshold=experienceThreshold(next[level]);if(next[level]===100){next[xp]=0;break;}next[xp]-=threshold;next[level]++;gained++;}
 if(gained){for(const stat of ['leadership','seamanship','knowledge','intuition'])next[stat]=Math.min(100,next[stat]+random(3));
  if(type==='navigation')for(const stat of ['leadership','seamanship','knowledge'])next[stat]=Math.min(100,next[stat]+random(3));
  else for(let i=0;i<gained;i++){next.courage=Math.min(100,next.courage+random(3));next.swordplay=Math.min(100,next.swordplay+random(2));}
 }
 return {captain:next,levels:gained};
}
export function piracyFame(enemyLevel,outcome,diplomaticClass,playerNation){if(![2,4,6].includes(outcome))return 0;const result=outcome===2?1:3,diplomacy=playerNation===6?3:[2,3,4].includes(diplomaticClass)?diplomaticClass:1;return 200+result*diplomacy*Math.min(enemyLevel,15)*Math.min(enemyLevel,30);}
export function discoveryReward(difficulty,percentage=100){return {fame:difficulty===100?1500:difficulty*8,gold:floor((difficulty===100?100000:difficulty*250)*percentage/100)};}
