import {random} from './random.mjs';

// A hostile approach is a saved decision, not a battle launched during a tick.
export function requestHostileEncounter(g,fleet){
 const s=g.state;
 if(s.mode!=='sea'||s.wait||s.encounter||s.spoils||s.sea.cooldown>0)return false;
 const other=g.nearbyFleets().find(f=>f.id===fleet),enemy=g.npcShips(fleet);
 if(!other||!enemy.length)return false;
 const speed=ships=>Math.min(...ships.map(u=>u.power*.65+u.tacking*.35));
 const chance=Math.round(Math.max(15,Math.min(90,50+(speed(g.ships)-speed(enemy))*.5+(g.captain.seamanship-g.host.captain(other.captain).seamanship)*.3)));
 s.encounter={fleet,captain:other.captain,phase:'challenge',chance,text:'적 함대가 진로를 가로막고 전투를 요구합니다. 어떻게 대응하시겠습니까?'};
 s.sea.heading=8;s.sea.route=[];s.sea.target=null;
 g.log(g.host.captain(other.captain).firstName+' 함대가 교전을 요구합니다.');
 return true;
}

export function encounterCommand(g,c){
 if(c.type!=='ENCOUNTER_REPLY')return false;
 const s=g.state,e=s.encounter;
 if(!e||s.mode!=='sea')throw new Error('응답할 교전 통보가 없습니다.');
 if(e.phase==='challenge'&&c.action==='fight'){
  s.encounter=null;g.encounter(e.fleet);
 }else if(e.phase==='challenge'&&c.action==='flee'){
  const escaped=random(s,100)<e.chance;
  e.phase=escaped?'escaped':'pursuit';
  e.text=escaped?'돛을 펼쳐 적의 추격을 따돌렸습니다. 함선과 물자를 보존한 채 항해를 계속합니다.':'적 함대가 퇴로를 차단했습니다. 전투 중 바다 가장자리의 이탈 경계까지 이동하면 다시 도주할 수 있습니다.';
  if(escaped)s.sea.cooldown=144;
  g.log(e.text);
 }else if(c.action==='continue'&&e.phase!=='challenge'){
  s.encounter=null;if(e.phase==='pursuit')g.encounter(e.fleet);
 }else throw new Error('현재 통보에 맞는 응답을 선택해 주세요.');
 return true;
}
