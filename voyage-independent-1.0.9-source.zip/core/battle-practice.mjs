import {VoyageGame} from './game.mjs';
import {createBattle} from './naval-battle.mjs';
import {realtimeBattle} from './realtime-battle.mjs';

// Practice has its own records and never commits battle damage to a voyage.
class PracticeGame extends VoyageGame {
  finishBattle() {
    this.state.practice.result = this.state.battle.outcome;
    this.state.battle.finishDelay = undefined;
    this.state.battle.phase = 'finished';
  }
  get ships() {
    return this.state.battle?.units.filter(u => u.team === 0) ?? super.ships;
  }
}

export function createBattlePractice(data, {captainId = 0, shipName = '연습 기함'} = {}) {
  const g = new PracticeGame(data);
  g.start(captainId);
  for (const field of [28,29,30,31,32,33,34,35]) g.host.set(3,captainId,field,90);
  g.host.set(3,captainId,36,50);
  g.host.set(3,captainId,37,50);
  const opponent = captainId === 2 ? 0 : 2;
  g.host.set(3,opponent,37,10);
  const common = {slot:0,type:10,side:0,main:true,flagship:true,heading:2,
    power:90,tacking:90,bunks:500,maximumCrew:500,modelDurability:80,
    combatPercent:50,oared:false,water:50000,food:50000,health:100};
  const units = [
    {...common,id:'practice-player',team:0,x:20,y:24,name:shipName,
      crew:500,durability:10000,maximumDurability:10000,guns:40,gunType:4,shot:1000,captain:g.captain},
    {...common,id:'practice-flagship',team:1,side:1,x:26,y:24,name:'훈련 대장선',
      crew:150,durability:600,maximumDurability:600,guns:4,gunType:5,shot:1000,
      trainingTarget:true,captain:g.host.captain(opponent)}
  ];
  const b = realtimeBattle(createBattle({units,player:units[0].id,seed:107,tick:24}));
  b.practice = true;
  b.target = units[1].id;
  b.units[0].angle = b.units[0].aim = 0;
  b.units[1].angle = b.units[1].aim = Math.PI;
  b.units[1].reload = 5;
  Object.assign(g.state,{mode:'battle',building:null,wait:null,afterStory:null,
    battle:b,duel:null,gambling:null,spoils:null,cinematic:null,
    practice:{captainId,shipName,result:null}});
  return g;
}
