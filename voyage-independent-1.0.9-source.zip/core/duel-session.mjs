import {duelDamage,npcDuelMove} from './combat-rules.mjs';import {random,validateCommand,commitCommand} from './random.mjs';
export const ATTACKS=['찌르기','베기','내려치기'],DEFENSES=['받아넘기기','막기','피하기'];
export function createDuel({challenger,defender,player=0,balance=100,seed=1}){
 if(![0,1].includes(player)||!Number.isInteger(balance)||balance<0||balance>200)throw new RangeError('Invalid duel');
 const s={version:1,revision:0,receipts:[],rng:seed,combatants:structuredClone([challenger,defender]),player,balance,exchange:0,history:[1,1],npcMove:null,phase:balance===0||balance===200?'finished':'choice',result:null,log:[]};
 if(s.phase==='finished')s.result=balance===200?0:1;else prepare(s);return s;
}
function prepare(s){const other=1-s.player,attacking=s.exchange%2===other;s.npcMove=npcDuelMove({attacking,family:s.combatants[other].family,armor:s.combatants[other].armor},random(s,10));}
export function duelActions(s){return s.phase==='choice'?(s.exchange%2===s.player?ATTACKS:DEFENSES).map((label,move)=>({type:'MOVE',label,move})):[];}
export function applyDuelCommand(state,command){
 if(!validateCommand(state,command))return {state,events:[]};
 if(state.phase!=='choice'||command.type!=='MOVE'||!Number.isInteger(command.move)||command.move<0||command.move>2)throw new Error('일기토 동작을 선택해 주세요.');
 const s=structuredClone(state),attacker=s.exchange%2,defender=1-attacker,choices=[];choices[s.player]=command.move;choices[1-s.player]=s.npcMove;
 const a=s.combatants[attacker],d=s.combatants[defender];
 const damage=duelDamage({swordplay:a.swordplay,battleLevel:a.battleLevel,defenderLevel:d.battleLevel,weapon:a.weapon,family:a.family,armor:d.armor,attack:choices[attacker],defense:choices[defender],previousAttack:s.history[attacker]&3,previousDefense:s.history[defender]&3},n=>random(s,n));
 const applied=Math.min(Math.max(0,damage),attacker===0?200-s.balance:s.balance);s.balance+=attacker===0?applied:-applied;
 for(let i=0;i<2;i++)s.history[i]=(s.history[i]*4+choices[i])&255;
 const event={type:'DUEL_EXCHANGE',exchange:s.exchange,attacker,attack:choices[attacker],defense:choices[defender],damage:applied,balance:s.balance};s.log.push(event);s.exchange++;
 const events=[event];
 if(s.balance===0||s.balance===200||s.exchange===20){s.phase='finished';s.result=s.balance===200?0:s.balance===0?1:null;s.npcMove=null;events.push({type:'DUEL_ENDED',winner:s.result,balance:s.balance,timeout:s.result===null});}
 else prepare(s);
 commitCommand(s,command.id);return {state:s,events};
}
