const trunc=Math.trunc,clamp=(n,a,b)=>Math.max(a,Math.min(n,b)),s16=n=>(n<<16)>>16,s8=n=>(n<<24)>>24;
export const WIND_TABLE=[[10,8,10,9,9,8,10,10],[10,9,10,10,10,10,10,10],[8,9,10,10,10,10,10,10],[6,7,8,9,9,10,9,10],[4,6,6,7,7,8,9,10],[6,7,8,9,9,10,9,10],[8,9,10,10,10,10,10,10],[10,9,10,10,10,10,10,10]];
export const DIRECTIONS=[[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1]];
export function shipSpeed(s,wind,heading,{legacyOverflow=false}={}){
 if(s.minimumCrew<=0||s.capacity<=0||!DIRECTIONS[heading]||!DIRECTIONS[wind.direction])throw new RangeError('Invalid navigation input');
 const row=Math.abs(wind.direction-heading),w=s.oared?Math.max(3,wind.speed):wind.speed;
 let f=trunc(s16(WIND_TABLE[row][s.sailType]*s.power*w)/150)&255;
 f=trunc(f*Math.min(100,trunc(s.navigationPercent*s.crew/s.minimumCrew))/100)&255;
 const factor=legacyOverflow?Math.min(150,(trunc(s16(-100*s.load)/s.capacity)+180)&65535):clamp(180-trunc(100*s.load/s.capacity),0,150);
 f=trunc(f*factor/100)&255;f=Math.min(30,f+trunc(f*s.captain.navigationLevel/10));f=Math.min(40,trunc(f*s.captain.seamanship/75));
 return row>=3&&row<=5?trunc(s.tacking*f/100):f;
}
export function fleetSpeed(ships,wind,heading,options){
 if(!ships.length||heading===8||(wind.speed===0&&!ships.some(s=>s.oared)))return 0;
 return Math.max(2,Math.min(...ships.map(s=>shipSpeed(s,wind,heading,options))));
}
export function hullBlocked(x,y,tile){return tile(x,y)>=0x34||tile(x+1,y)>=0x34||tile(x,y+1)>=0x34||tile(x+1,y+1)>=0x34;}
// Faithful 16-bit movement for differential analysis. legacyPoleWrap exposes an
// observed south-edge bug; production uses a bounded latitude instead.
export function moveStep(p,blocked,{legacyPoleWrap=false}={}){
 if(p.heading===8)return {blocked:false,boundary:false,result:{x:p.x,y:p.y,accumulatorX:p.accumulatorX,accumulatorY:p.accumulatorY}};
 const [dx,dy]=DIRECTIONS[p.heading],[cx,cy]=DIRECTIONS[p.currentDirection];
 const vx=dx*p.speed+cx*p.currentSpeed,vy=dy*p.speed+cy*p.currentSpeed;
 let ax=s8(p.accumulatorX+vx),ay=s8(p.accumulatorY+vy);
 const sx=ax>=60?1:ax<0?-1:0,sy=ay>=60?1:ay<0?-1:0,oldX=p.x%720;
 let x=oldX+sx,y=p.y+sy,boundary=false;
 if(!sx&&!sy)return {blocked:false,boundary:false,result:{x:p.x,y:p.y,accumulatorX:ax&255,accumulatorY:ay&255}};
 if(x<0||x>=719){x+=Math.sign(vx);y=p.y;boundary=true;}
 if(y<0||y>=1079){
  x=oldX;
  if(y>=0&&y<1080&&legacyPoleWrap){y+=Math.sign(vy);boundary=true;}
  else y=p.y;
 }
 const absoluteX=x+Math.floor(p.x/720)*720;
 if(!boundary&&blocked(absoluteX,y)){
  if(blocked(p.x+Math.sign(vx),p.y+Math.sign(vy)))return {blocked:true,boundary:false,result:{x:p.x,y:p.y,accumulatorX:p.accumulatorX,accumulatorY:p.accumulatorY}};
  if(sx)ax=vx>0?59:0;if(sy)ay=vy>0?59:0;
  return {blocked:false,boundary:false,result:{x:p.x,y:p.y,accumulatorX:ax&255,accumulatorY:ay&255}};
 }
 return {blocked:false,boundary,result:{x:(absoluteX+2160)%2160,y:legacyPoleWrap?(y+1080)%1080:clamp(y,0,1078),accumulatorX:(ax-sx*60)&255,accumulatorY:(ay-sy*60)&255}};
}
export function steerStep(p,tile){
 const collision=(x,y)=>hullBlocked((x+2160)%2160,y,(a,b)=>b<0||b>=1080?0xff:tile((a+2160)%2160,b));
 for(const heading of [p.heading,(p.heading+1)%8,(p.heading+7)%8]){const next=moveStep({...p,heading},collision);if(!next.blocked)return {...next,heading};}
 return {blocked:true,boundary:false,heading:p.heading,result:{x:p.x,y:p.y,accumulatorX:p.accumulatorX,accumulatorY:p.accumulatorY}};
}
