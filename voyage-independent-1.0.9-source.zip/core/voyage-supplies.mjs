const floor=Math.floor,trunc=Math.trunc,clamp=(x,a,b)=>Math.max(a,Math.min(x,b));
const s16=n=>(n<<16)>>16;
export function rationHealth(health,leadership,ration){const t=100-floor(leadership/5)-ration;return clamp(health-trunc(t/(t>0?5:10)),0,100);}
export function consumeResource(ships,kind,ration,ashore,{legacyDonorHealth=false}={}){
 if(!['food','water'].includes(kind)||!Number.isInteger(ration)||ration<0||ration>100)throw new RangeError('Invalid ration');
 const next=structuredClone(ships),events=[];
 for(let i=0;i<next.length;i++){
  const receiver=next[i];if(receiver.active===false)continue;
  const index=receiver[kind]>0?i:next.findIndex(s=>s.active!==false&&s[kind]>0);
  let checked=receiver;
  if(index===-1){receiver.health=Math.max(0,receiver.health-16);events.push({type:'SHORTAGE',ship:i,kind});}
  else{
   const provider=next[index],used=Math.min(provider[kind],floor(receiver.crew*ration/(ashore?200:100))+1);
   provider[kind]-=used;checked=legacyDonorHealth?provider:receiver;
   checked.health=rationHealth(checked.health,checked.captain.leadership,ration);
   events.push({type:'CONSUMED',ship:i,provider:index,kind,tenths:used});
  }
  if(checked.health<20){
   const raw=(20-receiver.health)*receiver.crew;
   const loss=legacyDonorHealth?Math.min(receiver.crew,(trunc(s16(raw)/100)+1)&65535):Math.min(receiver.crew,floor(Math.max(0,raw)/100)+1);
   receiver.crew-=loss;if(loss)events.push({type:'CREW_LOST',ship:i,count:loss,cause:kind});
  }
 }
 return {ships:next,events};
}
export function consumeDaily(ships,ration,ashore=false,options){const food=consumeResource(ships,'food',ration.food,ashore,options),water=consumeResource(food.ships,'water',ration.water,ashore,options);return {ships:water.ships,events:[...food.events,...water.events]};}
export function departureCheck(ships){
 const active=ships.filter(s=>s.active!==false);
 if(!active.length)return {ok:false,reason:'배가 없습니다.'};
 if(active.some(s=>floor(s.crew*s.navigationPercent/100)===0))return {ok:false,reason:'모든 배에 항해할 선원을 배치해 주세요.'};
 const crew=active.reduce((n,s)=>n+s.crew,0),water=active.reduce((n,s)=>n+s.water,0),food=active.reduce((n,s)=>n+s.food,0);
 const days=floor(Math.min(water,food)/Math.max(crew,1));
 return {ok:days>0,days,reason:days>0?null:'하루치 이상의 물과 식량을 실어 주세요.'};
}
