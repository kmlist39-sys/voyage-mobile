import {random,validateCommand,commitCommand} from './random.mjs';
import {boardingFactor,boardingKills,cannonDamage,firepower,turningRate,GUNS} from './combat-rules.mjs';
import {hexStep,hexDistance,attackKind,plotCourse,reachableCourses,broadside} from './battle-grid.mjs';
const live=u=>u&&!u.left&&u.crew>0&&u.durability>0;
const edge=(u,s)=>u.x===0||u.y===0||u.x===s.width-1||u.y===s.height-1;
const land=(s,x,y)=>!!s.terrain[y*s.width+x];
function board(s){return {width:s.width,height:s.height,wind:s.wind,units:s.units,land:(x,y)=>land(s,x,y)};}
function end(s,code){s.phase='finished';s.outcome=code;s.actor=null;s.pendingDuel=null;}
function resultCheck(s){
 const own=s.units.find(u=>u.id===s.player),enemy=s.units.find(u=>u.flagship&&u.main&&u.team!==own.team);
 if(!own||own.durability<=0||own.crew<=0)end(s,5);else if(own.left)end(s,3);
 else if(!enemy||enemy.durability<=0||enemy.crew<=0)end(s,4);else if(enemy.left)end(s,2);
 return s.phase==='finished';
}
function actorAt(s){return s.units.find(u=>u.side===s.cursor%4&&u.orderIndex===Math.floor(s.cursor/4));}
function seek(s){
 if(resultCheck(s))return;
 for(let safety=0;safety<41;safety++){
  if(s.cursor>=40){s.cursor=0;s.turn++;s.tick++;if(s.tick>=63){end(s,1);return;}}
  const u=actorAt(s);if(live(u)){s.actor=u.id;s.phase=u.id===s.player?'command':'ai';return;}s.cursor++;
 }
 throw new Error('No battle unit can act');
}
function next(s){s.cursor++;seek(s);}
export function createBattle({units,player,terrain,width=52,height=48,tick=24,seed=1,wind}){
 if(!units.some(u=>u.id===player)||units.some(u=>!u.captain)||new Set(units.map(u=>u.id)).size!==units.length)throw new Error('Invalid battle fleet');
 const s={version:1,revision:0,receipts:[],rng:seed,units:structuredClone(units),player,terrain:terrain?Array.from(terrain):Array(width*height).fill(0),width,height,tick,turn:1,cursor:0,phase:'command',actor:null,outcome:null,pendingDuel:null,duelBalance:100,lastDuelOpponent:null,wind:null};
 s.wind=wind??{speed:1+random(s,8),direction:Math.floor(random(s,8)*5/7)};
 for(const u of s.units){u.turnCharge=0;u.left=false;u.maximumCrew??=u.bunks??u.crew;u.boardingFactor=boardingFactor({...u.captain,primary:u.primaryBoarder??u.team===s.units.find(n=>n.id===player).team});
  u.orders??={strategy:'pack',tactic:'attack',chase:u.captain.courage>=random(s,50),method:u.shot&&!u.oared?'fire':'rush',target:null};
  if(u.flagship)u.orders={strategy:'pack',tactic:'attack',chase:false,method:'rush',target:null};
 }
 for(const side of [...new Set(s.units.map(u=>u.side))]){const list=s.units.filter(u=>u.side===side).sort((a,b)=>Number(b.flagship)-Number(a.flagship)||a.slot-b.slot);list.forEach((u,i)=>u.orderIndex=i);}
 if(tick>=63)end(s,1);else seek(s);return s;
}
function pool(s,u){
 const officers=u.id===s.player?[u.captain,...(u.officers??[])]:[u.captain];
 return {leadership:Math.max(...officers.map(c=>c.leadership)),battleLevel:Math.max(...officers.map(c=>c.battleLevel)),swordplay:Math.max(...officers.map(c=>c.swordplay)),gunnery:officers.some(c=>c.gunnery??(c.skills&4)),ownBattleLevel:u.captain.battleLevel};
}
function critical(s,target,damage){
 if(damage<10&&random(s,5)!==0)return [];
 const roll=random(s,19);let parts=roll<3?['maximumDurability']:roll<7?['power']:roll<11?['tacking']:roll<13?['maximumDurability','power']:roll<15?['maximumDurability','tacking']:roll<17?['power','tacking']:['maximumDurability','power','tacking'];
 if(damage>=20){const roll2=random(s,7);parts=roll2<2?['maximumDurability','power']:roll2<4?['maximumDurability','tacking']:roll2<6?['power','tacking']:['maximumDurability','power','tacking'];}
 if(damage>=40)parts=['maximumDurability','power','tacking'];
 for(const p of parts)target[p]=p==='maximumDurability'?Math.max(Math.floor(target.modelDurability/4),target[p]-1):Math.max(0,target[p]-Math.floor(damage/2)-random(s,3));
 return parts;
}
function attack(s,source,target,events){
 const kind=attackKind(source,target);if(!kind)throw new Error('공격 사거리와 방향을 확인해 주세요.');
 const a=pool(s,source),d=pool(s,target);
 if(kind==='cannon'){
  const damage=cannonDamage({...source,...a,firepower:firepower(source.gunType,hexDistance(source,target))},n=>random(s,n));source.shot--;
  const hullLost=Math.min(target.durability,damage),crewLost=Math.min(target.crew,Math.floor(damage/2)+random(s,3));target.durability-=hullLost;target.crew-=crewLost;
  const damaged=critical(s,target,damage);events.push({type:'CANNON',source:source.id,target:target.id,damage:hullLost,crewLost,critical:damaged});
 }else{
  const hit=Math.min(target.crew,boardingKills({...source,swordplay:a.swordplay},n=>random(s,n)));target.crew-=hit;
  const counter=Math.min(source.crew,boardingKills({...target,swordplay:d.swordplay},n=>random(s,n)));source.crew-=counter;
  events.push({type:'BOARDING',source:source.id,target:target.id,crewLost:hit,counterLost:counter});
 }
 const experience=target.durability===0||target.crew===0?10*target.maximumDurability:10;events.push({type:'BATTLE_EXPERIENCE',captain:source.captain.id,amount:experience});
 if(!live(target))events.push({type:target.durability===0?'SHIP_SUNK':'CREW_DEFEATED',ship:target.id});
 for(const u of s.units)if(u.orders.target===target.id&&!live(target))u.orders.target=null;
}
export function battleActions(s){
 if(s.phase==='finished')return [];
 if(s.phase==='ai')return [{type:'ADVANCE',label:'함대 행동'}];
 if(s.phase==='duel')return [{type:'DUEL_RESULT',label:'일기토 진행'}];
 const u=s.units.find(u=>u.id===s.actor),targets=s.units.filter(t=>attackKind(u,t)).map(t=>({id:t.id,kind:attackKind(u,t)}));
 const actions=[{type:'ATTACK',label:'공격',targets,enabled:targets.length>0},{type:'WAIT',label:s.phase==='attack'?'공격 없이 완료':'대기'}];
 if(s.phase==='command')actions.unshift({type:'MOVE',label:'항로 지정'},{type:'TURN',label:'방향 전환'},{type:'ORDER',label:'함대 지휘'},{type:'ESCAPE',label:'전장 이탈',enabled:edge(u,s)},{type:'SURRENDER',label:'항복'});
 return actions;
}
function threat(s,u,p){let n=0;for(const e of s.units)if(e.team!==u.team){const d=hexDistance(e,p);if(d===1)n+=e.boardingFactor;else if(e.shot&&broadside(e,p,e.heading))n+=firepower(e.gunType,d);}return n&255;}
function attackValue(s,u,p){let n=0;for(const e of s.units)if(e.team!==u.team){const d=hexDistance(p,e);let v=0;if(u.shot&&d>=2&&d<=(GUNS[u.gunType]?.range??0)&&broadside(p,e,p.heading))v=firepower(e.gunType,d)*(u.orders.method==='fire'?2:1);if(d===1)v=e.boardingFactor*(u.orders.method==='rush'?2:1);n=Math.max(n,v&255);}return n;}
function aiMove(s,u,events){
 const ownFlag=s.units.find(n=>n.side===u.side&&n.flagship);
 if(!live(ownFlag)||ownFlag.crew<=ownFlag.maximumCrew*.4||ownFlag.durability<=ownFlag.maximumDurability*.4)u.orders.strategy='flee';
 if(u.orders.strategy==='flee'&&edge(u,s)&&!land(s,u.x,u.y)){u.left=true;events.push({type:'SHIP_ESCAPED',ship:u.id});return;}
 const b=board(s),routes=reachableCourses(u,b),start={x:u.x,y:u.y,heading:u.heading,turnCharge:u.turnCharge,remaining:0,path:[],directions:[]};
 const candidates=[start,...routes.filter(p=>[p.heading,(p.heading+1)%6,(p.heading+5)%6].some(d=>{try{plotCourse(u,[...p.directions,d],b);return true;}catch(e){if(!(e instanceof RangeError))throw e;return false;}}))];
 const excluded=new Set();for(const ally of s.units.filter(n=>n.team===u.team&&live(n))){const forward=hexStep(ally,ally.heading);excluded.add(`${forward.x},${forward.y}`);const free=Array.from({length:6},(_,d)=>hexStep(ally,d)).filter(p=>p.x>=0&&p.x<s.width&&p.y>=0&&p.y<s.height&&!land(s,p.x,p.y)&&!s.units.some(n=>!n.left&&n.durability>0&&n.x===p.x&&n.y===p.y));if(free.length===1)excluded.add(`${free[0].x},${free[0].y}`);}
 const target=s.units.find(n=>n.id===u.orders.target)??s.units.find(n=>n.team!==u.team&&n.flagship&&n.main);
 let best=null;
 for(const p of candidates.sort((a,b)=>a.y-b.y||a.x-b.x)){
  if(excluded.has(`${p.x},${p.y}`))continue;const distance=hexDistance(p,u),exposure=threat(s,u,p),value=attackValue(s,u,p),r=GUNS[u.gunType]?.range??0;
  let metric;
  if(u.orders.strategy==='flee')metric=Math.min(p.x,p.y,s.width-1-p.x,s.height-1-p.y);
  else if(u.orders.strategy==='fightBack')metric=hexDistance(p,ownFlag);
  else if(u.orders.tactic==='escape')metric=exposure;
  else metric=Math.max(target?hexDistance(p,target):0,r);
  let replace=!best||metric<best.metric;
  if(best&&metric===best.metric){
   if(u.orders.strategy==='flee')replace=distance>best.distance;
   else if(u.orders.tactic==='escape'){
    const threshold=u.orders.strategy==='fightBack'?Math.ceil(Math.floor(Math.min(metric,10)*best.exposure/10)/10)*10:best.exposure;
    replace=exposure<threshold||exposure===threshold&&distance>best.distance;
   }else {const threshold=Math.ceil(Math.floor((12-Math.min(metric,10))*best.value/10)/10)*10;replace=value>threshold||value===threshold&&distance>best.distance;}
  }
  if(replace)best={...p,distance,metric,exposure,value};
 }
 if(best?.directions.length){Object.assign(u,{x:best.x,y:best.y,heading:best.heading,turnCharge:best.turnCharge});events.push({type:'SHIP_MOVED',ship:u.id,path:best.path});}
 else{let heading=u.heading,value=-1;for(const h of [u.heading,(u.heading+5)%6,(u.heading+1)%6]){const v=attackValue(s,u,{...u,heading:h});if(v>=value){value=v;heading=h;}}u.heading=heading;u.turnCharge=Math.min(100,u.turnCharge+turningRate({...u.captain,tacking:u.tacking}));}
 if(u.orders.tactic==='attack'||u.orders.chase){let targets=s.units.filter(t=>attackKind(u,t));if(u.orders.target)targets=targets.filter(t=>t.id===u.orders.target);const preferred=u.orders.method==='fire'?'cannon':'boarding',t=targets.find(t=>attackKind(u,t)===preferred)??targets[0];if(t)attack(s,u,t,events);}
}
export function applyBattleCommand(state,command){
 if(!validateCommand(state,command))return {state,events:[]};if(state.phase==='finished')throw new Error('전투가 종료되었습니다.');
 const s=structuredClone(state),u=s.units.find(u=>u.id===s.actor),events=[];
 if(s.phase==='ai'){
  if(command.type!=='ADVANCE')throw new Error('다른 배가 행동할 차례입니다.');aiMove(s,u,events);next(s);
 }else if(s.phase==='duel'){
  if(command.type!=='DUEL_RESULT'||![0,1,null].includes(command.winner)||!Number.isInteger(command.balance)||command.balance<0||command.balance>200)throw new Error('Invalid duel completion');
  s.duelBalance=command.balance;const target=s.units.find(n=>n.id===s.pendingDuel.target);
  if(command.winner!==null){if(!target.main){target.crew=0;s.pendingDuel=null;next(s);}else end(s,command.winner===0?6:7);}else{s.pendingDuel=null;next(s);}
 }else switch(command.type){
  case 'MOVE':{if(s.phase!=='command')throw new Error('이미 이동했습니다.');const p=plotCourse(u,command.directions,board(s));if(!p.path.length)throw new Error('이동할 항로를 선택해 주세요.');Object.assign(u,{x:p.x,y:p.y,heading:p.heading,turnCharge:p.turnCharge});s.phase='attack';events.push({type:'SHIP_MOVED',ship:u.id,path:p.path});break;}
  case 'TURN':{if(s.phase!=='command'||![1,5].includes((command.heading-u.heading+6)%6))throw new Error('인접한 방향으로 전환해 주세요.');const neighbor=hexStep(u,command.heading);if(neighbor.x<0||neighbor.y<0||neighbor.x>=s.width||neighbor.y>=s.height)throw new Error('지도의 바깥 방향입니다.');u.heading=command.heading;u.turnCharge=0;s.phase='attack';break;}
  case 'ATTACK':{const target=s.units.find(n=>n.id===command.target);if(!target||!attackKind(u,target))throw new Error('공격할 수 없는 대상입니다.');
   if(command.challenge&&u.flagship&&target.flagship&&attackKind(u,target)==='boarding'&&u.crew+random(s,u.captain.luck)>=target.crew){if(s.lastDuelOpponent!==target.id)s.duelBalance=100;s.lastDuelOpponent=target.id;s.pendingDuel={source:u.id,target:target.id,balance:s.duelBalance};s.phase='duel';events.push({type:'DUEL_STARTED',...s.pendingDuel});break;}
   attack(s,u,target,events);next(s);break;}
  case 'WAIT':next(s);break;
  case 'ESCAPE':if(s.phase!=='command'||!edge(u,s))throw new Error('전장 가장자리에서 이탈할 수 있습니다.');u.left=true;resultCheck(s);break;
  case 'SURRENDER':if(s.phase!=='command')throw new Error('지금은 항복할 수 없습니다.');end(s,9);break;
  case 'ORDER':{if(s.phase!=='command')throw new Error('지금은 명령을 바꿀 수 없습니다.');const other=s.units.find(n=>n.id===command.ship);if(!other||other.team!==u.team||other.id===s.player)throw new Error('아군 배를 선택해 주세요.');const o=command.orders;if(!['pack','fightBack','flee'].includes(o.strategy)||!['attack','escape'].includes(o.tactic)||!['fire','rush'].includes(o.method)||typeof o.chase!=='boolean')throw new Error('Invalid fleet orders');if(o.target&&!s.units.some(n=>n.id===o.target&&n.team!==u.team))throw new Error('Invalid target');other.orders=structuredClone(o);break;}
  default:throw new Error('Unknown battle command');
 }
 if(s.phase==='finished')events.push({type:'BATTLE_ENDED',outcome:s.outcome});commitCommand(s,command.id);return {state:s,events};
}
