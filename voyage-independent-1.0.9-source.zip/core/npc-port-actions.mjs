// Original port economy actions; path finding and pursuit steering are modernized.
const floor=Math.floor;
const OBJECTIVES=[[1,9,8],[1,9,8],[2,9,8],[1,6,6],[1,5,6],[1,5,6],[1,5,6],[6,9,6],[6,4,6]];
export function npcHome(h,data,id){const p=h.get(8,id,38);h.set(8,id,27,0);h.set(8,id,28,p);h.set(8,id,4,data.ports[p].x,2);h.set(8,id,6,data.ports[p].y,2);h.set(8,id,41,h.get(8,id,41)&207);}
function sortie(h,data,id,rng){const n=floor(id/10),position=id%10,mode=h.get(0,n,3),own=h.state.protagonist,kind=position<=4?0:position<=6?1:2,home=h.get(8,id,38);
 if(home!==h.get(0,n,10)){h.set(8,id,39,5);return;}const siblings=Array.from({length:9},(_,i)=>n*10+1+i).filter(f=>{const p=f%10;return (p<=4?0:p<=6?1:2)===kind;});if(!(h.get(8,id,41)&64)&&siblings.filter(f=>!(h.get(8,f,41)&16)).length>=(kind===0?2:1)){h.set(8,id,39,5);return;}
 const order=OBJECTIVES[mode]?.[kind]??0;let arg=home,target=h.get(0,n,2);if(target===7)target=h.get(3,own,49)&7;
 if(order===1||order===2)arg=h.get(0,n,4);else if(order===4)arg=own;else if(order===8)arg=h.get(8,n*10+1+rng(4),42);else if(order===5||order===6){let f;if(mode===3||mode===7)f=h.fleetId();else if(mode===4||mode===8)f=target*10+(h.get(1,own,13)>2?rng(5):1+rng(4));else if(mode===5)f=target*10+5+rng(2);else if(mode===6)f=61+rng(9);if(f===undefined||!(h.get(8,f,41)&1)){h.set(8,id,39,5);return;}arg=h.get(8,f,42);}
 if(order<=3&&arg>=130){h.set(8,id,39,5);return;}h.set(8,id,27,order);h.set(8,id,28,arg);h.set(8,id,39,0);h.set(8,id,41,h.get(8,id,41)&207);
}
export function npcPortAction(h,data,id,rng){
 if(id===h.fleetId()||id%10===0||!(h.get(8,id,41)&1)||!(h.get(8,id,41)&16)||h.get(8,id,41)&64)return false;
 const order=h.get(8,id,27);if(order>2)return false;const delay=h.get(8,id,39);if(delay>0){h.set(8,id,39,delay-1);if(delay>1)return false;}
 const nation=floor(id/10),port=h.get(8,id,28),treasury=h.get(8,id,36,2);if(port>=100){npcHome(h,data,id);return true;}
 if(order===0){const good=h.get(8,id,33);if(good<46){for(let c=0;c<10;c++)h.set(13,port,14+c,Math.max(0,h.get(13,port,14+c)-rng(3)));const c=data.goods[good].category;h.set(13,port,14+c,Math.max(0,h.get(13,port,14+c)-2));}for(let i=0;i<10;i++){const at=43+i*9;if((h.get(8,id,at+8)&48)===16)h.set(8,id,at+2,h.get(8,id,at+3));}h.set(8,id,36,floor(h.get(0,nation,0,2)/10)+1+rng(3),2);h.set(8,id,33,255);h.set(8,id,34,0,2);sortie(h,data,id,rng);return true;}
 if(port!==h.get(0,nation,10)&&nation<6){
  if(order===1&&treasury>=2){let field=h.get(13,port,4,2)>h.get(13,port,0,2)?2:6;if(h.get(13,port,field,2)>=50000)field=field===2?6:2;const half=floor(treasury/2);h.set(13,port,field,Math.min(50000,h.get(13,port,field,2)+half*100),2);h.set(8,id,36,treasury-half,2);const gain=Math.min(100-h.get(13,port,8+nation),floor(6*(treasury-half)/10));h.set(13,port,8+nation,h.get(13,port,8+nation)+gain);let remaining=gain;while(remaining){let changed=false;for(let n=0;n<6&&remaining;n++)if(n!==nation&&h.get(13,port,8+n)>0){h.set(13,port,8+n,h.get(13,port,8+n)-1);remaining--;changed=true;}if(!changed)break;}}
  if(order===2){const good=10+rng(16),category=data.goods[good].category,price=floor((h.get(13,port,14+category)+50)*data.markets[data.ports[port].market].salePrices[good]/100);if(price>0&&treasury*100>=price){const amount=Math.min(1000,floor(treasury*100/price));h.set(8,id,33,good);h.set(8,id,34,amount,2);h.set(8,id,36,treasury-floor(amount*price/100),2);h.set(13,port,14+category,Math.min(100,h.get(13,port,14+category)+3+rng(3)));}}
 }
 npcHome(h,data,id);return true;
}
export function npcArrive(h,id,rng){h.set(8,id,41,h.get(8,id,41)|48);h.set(8,id,39,8+rng(8));}
