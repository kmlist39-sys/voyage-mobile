import {cargoUsed,maximumSupplyLoad,maximumSupplyUnload,changeSupplies,supplyUnitPrice} from '../supply-model.mjs';
export {cargoUsed,maximumSupplyLoad,maximumSupplyUnload,changeSupplies,supplyUnitPrice};
const floor=Math.floor,clamp=(x,a,b)=>Math.max(a,Math.min(x,b));
const amount=n=>{if(!Number.isSafeInteger(n)||n<0)throw new RangeError('수량이 올바르지 않습니다.');return n;};
export const MAX_GOLD=600000000;
export function taxExempt(port,inventory){const nation=port.controller??(port.initialFlags&7);return nation<6&&inventory.includes(0x23+nation);}
export function buyPrice(port,market,goods,slot,inventory=[]){
 const specialty=slot===9,b=specialty?{good:port.specialty,basePrice:port.specialtyBasePrice}:market.buy[slot];
 if(!b||!goods[b.good])throw new RangeError('상품이 없습니다.');
 const ordinary=floor((port.rates[goods[b.good].category]+50)*b.basePrice/100);
 return taxExempt(port,inventory)?ordinary:floor(ordinary*12/10);
}
export function sellPrice(port,market,goods,id){
 if(!goods[id])throw new RangeError('상품이 없습니다.');
 const specialty=id===port.specialty,base=specialty?port.specialtyBasePrice:market.salePrices[id];
 const ordinary=floor((port.rates[goods[id].category]+50)*base/100);
 return specialty?floor(ordinary/2):ordinary;
}
export function marketOffers(port,market,goods,inventory=[]){
 const offers=[];
 for(let slot=0;slot<market.buy.length;slot++){const b=market.buy[slot];if(b.good===255)break;if(port.economy>=b.minimumEconomy)offers.push({slot,id:b.good,name:goods[b.good].name,price:buyPrice(port,market,goods,slot,inventory)});}
 if(goods[port.specialty]&&port.economy>=port.specialtyEconomy&&port.rates[goods[port.specialty].category]<90)offers.push({slot:9,id:port.specialty,name:goods[port.specialty].name,price:buyPrice(port,market,goods,9,inventory)});
 return offers;
}
export function rateAdjustment(port,category,value,mode){
 if(!['buy','sell'].includes(mode))throw new RangeError('Invalid market operation');
 amount(value);const delta=Math.min(10,floor((mode==='buy'?value%65536:value)/(port.economy+500))),all=Math.min(3,floor(value%65536/1000)),sign=mode==='buy'?1:-1;
 const rates=port.rates.slice();rates[category]=clamp(rates[category]+sign*delta,0,100);
 return {...port,rates:rates.map(n=>clamp(n+sign*all,0,100))};
}
export function maximumGoodsBuy(s,capacity,gold,id,price){
 amount(gold);amount(capacity);amount(price);
 if(!s.goods.some(g=>g.id===id||g.id===255))return 0;
 const free=Math.max(0,capacity-cargoUsed(s));return price?Math.min(free,floor(gold/price)):free;
}
// All validation precedes the mutation. Callers commit this complete result once.
export function trade({port,market,goods,inventory=[],supplies,capacity,gold},command){
 const {mode,quantity}=command;amount(quantity);let id,price,index;
 if(mode==='buy'){
  const offer=marketOffers(port,market,goods,inventory).find(o=>o.slot===command.slot);if(!offer)throw new RangeError('지금은 판매하지 않는 상품입니다.');
  id=offer.id;price=offer.price;
  if(command.agreedPrice!==undefined){amount(command.agreedPrice);const lowest=negotiationTerms(price,command.rank??0,command.ownNation===true).floor;if(command.agreedPrice<lowest||command.agreedPrice>price)throw new RangeError('Invalid negotiated price');price=command.agreedPrice;}
  if(quantity>maximumGoodsBuy(supplies,capacity,gold,id,price))throw new RangeError('금화나 적재 공간이 부족합니다.');
  index=supplies.goods.findIndex(g=>g.id===id);if(index<0)index=supplies.goods.findIndex(g=>g.id===255);
 }else if(mode==='sell'){
  index=command.cargoSlot;const entry=supplies.goods[index];if(!entry||entry.id===255||quantity>entry.quantity)throw new RangeError('판매할 수량을 확인해 주세요.');
  id=entry.id;price=sellPrice(port,market,goods,id);
 }else throw new RangeError('Invalid trade mode');
 const value=price*quantity;if(mode==='sell'&&gold+value>MAX_GOLD)throw new RangeError('보유 금화 한도를 넘습니다.');
 if(quantity===0)return {port,supplies,gold,quantity:0,price,value:0};
 const next=structuredClone(supplies),old=next.goods[index],qty=(old.id===255?0:old.quantity)+(mode==='buy'?quantity:-quantity);
 next.goods[index]=qty?{id,quantity:qty}:{id:255,quantity:0};
 return {port:rateAdjustment(port,goods[id].category,value,mode),supplies:next,gold:gold+(mode==='buy'?-value:value),quantity,price,value};
}
export function negotiationTerms(price,rank,ownNation){const low=floor(price*(19-(ownNation?rank:0))/20),threshold=price-floor((price-low)/2),counter=price-floor((threshold-low)/2);return {price,floor:low,threshold,counter};}
export function negotiate(state,offer,{playerNegotiation=false,bookkeeperAccounting=false,bookkeeperNegotiation=false,hasBookkeeper=false}={}){
 amount(offer);if(offer>state.price)throw new RangeError('호가보다 높습니다.');if(offer===0)return {...state,status:'cancelled'};
 if(offer>=state.threshold)return {...state,status:'accepted',agreedPrice:offer};
 if(state.threshold-state.floor<=1)return {...state,status:'offer'};
 const skilled=state.bookkeeperActive?bookkeeperNegotiation:playerNegotiation;
 if(skilled||(!state.bookkeeperActive&&hasBookkeeper&&bookkeeperAccounting))return {...state,status:'accepted',agreedPrice:state.floor};
 return {...state,status:'offer',bookkeeperActive:state.bookkeeperActive||hasBookkeeper};
}
export function bankLimit({gold,balance,rank},operation){
 switch(operation){
  case'deposit':return gold<=1000||balance<0?0:Math.min(gold,1000000-balance);
  case'withdraw':return balance<=0||MAX_GOLD-gold<100?0:Math.min(balance,MAX_GOLD-gold);
  case'borrow':return balance>0?0:Math.max(0,Math.min(10000*rank*rank+balance+1000,MAX_GOLD-gold));
  case'repay':return balance>=0?0:Math.min(-balance,gold);
  default:throw new RangeError('Unknown banking operation');
 }
}
export function bankTransaction(account,operation,value){
 amount(value);if(value>bankLimit(account,operation))throw new RangeError('거래 한도를 넘습니다.');
 const towardBank=operation==='deposit'||operation==='repay';return {...account,gold:account.gold+(towardBank?-value:value),balance:account.balance+(towardBank?value:-value)};
}
export function bankInterest(balance){return clamp(balance+Math.trunc(balance*(balance>=0?3:10)/100),-1000000,1000000);}
export function monthlyMarket(port,random){return {...port,economy:Math.min(1000,port.economy+floor((port.marketInvestment??0)/300)),industry:Math.min(1000,port.industry+floor((port.shipyardInvestment??0)/300)),marketInvestment:0,shipyardInvestment:0,rates:port.rates.map(v=>v+(v>50?-1:1)*(random(5)+1))};}
export function invest(port,gold,nation,kind,value,{isCapital=false}={}){
 amount(value);if(!['market','shipyard'].includes(kind))throw new RangeError('Invalid investment');
 const key=kind+'Investment',pending=port[key]??0,scale=kind==='market'?port.economy:port.industry;
 if(isCapital||value>Math.min(gold,50000-pending))throw new RangeError('투자 가능한 금액을 확인해 주세요.');
 const support=port.allegiances.slice(),gain=Math.min(nation<6?100-support[nation]:100,floor(value/Math.max(1,scale)));
 if(nation<6)support[nation]+=gain;
 let remaining=gain;
 while(remaining>0){let removed=0;for(let i=0;i<6&&remaining;i++)if(i!==nation&&support[i]>0){support[i]--;remaining--;removed++;}if(!removed)break;}
 return {port:{...port,[key]:pending+value,allegiances:support,controller:controllerFor(support)},gold:gold-value};
}
export function controllerFor(support){const i=support.findLastIndex(v=>v>=75);return i<0?6:i;}
export function automaticSupply(supplies,capacity,gold,rate){
 // New mobile command: newly loaded water and food are equal, whole barrels.
 const free=Math.max(0,capacity-cargoUsed(supplies)),price=supplyUnitPrice('food',rate),pairs=Math.min(floor(free/2),price?floor(gold/price):floor(free/2));
 return {supplies:{...structuredClone(supplies),water:supplies.water+pairs*10,food:supplies.food+pairs*10},gold:gold-pairs*price,water:pairs,food:pairs,unusedSpace:free-pairs*2};
}
export function recruitmentOffer({ships,gold,enthusiasm,economy,rank,recruitedToday}){
 const free=ships.reduce((n,s)=>n+Math.max(0,s.bunks-s.crew),0),available=Math.min(floor(enthusiasm*economy/500),(rank+1)*enthusiasm),price=floor(economy/20)+5;
 return {price,available,maximum:recruitedToday?0:Math.min(available,free,floor(gold/price))};
}
export function recruit(input,allocation){
 if(allocation.length!==input.ships.length||allocation.some(n=>!Number.isSafeInteger(n)||n<0))throw new RangeError('승선 인원을 확인해 주세요.');
 const count=allocation.reduce((a,b)=>a+b,0),offer=recruitmentOffer(input);
 if(count>offer.maximum||allocation.some((n,i)=>n>input.ships[i].bunks-input.ships[i].crew))throw new RangeError('모집 가능한 인원을 넘습니다.');
 return {ships:input.ships.map((s,i)=>({...s,crew:s.crew+allocation[i],health:allocation[i]?floor((s.crew*s.health+allocation[i]*60)/(s.crew+allocation[i])):s.health})),gold:input.gold-count*offer.price,recruitedToday:input.recruitedToday||count>0,count};
}
