const MONTH_DAYS=[31,28,31,30,31,30,31,31,30,31,30,31];
export function calendarValid(c){return Number.isInteger(c.year)&&c.year>=1501&&c.year<=1554&&Number.isInteger(c.month)&&c.month>=1&&c.month<=12&&Number.isInteger(c.day)&&c.day>=1&&c.day<=MONTH_DAYS[c.month-1]&&Number.isInteger(c.tick)&&c.tick>=0&&c.tick<72;}
export function koreanDate(c){return `${c.year}년 ${c.month}월 ${c.day}일`;}
export function koreanTime(c){const m=c.tick*20;return `${String(Math.floor(m/60)).padStart(2,'0')}시 ${String(m%60).padStart(2,'0')}분`;}
export function advanceCalendar(c){
 if(!calendarValid(c))throw new RangeError('Invalid game calendar');const next={...c},events=[];next.tick++;
 if(next.tick===72){next.tick=0;next.day++;events.push({type:'MIDNIGHT'});if(next.day>MONTH_DAYS[next.month-1]){next.day=1;next.month++;events.push({type:'MONTH_END'});if(next.month===13){next.month=1;next.year++;events.push({type:'YEAR_END'});if(next.year>=1554)events.push({type:'TIME_LIMIT'});}}}
 return {calendar:next,events};
}
