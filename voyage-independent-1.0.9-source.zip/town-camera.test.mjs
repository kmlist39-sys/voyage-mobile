import test from 'node:test';import assert from 'node:assert/strict';
import {townTileSize,townProjection} from './app/town-camera.mjs';
test('Mobile default shows at least 2.7 times the former town area',()=>{
 for(const [w,h] of [[320,568],[390,844],[568,320],[640,336],[741,377],[844,390]]){
  const previous=w<600?30:35,current=townTileSize(w,h);assert.ok((previous/current)**2>=2.7);
 }
});
test('Town view and touch coordinates stay aligned for every zoom and orientation',()=>{
 for(const [w,h] of [[320,568],[390,844],[568,320],[844,390],[1280,720]])for(let z=0;z<4;z++)for(const focus of [{x:1,y:1},{x:48,y:48},{x:94,y:94}]){
  const v=townProjection(w,h,focus,z,54,64);
  assert.ok(v.ox<=0&&v.ox+96*v.sx>=w-1e-8);assert.ok(v.oy<=54&&v.oy+96*v.sy>=h-64-1e-8);
  for(const p of [{x:17,y:25},{x:70,y:52}]){const x=v.ox+(p.x+1)*v.sx,y=v.oy+(p.y+2)*v.sy;assert.equal(Math.round((x-v.ox)/v.sx)-1,p.x);assert.equal(Math.round((y-v.oy)/v.sy)-2,p.y);}
 }
});
