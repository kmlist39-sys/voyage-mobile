import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {analysisDirectory} from './paths.mjs';import * as e from './core/economy.mjs';
const read=f=>JSON.parse(fs.readFileSync(path.join(analysisDirectory,f))),oracle=read('oracle/economy.json'),ports=read('data/ports.json'),markets=read('data/markets.json'),goods=read('data/goods.json');
const empty=()=>({water:0,food:0,lumber:0,shot:0,goods:Array.from({length:5},()=>({id:255,quantity:0}))});
test('2000 Korean purchase prices match with rates, specialty and tax permits',()=>{
 for(const c of oracle.prices){const p={...ports[c.port],controller:c.nation,rates:c.rates};assert.equal(e.buyPrice(p,markets[p.market],goods,c.slot,c.inventory),c.result,JSON.stringify(c));}
});
test('2000 positive and negative bank interest cases match original arithmetic',()=>{for(const c of oracle.interest)assert.equal(e.bankInterest(c.balance),c.result,JSON.stringify(c));});
test('20 entire monthly world-market passes match all 100 ports and 20000 random draws',()=>{
 for(const c of oracle.months){let i=0;const actual=c.ports.map(p=>e.monthlyMarket(p,n=>{const draw=c.random[i++];assert.equal(draw.bound,n);return draw.value;}));assert.deepEqual(actual,c.result);assert.equal(i,c.random.length);}
});
test('All 100 markets can buy to cargo/funds maximum and sell with exact ledger totals',()=>{
 for(const port of ports.slice(0,100))for(const offer of e.marketOffers(port,markets[port.market],goods)){
  const input={port,market:markets[port.market],goods,supplies:empty(),capacity:250,gold:50000};
  const n=e.maximumGoodsBuy(input.supplies,250,50000,offer.id,offer.price);assert.ok(n>0);
  const bought=e.trade(input,{mode:'buy',slot:offer.slot,quantity:n});assert.equal(bought.gold,50000-n*offer.price);assert.equal(e.cargoUsed(bought.supplies),n);assert.equal(e.cargoUsed(input.supplies),0);
  assert.throws(()=>e.trade(input,{mode:'buy',slot:offer.slot,quantity:n+1}));
  const sold=e.trade({...input,...bought},{mode:'sell',cargoSlot:0,quantity:n});assert.equal(e.cargoUsed(sold.supplies),0);assert.equal(sold.gold,bought.gold+sold.value);
 }
});
test('Full cargo slots and absent offers fail atomically; selling local specialty halves ordinary price',()=>{
 const s=empty();s.goods=Array.from({length:5},(_,id)=>({id,quantity:1}));assert.equal(e.maximumGoodsBuy(s,100,10000,20,1),0);
 assert.equal(e.sellPrice({...ports[0],rates:Array(10).fill(50)},markets[0],goods,16),19);
 assert.throws(()=>e.trade({port:ports[0],market:markets[0],goods,supplies:s,capacity:100,gold:50000},{mode:'buy',slot:99,quantity:1}));
});
test('Rate overflow behavior and specialty availability follow original rules',()=>{
 const p={...ports[0],rates:Array(10).fill(50)};
 assert.deepEqual(e.rateAdjustment(p,0,262449,'buy').rates,p.rates);
 assert.equal(e.rateAdjustment(p,0,262449,'sell').rates[0],40);
 const blocked={...p,rates:p.rates.map((v,i)=>i===goods[p.specialty].category?90:v)};
 assert.ok(!e.marketOffers(blocked,markets[p.market],goods).some(o=>o.slot===9));
});
test('Negotiation selects concrete offered price and resumes bookkeeper skills',()=>{
 const n=e.negotiationTerms(120,0,false);assert.deepEqual(n,{price:120,floor:114,threshold:117,counter:119});
 assert.equal(e.negotiate(n,117).agreedPrice,117);assert.equal(e.negotiate(n,1,{playerNegotiation:true}).agreedPrice,114);
 const low=e.negotiate(n,1,{hasBookkeeper:true,bookkeeperNegotiation:true});assert.equal(low.status,'offer');assert.equal(e.negotiate(low,1,{bookkeeperNegotiation:true}).agreedPrice,114);
 assert.equal(e.negotiate(n,0).status,'cancelled');
});
test('Bank deposit, withdrawal, borrowing and repayment conserve money and respect caps',()=>{
 let a={gold:50000,balance:0,rank:1};a=e.bankTransaction(a,'deposit',30000);a=e.bankTransaction(a,'withdraw',30000);assert.deepEqual(a,{gold:50000,balance:0,rank:1});
 a=e.bankTransaction(a,'borrow',11000);assert.equal(e.bankLimit(a,'borrow'),0);assert.equal(e.bankLimit(a,'deposit'),0);
 a=e.bankTransaction(a,'repay',11000);assert.equal(a.balance,0);assert.equal(a.gold,50000);
 assert.equal(e.bankLimit({...a,gold:1000},'deposit'),0);assert.throws(()=>e.bankTransaction(a,'borrow',11001));
});
test('Auto supply splits newly loaded barrels evenly and MAX/unload round-trip preserves fractions',()=>{
 for(let free=0;free<100;free++)for(const gold of [0,1,10,100,10000]){const s={...empty(),water:9,food:9};const a=e.automaticSupply(s,free,gold,50);assert.equal(a.water,a.food);assert.ok(a.gold>=0);assert.ok(e.cargoUsed(a.supplies)<=free);assert.equal(a.supplies.water%10,9);assert.equal(a.supplies.food%10,9);}
 const s=empty(),max=e.maximumSupplyLoad(s,100,250,'food',50);assert.equal(max,12);
 const loaded=e.changeSupplies(s,100,250,'food',max,50,'load');assert.equal(loaded.gold,10);assert.equal(e.maximumSupplyUnload(loaded.supplies,'food'),12);
 const unloaded=e.changeSupplies(loaded.supplies,100,10,'food',12,50,'unload');assert.equal(unloaded.supplies.food,0);assert.equal(unloaded.gold,10);
});
test('Recruitment costs apply once, health is weighted, next-day restriction is explicit',()=>{
 const input={ships:[{crew:10,bunks:100,health:100},{crew:0,bunks:10,health:0}],gold:1000,enthusiasm:30,economy:500,rank:1,recruitedToday:false};
 assert.deepEqual(e.recruitmentOffer(input),{price:30,available:30,maximum:30});const r=e.recruit(input,[10,10]);assert.equal(r.gold,400);assert.equal(r.ships[0].health,80);assert.equal(r.ships[1].health,60);assert.equal(r.recruitedToday,true);
 assert.equal(e.recruitmentOffer({...input,...r}).maximum,0);assert.throws(()=>e.recruit({...input,...r},[1,0]));
});
test('Investment is deferred until month end; support is conserved with competing nations',()=>{
 const p={...ports[1],allegiances:[20,30,40,10,0,0],economy:500,marketInvestment:0};const r=e.invest(p,100000,0,'market',5000);
 assert.equal(r.gold,95000);assert.equal(r.port.economy,500);assert.equal(r.port.marketInvestment,5000);assert.equal(r.port.allegiances.reduce((a,b)=>a+b),100);assert.equal(r.port.allegiances[0],30);
 assert.equal(e.monthlyMarket(r.port,()=>0).economy,516);assert.throws(()=>e.invest(p,100000,0,'market',50001));
});
