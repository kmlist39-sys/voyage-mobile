import test from 'node:test';import assert from 'node:assert/strict';
import {encodeRecord,decodeRecord,readRecord,writeRecord} from './app/save-storage.mjs';
import {data} from './game-fixtures.mjs';import {VoyageGame} from './core/game.mjs';
const storage=limit=>{const m=new Map();return{getItem:k=>m.get(k)??null,setItem(k,v){if([...m].filter(([x])=>x!==k).reduce((n,[x,t])=>n+x.length+t.length,0)+k.length+v.length>limit)throw new Error('QuotaExceededError');m.set(k,v);}};};
test('compressed saves round-trip Korean names, real game records and long NPC routes below WebView quota',()=>{
 const g=new VoyageGame(data);g.start(0);const record={format:2,name:'조안 페레로 · ⚓',snapshot:g.snapshot()};record.snapshot.game.npcPaths=Object.fromEntries(Array.from({length:70},(_,i)=>[i,{index:20,order:1,target:8,route:Array.from({length:1500},(_,j)=>({x:600+j%500,y:200+j%90,heading:j%8}))}]));
 const raw=JSON.stringify(record),packed=encodeRecord(record);assert.deepEqual(decodeRecord(packed),record);assert.ok(packed.length<raw.length*.4);const s=storage(5*1024*1024);for(let i=0;i<6;i++){writeRecord(s,'slot'+i,record);writeRecord(s,'slot'+i,record);}assert.deepEqual(readRecord(s,'slot5'),record);
});
test('legacy saves and backups survive migration, corrupt primary and failed quota writes',()=>{
 const record={format:2,snapshot:{version:2},name:'기존 기록'},s=storage(10000);s.setItem('slot',JSON.stringify(record));assert.deepEqual(readRecord(s,'slot'),record);const next={...record,name:'새 기록'};writeRecord(s,'slot',next);assert.deepEqual(readRecord(s,'slot'),next);s.setItem('slot','broken');assert.deepEqual(readRecord(s,'slot'),record);
 const full=storage(100);full.setItem('slot',JSON.stringify(record));assert.throws(()=>writeRecord(full,'slot',next),/Quota/);assert.deepEqual(readRecord(full,'slot'),record);assert.throws(()=>decodeRecord(encodeRecord(next).replace('lzw16','bad')));
});
