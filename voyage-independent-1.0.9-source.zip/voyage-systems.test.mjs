import test from 'node:test';import assert from 'node:assert/strict';import {advanceCalendar,koreanDate,koreanTime} from './core/calendar.mjs';import {gainExperience,voyageExperience,experienceThreshold,piracyFame,discoveryReward} from './core/progression.mjs';import {createWeather,weatherCheck,illnessPass} from './core/voyage-weather.mjs';
test('Korean clock advances 72 ticks per day through original 28-day February and 1553 limit',()=>{
 let c={year:1524,month:2,day:28,tick:71};assert.equal(koreanDate(c),'1524년 2월 28일');assert.equal(koreanTime(c),'23시 40분');let r=advanceCalendar(c);assert.deepEqual(r.calendar,{year:1524,month:3,day:1,tick:0});assert.deepEqual(r.events.map(e=>e.type),['MIDNIGHT','MONTH_END']);
 r=advanceCalendar({year:1553,month:12,day:31,tick:71});assert.deepEqual(r.events.map(e=>e.type),['MIDNIGHT','MONTH_END','YEAR_END','TIME_LIMIT']);
});
test('Multi-level progression, 100-level cap and fame rules apply exact per-award rolls',()=>{
 const c={navigationLevel:1,navigationExperience:0,battleLevel:1,battleExperience:0,leadership:50,seamanship:50,knowledge:50,intuition:50,courage:50,swordplay:50};let draws=0;const r=gainExperience(c,'battle',150,n=>{draws++;return n-1;});assert.equal(r.captain.battleLevel,3);assert.equal(r.levels,2);assert.equal(r.captain.battleExperience,0);assert.equal(draws,8);assert.equal(r.captain.courage,54);assert.equal(r.captain.swordplay,52);
 assert.equal(gainExperience({...c,battleLevel:100},'battle',10000,()=>0).captain.battleExperience,0);assert.equal(experienceThreshold(100),9720);assert.equal(voyageExperience(100,1),9800);assert.equal(voyageExperience(100,6),10000);assert.equal(piracyFame(30,4,0,6),4250);assert.equal(piracyFame(30,1,0,6),0);assert.deepEqual(discoveryReward(100,80),{fame:1500,gold:80000});
});
const captain={id:0,luck:0,navigationLevel:1,seamanship:50,knowledge:50,intuition:50,status:0},ship={slot:0,captain,figurehead:0,durability:80,maximumDurability:80,modelDurability:80,power:80,tacking:80,stormWeak:false,crew:100,food:1000};
test('Storms cannot end on announcement day, damage ships, and leave fixed bounds',()=>{
 const region={wind:{speed:3,direction:2,anomalyFlags:2},current:{speed:2,direction:3,anomalyFlags:1}},s={...createWeather(),rng:123,anomaly:{kind:'storm',pending:true,announcedToday:false}};
 const r=weatherCheck(s,region,[ship],{protagonist:captain});assert.equal(r.weather.wind.speed,7);assert.equal(r.weather.anomaly.announcedToday,true);assert.ok(r.ships[0].durability<80);assert.equal(s.anomaly.pending,true);
 const ashore=weatherCheck(s,region,[ship],{protagonist:captain,ashore:true});assert.equal(ashore.ships[0].durability,80);
});
test('Voyage weather and illnesses replay from snapshots; cats prevent rats and remedies clear flags externally',()=>{
 for(let seed=1;seed<=500;seed++){const state={rng:seed,daysAtSea:100,rats:false,scurvy:false},a=illnessPass(state,[ship],captain,[25]),b=illnessPass(JSON.parse(JSON.stringify(state)),[ship],captain,[25]);assert.deepEqual(a,b);assert.equal(a.state.rats,false);assert.ok(a.ships[0].crew>=0);}
});
