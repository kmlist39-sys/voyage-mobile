import test from 'node:test';import assert from 'node:assert/strict';import {createBattle,applyBattleCommand,battleActions} from './core/naval-battle.mjs';import {reachableCourses,hexDistance,attackKind} from './core/battle-grid.mjs';
function unit(id,team,x,y,slot=0){return {id,team,side:team,main:true,flagship:slot===0,slot,x,y,heading:team?4:1,power:75,tacking:80,crew:100,bunks:120,maximumCrew:120,guns:40,gunType:4,shot:30,durability:65,maximumDurability:65,modelDurability:80,combatPercent:50,oared:false,captain:{id:team*10+slot,leadership:80,seamanship:80,swordplay:80,navigationLevel:20,battleLevel:20,courage:80,luck:75,skills:4}};}
test('50 complete naval encounters terminate by victory, defeat or nightfall and resume identically from saved turns',()=>{
 for(let seed=1;seed<=50;seed++){
  let s=createBattle({units:[unit('player',0,20,20),unit('escort',0,18,21,1),unit('enemy',1,25,21),unit('enemy2',1,27,23,1)],player:'player',seed,tick:50});let commands=0;
  while(s.phase!=='finished'){
   assert.ok(++commands<1000);let action;
   if(s.phase==='ai')action={type:'ADVANCE'};
   else{const u=s.units.find(u=>u.id===s.actor),target=s.units.find(t=>attackKind(u,t));
    if(target)action={type:'ATTACK',target:target.id};
    else if(s.phase==='attack')action={type:'WAIT'};
    else{const enemy=s.units.find(n=>n.id==='enemy'),routes=reachableCourses(u,{wind:s.wind,units:s.units});routes.sort((a,b)=>hexDistance(a,enemy)-hexDistance(b,enemy));action=routes.length?{type:'MOVE',directions:routes[0].directions}:{type:'WAIT'};}
   }
   const cmd={...action,id:`${seed}-${commands}`,revision:s.revision},a=applyBattleCommand(s,cmd),b=applyBattleCommand(JSON.parse(JSON.stringify(s)),cmd);assert.deepEqual(a,b);assert.equal(applyBattleCommand(a.state,cmd).state,a.state);s=a.state;
   for(const u of s.units){assert.ok(u.crew>=0&&u.shot>=0&&u.durability>=0);assert.ok(u.x>=0&&u.x<s.width&&u.y>=0&&u.y<s.height);}
  }
  assert.ok([1,2,3,4,5].includes(s.outcome));assert.ok(s.tick<=63);assert.deepEqual(battleActions(s),[]);
 }
});
test('Fleet alternation follows flagship-first round order and moves allow one attack only',()=>{
 let s=createBattle({units:[unit('p',0,20,20),unit('e',1,40,40),unit('p2',0,15,15,1)],player:'p',tick:24,seed:8});
 const course=reachableCourses(s.units[0],{wind:s.wind,units:s.units})[0];s=applyBattleCommand(s,{id:'move',revision:s.revision,type:'MOVE',directions:course.directions}).state;assert.equal(s.phase,'attack');assert.throws(()=>applyBattleCommand(s,{id:'twice',revision:s.revision,type:'MOVE',directions:course.directions}));
 s=applyBattleCommand(s,{id:'skip',revision:s.revision,type:'WAIT'}).state;assert.equal(s.actor,'e');s=applyBattleCommand(s,{id:'ai',revision:s.revision,type:'ADVANCE'}).state;assert.equal(s.actor,'p2');
});
test('Adjacent flagship challenge enters a resumable duel and decided result ends battle',()=>{
 let s=createBattle({units:[unit('p',0,20,20),{...unit('e',1,20,19),crew:1}],player:'p',seed:42});s=applyBattleCommand(s,{id:'challenge',revision:s.revision,type:'ATTACK',target:'e',challenge:true}).state;
 assert.equal(s.phase,'duel');assert.deepEqual(s.pendingDuel,{source:'p',target:'e',balance:100});s=applyBattleCommand(s,{id:'win',revision:s.revision,type:'DUEL_RESULT',winner:0,balance:200}).state;assert.equal(s.phase,'finished');assert.equal(s.outcome,6);
});
test('Night battle ends immediately; escape requires edge; invalid commands change no state',()=>{
 const units=[unit('p',0,20,20),unit('e',1,30,20)],night=createBattle({units,player:'p',tick:63});assert.equal(night.outcome,1);
 const s=createBattle({units,player:'p'}),before=JSON.stringify(s);assert.throws(()=>applyBattleCommand(s,{id:'escape',type:'ESCAPE',revision:0}));assert.equal(JSON.stringify(s),before);
 const edgeBattle=createBattle({units:[{...units[0],x:0},units[1]],player:'p'});assert.equal(applyBattleCommand(edgeBattle,{id:'exit',type:'ESCAPE',revision:0}).state.outcome,3);
});
