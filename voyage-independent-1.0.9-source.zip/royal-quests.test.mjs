import test from 'node:test';import assert from 'node:assert/strict';import {data} from './game-fixtures.mjs';import {VoyageGame} from './core/game.mjs';
let sequence=0;function command(g,type,args={}){g.command({id:'royal-'+(++sequence),type,...args});finish(g);}
function finish(g){for(let i=0;g.state.wait;i++){assert.ok(i<400);const r=g.state.wait;g.command({id:'answer-'+(++sequence),type:'STORY',action:r.type==='YES_NO'?'ANSWER':r.type==='MENU'?'CHOOSE':'CONTINUE',yes:true,choice:0});}}
function setup(section){const g=new VoyageGame(data);g.start(3,{},123);finish(g);g.enter(3,true);finish(g);g.host.set(1,3,0,500,2);g.enter(3,true);finish(g);assert.equal(g.director.state.shared.flags&(1<<17),1<<17,'harbor arms invitation');g.enter(5,true);finish(g);g.director.state.shared.variables[30]=section;command(g,'AUDIENCE');assert.equal(g.director.state.shared.section,section);assert.equal(g.director.state.shared.subsection,2);return g;}
function audience(g,port=33){g.state.mode='town';g.host.state.port=port;g.state.building=5;command(g,'AUDIENCE');}
for(const section of [6,7,8,9,10,11,12])test('Royal mission '+section+': invitation, offer, completion, rank and save continuation',()=>{
 let g=setup(section);g=new VoyageGame(data,JSON.parse(JSON.stringify(g.snapshot())));let q=g.director.state.shared;
 if(section===6)g.host.loadGoods(q.variables[18],q.variables[19]);
 if(section===7||section===8){const capital=g.host.get(0,q.variables[18],10);audience(g,capital);}
 if(section===9){for(let id=0;id<q.variables[19]+5;id++)g.host.set(12,id,19,(g.host.get(12,id,19)&248)|5);}
 if(section===10){g.host.set(16,0,6,32);g.host.set(16,0,5,100);}
 if(section===11){g.host.setGold(5000);g.state.building=6;command(g,'ROYAL_CLUE');g.host.state.port=q.variables[16];command(g,'ROYAL_CLUE');const id=q.variables[17];assert.ok(id>=79&&id<120);g.host.state.port=g.host.get(3,id,45);g.state.building=1;command(g,'QUEST_CONTACT',{sailor:id});const map=q.variables[18]-10,d=data.discoveries[g.host.get(17,map,24)];g.state.mode='sea';g.state.sea={x:d.x,y:d.y};g.explore();assert.ok(g.host.inventory().includes(q.variables[18]));}
 if(section===12){const fleet=q.variables[18]*10+1,id=g.host.get(8,fleet,42);g.state.wait=g.director.start('before-battle',161,id);g.resolveStory();finish(g);g.host.set(3,id,44,255);g.state.wait=g.director.start('after-battle',162,id);g.resolveStory();finish(g);}
 audience(g);assert.equal(g.director.state.shared.section,0);assert.equal(g.rank,1);
});
