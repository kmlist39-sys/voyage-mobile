// Analysis reference: Korean MAIN.EXE 0xB02C, 0x2C7A2, 0x2C935.
// Valid, nonnegative game values only. This does not implement a game UI.
const types=['water','food','lumber','shot'];
const integer=(n,label)=>{if(!Number.isSafeInteger(n)||n<0)throw new RangeError(label);return n};
const unit=k=>{if(!types.includes(k))throw new RangeError('Unknown supply type');return k==='water'||k==='food'?10:1};
export function cargoUsed(s){
 const basic=Math.trunc(integer(s.water,'water')/10)+Math.trunc(integer(s.food,'food')/10)+integer(s.lumber,'lumber')+integer(s.shot,'shot');
 if(s.goods.length!==5)throw new RangeError('Five cargo slots required');
 return basic+s.goods.reduce((total,g)=>total+(g.id===255?0:integer(g.quantity,'quantity')),0);
}
export function supplyUnitPrice(kind,rate){
 unit(kind);integer(rate,'rate');
 return kind==='water'?0:Math.trunc(({food:20,lumber:90,shot:120}[kind])*(rate+50)/100);
}
export function maximumSupplyLoad(s,maximumCargo,gold,kind,rate){
 const price=supplyUnitPrice(kind,rate),free=Math.max(0,integer(maximumCargo,'maximumCargo')-cargoUsed(s));
 integer(gold,'gold');return price===0?free:Math.min(free,Math.trunc(gold/price));
}
export function maximumSupplyUnload(s,kind){return Math.trunc(integer(s[kind],'quantity')/unit(kind));}
export function changeSupplies(s,maximumCargo,gold,kind,quantity,rate,mode){
 integer(quantity,'quantity');if(!['load','unload'].includes(mode))throw new RangeError('Unknown operation');
 const limit=mode==='load'?maximumSupplyLoad(s,maximumCargo,gold,kind,rate):maximumSupplyUnload(s,kind);
 if(quantity>limit)throw new RangeError('Quantity exceeds capacity, funds, or carried stock');
 const sign=mode==='load'?1:-1;
 return {supplies:{...s,[kind]:s[kind]+sign*quantity*unit(kind)},gold:gold-(mode==='load'?quantity*supplyUnitPrice(kind,rate):0)};
}
