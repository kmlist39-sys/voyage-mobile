import test from 'node:test';
import assert from 'node:assert/strict';
import {data} from './game-fixtures.mjs';
import {createBattlePractice} from './core/battle-practice.mjs';
import {nearbyFlagship} from './core/realtime-battle.mjs';

test('practice supplies survive sustained fire and allow moving, aiming, firing, and flagship approach',()=>{
  const g=createBattlePractice(data),p=()=>g.state.battle.units[0],enemy=()=>g.state.battle.units[1];
  assert.equal(p().durability,10000);assert.equal(p().crew,500);assert.equal(p().shot,1000);
  const start={x:enemy().x,y:enemy().y};
  for(let i=0;i<600;i++)g.updateBattle(.1,{});
  assert.equal(g.state.battle.phase,'active');assert.ok(p().durability>9900);assert.ok(p().crew>490);
  assert.deepEqual({x:enemy().x,y:enemy().y},start);
  const hull=enemy().durability;
  for(let i=0;i<40&&!nearbyFlagship(g.state.battle);i++)g.updateBattle(.1,{x:1,y:0,fire:true,aimX:enemy().x,aimY:enemy().y});
  assert.ok(p().x>22);assert.ok(p().shot<1000);assert.ok(enemy().durability<hull);
  assert.ok(nearbyFlagship(g.state.battle));
  g.command({id:'challenge',type:'BATTLE',action:'CHALLENGE',target:enemy().id});
  assert.equal(g.state.mode,'duel');
  for(let i=0;i<20&&g.state.mode==='duel';i++)g.command({id:'duel-'+i,type:'DUEL',move:i%3});
  assert.equal(g.state.mode,'battle');
  assert.ok(g.state.practice.result!==null||g.state.battle.phase==='active');
});

test('practice terminal results leave original records and a fresh retry intact',()=>{
  const g=createBattlePractice(data,{shipName:'시험선'}),records=g.host.snapshot();
  g.command({id:'end',type:'BATTLE',action:'SURRENDER'});
  assert.equal(g.state.practice.result,9);assert.equal(g.state.battle.phase,'finished');
  assert.deepEqual(g.host.snapshot(),records);
  const reset=createBattlePractice(data,g.state.practice);
  assert.equal(reset.ships[0].name,'시험선');assert.equal(reset.ships[0].shot,1000);
  assert.equal(reset.state.practice.result,null);
});
