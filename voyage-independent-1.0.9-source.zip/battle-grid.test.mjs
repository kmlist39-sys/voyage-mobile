import test from 'node:test';import assert from 'node:assert/strict';import {hexStep,hexDistance,broadside,attackKind,plotCourse,reachableCourses} from './core/battle-grid.mjs';
const ship={id:'a',x:20,y:20,heading:0,turnCharge:0,power:80,tacking:90,crew:100,guns:30,gunType:7,shot:10,durability:60,side:0,team:0,captain:{seamanship:90,navigationLevel:20}};
test('Odd-column hex coordinates are reversible and broadside arcs contain exactly 2d+2 hexes',()=>{
 for(let x=0;x<10;x++)for(let y=0;y<10;y++)for(let d=0;d<6;d++){const p={x,y},q=hexStep(p,d);assert.equal(hexDistance(p,q),1);assert.deepEqual(hexStep(q,(d+3)%6),p);}
 for(let heading=0;heading<6;heading++)for(let distance=2;distance<=5;distance++){let n=0,total=0;for(let x=10;x<=30;x++)for(let y=10;y<=30;y++)if(hexDistance(ship,{x,y})===distance){total++;if(broadside(ship,{x,y},heading))n++;}assert.equal(total,6*distance);assert.equal(n,2*distance+2);}
});
test('Attack availability observes ammunition, gun range, arc, alliance and crew',()=>{
 const enemy={...ship,id:'b',x:22,y:20,side:1,team:1};assert.equal(attackKind(ship,enemy),'cannon');assert.equal(attackKind({...ship,shot:0},enemy),null);assert.equal(attackKind(ship,{...enemy,x:20,y:18}),null);assert.equal(attackKind(ship,{...enemy,x:20,y:19}),'boarding');assert.equal(attackKind(ship,{...enemy,team:0}),null);
});
test('Reachable courses obey land, occupied crewless ships, wind cost and turn charge',()=>{
 const board={wind:{speed:4,direction:0},land:(x,y)=>x===21,units:[{...ship,id:'b',x:20,y:18,crew:0}]};const routes=reachableCourses(ship,board);assert.ok(routes.length>0);
 for(const r of routes){assert.deepEqual(plotCourse(ship,r.directions,board).path,r.path);assert.ok(r.remaining>=0);assert.ok(r.path.every(p=>p.x!==21&&!(p.x===20&&p.y===18)));}
 assert.throws(()=>plotCourse({...ship,tacking:0},[1],board));assert.throws(()=>plotCourse(ship,[3],board));
});
