$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$jdk=if($env:JAVA_HOME){$env:JAVA_HOME}else{'C:/Program Files/Android/Android Studio/jbr'}
$sdk=if($env:ANDROID_HOME){$env:ANDROID_HOME}else{"$env:LOCALAPPDATA/Android/Sdk"}
$env:JAVA_HOME=$jdk
$bt="$sdk/build-tools/35.0.0"
$androidJar="$sdk/platforms/android-34/android.jar"
$build="$PSScriptRoot/build"
$dist="$PSScriptRoot/dist"
New-Item -ItemType Directory -Force "$build/assets/game","$build/classes","$build/dex",$dist | Out-Null
& node "$PSScriptRoot/build-web.mjs"
Copy-Item -Path "$PSScriptRoot/web/*" -Destination "$build/assets/game" -Recurse -Force
& "$bt/aapt2.exe" compile --dir "$PSScriptRoot/android/res" -o "$build/icons.zip"
& "$bt/aapt2.exe" link -I $androidJar --manifest "$PSScriptRoot/android/AndroidManifest.xml" "$build/icons.zip" -o "$build/stage.apk"
& "$jdk/bin/jar.exe" --update --file "$build/stage.apk" -C $build assets
& "$jdk/bin/javac.exe" -encoding UTF-8 --release 8 -cp $androidJar -d "$build/classes" "$PSScriptRoot/android/src/VoyageActivity.java"
& "$jdk/bin/jar.exe" --create --file "$build/classes.jar" -C "$build/classes" .
& "$bt/d8.bat" --lib $androidJar --min-api 26 --output "$build/dex" "$build/classes.jar"
& "$jdk/bin/jar.exe" --update --file "$build/stage.apk" -C "$build/dex" classes.dex
& "$bt/zipalign.exe" -f 4 "$build/stage.apk" "$build/aligned.apk"
# A new local development key; the delivered APK's signing key is not distributed.
$key="$build/development-signing.jks"
if(!(Test-Path -LiteralPath $key)){& "$jdk/bin/keytool.exe" -genkeypair -keystore $key -storepass localdevelopment -keypass localdevelopment -alias local -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Local Independent Development'}
& "$bt/apksigner.bat" sign --v4-signing-enabled false --ks $key --ks-pass pass:localdevelopment --out "$dist/voyage-independent-local.apk" "$build/aligned.apk"
& "$bt/apksigner.bat" verify --verbose "$dist/voyage-independent-local.apk"
