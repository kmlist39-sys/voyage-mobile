import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {analysisDirectory} from './paths.mjs';
import {WIND_TABLE,fleetSpeed,moveStep,hullBlocked,steerStep} from './core/navigation-rules.mjs';
const oracle=JSON.parse(fs.readFileSync(path.join(analysisDirectory,'oracle/navigation.json')));
test('Korean sail response table and 2000 fleet calculations match',()=>{
 assert.deepEqual(WIND_TABLE,oracle.table);
 for(const c of oracle.speed)assert.equal(fleetSpeed(c.ships,c.wind,c.heading,{legacyOverflow:true}),c.result,JSON.stringify(c));
});
test('4000 original movement cases include 2x2 collisions, coastal slides and seams',()=>{
 for(const c of oracle.movement){const land=new Set(c.land.map(x=>x.join(','))),blocked=(x,y)=>hullBlocked(x,y,(a,b)=>land.has(`${a},${b}`)?0x34:0);
 assert.deepEqual(moveStep(c.input,blocked,{legacyPoleWrap:true}),{blocked:c.blocked,boundary:c.boundary,result:c.result},JSON.stringify(c));}
});
test('Stopped ships never drift; input changes direction on the next tick',()=>{
 const p={x:50,y:50,accumulatorX:30,accumulatorY:30,heading:8,speed:40,currentDirection:2,currentSpeed:7};
 assert.equal(steerStep(p,()=>0).result.x,50);assert.equal(steerStep({...p,heading:2},()=>0).result.x,51);
 assert.equal(steerStep({...p,heading:6},()=>0).result.x,49);
});
test('Corrected load arithmetic penalizes heavier ships and latitude never wraps',()=>{
 const s={power:80,tacking:80,crew:100,navigationPercent:100,load:250,capacity:1000,minimumCrew:100,sailType:1,oared:false,captain:{navigationLevel:0,seamanship:75}};
 const wind={direction:2,speed:8};let previous=100;
 for(let load=0;load<=1000;load++){const speed=fleetSpeed([{...s,load}],wind,2);assert.ok(speed<=previous);previous=speed;}
 const result=moveStep({x:50,y:1078,accumulatorX:30,accumulatorY:50,heading:4,speed:40,currentDirection:0,currentSpeed:0},()=>false);
 assert.equal(result.result.y,1078);
});
