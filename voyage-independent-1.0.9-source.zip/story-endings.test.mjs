import test from 'node:test';import assert from 'node:assert/strict';
import {openingRuns} from './story-playthrough.mjs';import {data} from './game-fixtures.mjs';import {VoyageGame} from './core/game.mjs';
import {initializeDiscoveries} from './core/discovery-start.mjs';import {random} from './core/random.mjs';
import {advanceCalendar} from './core/calendar.mjs';
function initialize(p){const rng={rng:123},r=initializeDiscoveries(data.discoveries.map(d=>({flags:d.typeAndFlags,contentId:d.contentId})),b=>random(rng,b));r.discoveries.forEach((d,i)=>{p.host.set(16,i,4,d.contentId);p.host.set(16,i,6,d.flags);});r.treasureItems.forEach(t=>p.host.set(17,t.itemId,24,t.discoveryId));}
function dig(p,map){assert.ok(p.host.inventory().includes(map));const id=p.host.get(17,map,24),d=data.discoveries[id],g=new VoyageGame(data);g.host=p.host;g.state.mode='sea';g.state.sea={x:d.x,y:d.y};g.explore();assert.ok(p.host.inventory().includes(map+10));assert.ok(!p.host.inventory().includes(map));assert.equal(p.host.get(16,id,6)&176,176);}
test('Catalina: all eight chapters, randomized searches, Perot, Massawa and Neo-Atlantis ending',()=>{
 const p=openingRuns()[1],v=(a,b,o={})=>p.visit(a,b,o);const battle=(f,win=false)=>{const c=p.host.get(8,f,42);v(161,c);if(win)p.host.set(3,c,44,255);v(162,c);};
 p.host.set(1,1,2,1,2);v(3,0);battle(15);battle(15);assert.equal(p.state.section,2);
 p.host.set(1,1,2,1500,2);v(3,0);p.host.set(1,1,2,2000,2);v(3,1);assert.equal(p.state.section,3);v(3,0);v(3,0);v(160,1);v(3,0);v(160,1);v(3,0,{tick:24});v(3,2);assert.equal(p.state.section,4);
 p.host.set(1,1,2,8000,2);v(160,3);v(3,0);v(3,1);const port=p.state.variables[16];v(port,1);v(port,0);v(port,1);
 const searching=p.state.subsection;for(let tick=24;tick<72&&p.state.subsection===searching;tick++)v(port,1,{tick});v(port,0);v(port,3);assert.equal(p.state.section,5);
 v(port===3?4:3,1);v(0,1,{tick:24});v(0,4);v(0,4);v(0,4);v(26,4);v(26,1);v(18,0);battle(60,true);assert.equal(p.state.section,6);
 p.host.set(1,1,2,15000,2);v(3,0);battle(11,true);v(74,0);v(74,3);v(74,0);battle(25);v(74,7);assert.equal(p.state.section,7);
 p.host.set(1,1,2,30000,2);v(160,5);v(3,4);v(0,7);for(let tick=25;tick<72&&p.state.subsection===3;tick++)v(43,0,{tick});v(43,1);v(43,3);assert.equal(v(161,p.host.get(8,15,42)).control,0);battle(61,true);assert.deepEqual(p.host.state.ending,{kind:'story',id:1});
});
test('Joao: all six chapters, both duels, pursuit, Massawa calendar wait and Neo-Atlantis ending',()=>{
 const p=openingRuns()[0],v=(a,b,o={})=>p.visit(a,b,{duel:200,...o});const battle=f=>{const c=p.host.get(8,f,42);v(161,c);v(162,c);};
 p.host.set(1,0,4,2000,2);v(3,3);v(3,1,{tick:24});v(3,2);v(3,3);v(0,7);v(0,5);v(0,7);v(0,3);v(160,1);assert.equal(p.state.section,2);
 p.host.set(1,0,4,8000,2);v(3,0);
 for(let cycle=1;cycle<=2;cycle++){v(3,1);for(let tick=24;tick<72&&p.state.subsection===cycle;tick++){v(3,0,{tick});v(3,3);v(160,1);}assert.equal(p.state.subsection,cycle+1);}
 v(3,3);v(161,1);v(162,1);v(3,1);v(0,1);v(76,1);v(2,4);assert.equal(p.state.section,3);
 p.host.set(1,0,4,16000,2);v(160,5);v(3,0);v(74,10);v(74,7);v(74,0);v(0,7);v(74,7);p.host.state.calendar={...p.host.state.calendar,month:6,day:11};v(74,7);v(74,7);v(74,3);battle(25);battle(25);v(74,0);v(74,7);v(74,3);assert.equal(p.state.section,4);
 p.host.set(1,0,4,30000,2);v(3,1);v(99,3);assert.equal(p.state.section,5);
 p.host.set(1,0,4,40000,2);v(3,0);v(0,6);v(98,7);
 for(let tick=13;tick<=51&&p.state.subsection===3;tick++){v(43,0,{tick});v(43,1);}
 v(43,3);p.host.state.calendar.day++;v(43,3,{tick:25});const c=p.host.get(8,15,42);assert.equal(v(161,c).control,0);v(161,60);p.host.set(3,60,44,255);v(162,60);v(0,7);assert.deepEqual(p.host.state.ending,{kind:'story',id:0});
});
test('Otto: all six chapters, timed appointment, Spanish pursuit and final battle ending',()=>{
 const p=openingRuns()[2];const battle=f=>{const c=p.host.get(8,f,42);p.visit(161,c);p.visit(162,c);};
 p.visit(3,0);battle(18);assert.equal(p.state.section,2);
 p.host.set(1,2,2,5000,2);p.visit(3,1,{tick:24});p.visit(3,0,{tick:24});p.visit(3,1,{tick:30});assert.equal(p.state.section,3);
 p.host.set(1,2,2,20000,2);p.visit(3,0);assert.equal(p.state.section,4);
 p.host.set(1,2,2,30000,2);p.visit(3,3);p.visit(29,5);p.visit(29,6);battle(15);assert.equal(p.state.subsection,4);
 p.visit(43,0);battle(15);assert.equal(p.state.subsection,7);const c=p.host.get(8,15,42);assert.equal(p.visit(161,c).control,0);p.visit(160,5);assert.equal(p.state.section,5);
 p.visit(3,3);p.visit(3,1);p.visit(3,0);assert.equal(p.state.subsection,3);
 for(let i=0;i<32*72&&!(p.host.get(8,60,41)&64);i++){const r=advanceCalendar(p.host.state.calendar);p.host.state.calendar=r.calendar;if(r.events.some(e=>e.type==='MIDNIGHT'))p.visit(160,7);}
 assert.equal(p.host.get(8,60,41)&64,64);p.visit(161,60);p.host.set(3,60,44,255);p.visit(162,60);p.visit(29,5);assert.deepEqual(p.host.state.ending,{kind:'story',id:2});
});
test('Ernst: all five chapters and Changan ending, including exact fame gates and saved choices',()=>{
 const p=openingRuns()[3];p.host.set(1,3,4,999,2);p.visit(33,3);assert.equal(p.state.section,1);p.host.set(1,3,4,1000,2);p.visit(33,3);assert.equal(p.state.section,2);
 p.host.set(1,3,4,5000,2);p.visit(0,3);assert.equal(p.state.section,2);p.visit(43,3);assert.equal(p.state.section,3);p.host.set(1,3,4,20000,2);p.visit(43,3);assert.equal(p.state.section,4);
 p.host.set(1,3,4,40000,2);p.visit(43,3);assert.equal(p.state.subsection,0);p.visit(43,3);assert.equal(p.state.subsection,1);p.visit(94,3);assert.equal(p.state.subsection,2);p.visit(98,3);p.visit(98,1);assert.equal(p.state.subsection,3);
 for(let tick=0;tick<72&&p.state.subsection===3;tick++)p.visit(98,3,{tick});assert.equal(p.state.subsection,4);p.visit(97,7);assert.deepEqual(p.host.state.ending,{kind:'story',id:3});
});
test('Pietro: all four chapters, both actual treasure searches, pointer comparison and ending',()=>{
 const p=openingRuns()[4];initialize(p);p.host.setGold(9999);p.visit(57,1);assert.equal(p.state.subsection,0);p.host.setGold(10000);p.visit(57,1,{yes:false});assert.equal(p.state.subsection,1);assert.equal(p.host.gold(),9000);dig(p,87);p.visit(57,3);assert.equal(p.state.section,2);
 p.host.set(1,4,4,10000,2);p.visit(0,7);p.visit(0,3);assert.equal(p.state.subsection,1);p.visit(72,1);const fortune=p.state.variables[16];p.visit(fortune,11);const brother=p.state.variables[18];p.visit(brother,1);assert.equal(p.state.subsection,2);dig(p,88);p.visit(74,1);assert.equal(p.state.section,3);assert.ok(!p.host.inventory().includes(98));
 p.host.set(1,4,4,40000,2);p.visit(0,3);p.visit(98,3);p.visit(99,3);assert.equal(p.state.subsection,2);p.visit(56,3);assert.equal(p.state.subsection,3);p.visit(0,7);assert.deepEqual(p.host.state.ending,{kind:'story',id:4});
});
test('Ali: debt repayments, title, decoy, six voyages, Ottoman expansion and the house ending',()=>{
 const p=openingRuns()[5];p.host.setGold(1000000);for(const b of [1,3,8,2])p.visit(2,b);p.host.set(1,5,13,1);p.visit(2,0);p.visit(2,4);assert.equal(p.state.subsection,1);p.visit(2,21);assert.equal(p.state.section,2);
 p.host.setGold(1000000);p.visit(2,0);p.visit(160,1);p.visit(2,1);p.visit(2,3);assert.equal(p.state.subsection,2);const cancelled=p.visit(161,1);assert.equal(cancelled.control,0);assert.equal(p.state.subsection,3);for(let i=0;i<5;i++)p.visit(160,5);p.visit(2,1);assert.equal(p.state.subsection,3);p.visit(160,5);p.visit(2,1);assert.equal(p.state.subsection,4);p.visit(76,1);p.visit(2,1);assert.equal(p.state.section,3);
 for(let i=0;i<30;i++)p.host.set(12,i,19,(p.host.get(12,i,19)&248)|2);p.visit(3,3);p.visit(2,8);p.visit(13,8,{yes:false});assert.equal(p.state.section,4);p.visit(2,21);assert.equal(p.state.section,5);
 p.host.set(1,5,0,40000,2);p.visit(3,3);p.visit(3,1);assert.equal(p.state.subsection,1);p.visit(76,1);assert.equal(p.state.subsection,2);p.visit(2,1);p.visit(13,8);p.host.setGold(200000000);p.visit(13,8);assert.equal(p.state.subsection,3);p.visit(2,1);assert.deepEqual(p.host.state.ending,{kind:'story',id:5});
});
