import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {analysisDirectory} from './paths.mjs';
import {evaluateDice,compareDice,resolveDice,dicePayout,nextDiceStarter} from './core/dice-rules.mjs';
import {createDiceSession,applyDiceCommand,diceActions,saveDiceSession,restoreDiceSession} from './core/dice-session.mjs';
const oracleRoot=path.join(analysisDirectory,'oracle'),oracle=JSON.parse(fs.readFileSync(path.join(oracleRoot,'dice.json')));
const hands=oracle.multisets.map(h=>h.map(v=>v===6?1:v+1));
const command=(s,type,extra={})=>({id:`${s.round}:${s.revision}:${type}`,revision:s.revision,type,...extra});
function apply(s,type,extra={}){const r=applyDiceCommand(s,command(s,type,extra));assert.equal(r.ok,true,r.error);return r.state;}
function enterPlayer(s){s=apply(s,'BET',{amount:Math.min(s.gold,500)});if(s.phase==='offer')s=apply(s,'ACCEPT');while(s.turn!==0)s=apply(s,'ADVANCE');return s;}
function complete(s){for(let n=0;n<20&&s.phase==='turn';n++)s=apply(s,s.turn===0?'ROLL':'ADVANCE');assert.equal(s.phase,'settled');return s;}

test('Korean oracle belongs to the audited executable and has intact triple results',()=>{
 assert.equal(oracle.sha256,'1718bbbbcdd938dfe44403d9bd5254dfc02d431217dea39ae5fb3fcde1597747');
 const bytes=fs.readFileSync(path.join(oracleRoot,oracle.tripleFile));assert.equal(bytes.length,343000*2);
 assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),oracle.tripleSha256);
 assert.equal(oracle.representativeIndices.length,70);
});
test('All 7776 ordered five-dice categories match isolated Korean execution',()=>{
 let at=0;for(let a=1;a<=6;a++)for(let b=1;b<=6;b++)for(let c=1;c<=6;c++)for(let d=1;d<=6;d++)for(let e=1;e<=6;e++)assert.equal(evaluateDice([a,b,c,d,e]).category,oracle.orderedRollCategories[at++]);assert.equal(at,7776);
});
test('All 12672 same-category comparisons match isolated Korean execution',()=>{
 assert.equal(oracle.sameCategoryComparisons.length,12672);
 for(const [i,j,result] of oracle.sameCategoryComparisons)assert.equal(({1:0,'-1':1,0:3})[compareDice(hands[i],hands[j])],result,`${i},${j}`);
});
test('All 343000 representative triples differ only in seven audited defect cases',()=>{
 const bytes=fs.readFileSync(path.join(oracleRoot,oracle.tripleFile)),groups={};let at=0,same=0;
 for(const i of oracle.representativeIndices)for(const j of oracle.representativeIndices)for(const k of oracle.representativeIndices){
  const r=resolveDice([hands[i],hands[j],hands[k]]),old=bytes.readUInt16LE(at++*2);
  if(r.resultCode===old){same++;continue;}
  const categories=r.scores.map(s=>s.category);assert.equal(new Set(categories).size,1);
  const key=categories.join(',')+' / '+old+' -> '+r.resultCode;groups[key]=(groups[key]||0)+1;
  // Each documented case must also have its expected ordering relation.
  const ab=compareDice(hands[i],hands[j]),ac=compareDice(hands[i],hands[k]),bc=compareDice(hands[j],hands[k]);
  if(old===0xcafe&&categories[0]!==0){assert.equal(ac,0);assert.equal(ab,1);}
  if(categories[0]===2){assert.equal(ab,old===1?1:-1);assert.equal(ac,-1);assert.notEqual(bc,0);}
  if(categories[0]===1||categories[0]===0){assert.equal(ab,0);assert.equal(ac,0);}
 }
 assert.equal(same,342606);assert.deepEqual(groups,{
  '6,6,6 / 51966 -> 6':15,'3,3,3 / 51966 -> 6':15,'2,2,2 / 1 -> 2':119,
  '1,1,1 / 2 -> 4':6,'2,2,2 / 3 -> 2':119,'2,2,2 / 3 -> 1':119,'0,0,0 / 51966 -> 4':1});
});
test('Original no-hand result depends on stale stack; remake always returns a three-way draw',()=>{
 assert.deepEqual(oracle.allNoHandStackExperiments.map(x=>x.result),oracle.allNoHandStackExperiments.map(x=>x.stackWord));
 assert.equal(resolveDice([[1,2,3,4,5],[1,2,3,4,6],[2,3,4,5,6]]).resultCode,4);
});
test('Dice ranks preserve ones-high, unusual two-pair order, no kickers and no straights',()=>{
 assert.ok(compareDice([1,1,2,3,4],[6,6,2,3,4])>0);
 assert.ok(compareDice([2,2,6,6,4],[3,3,4,4,6])<0);
 assert.equal(compareDice([4,4,1,2,3],[4,4,2,5,6]),0);
 assert.equal(evaluateDice([1,2,3,4,5]).category,0);
 assert.throws(()=>evaluateDice([0,1,2,3,4]));assert.throws(()=>evaluateDice([1,2,3]));
});
test('Every stake and winner set conserves payout semantics and rotates starter to a winner',()=>{
 for(let stake=10;stake<=500;stake++)for(const winners of [[0],[1],[2],[0,1],[0,2],[1,2],[0,1,2]]){
  assert.equal(dicePayout(stake,winners),winners.includes(0)?Math.floor(3*stake/winners.length):0);
  for(let start=0;start<3;start++)assert.equal(nextDiceStarter(start,winners),[start,(start+1)%3,(start+2)%3].find(i=>winners.includes(i)));
 }
 assert.equal(dicePayout(11,[0,2]),16);assert.throws(()=>dicePayout(9,[0]));
});
test('A direct bet debits once, repeated touch is ignored, and stale/illegal input has no side effects',()=>{
 const s=createDiceSession({gold:1000,seed:4}),cmd=command(s,'BET',{amount:500}),r=applyDiceCommand(s,cmd);
 assert.equal(r.ok,true);assert.equal(r.state.gold,500);assert.equal(s.gold,1000);
 const repeated=applyDiceCommand(r.state,cmd);assert.equal(repeated.duplicate,true);assert.equal(repeated.state,r.state);
 for(const bad of [{...cmd,id:'late'},{...command(r.state,'BET'),amount:500},command(r.state,'FINISH_TURN')]){
  const rejected=applyDiceCommand(r.state,bad);assert.equal(rejected.ok,false);assert.equal(rejected.state,r.state);assert.deepEqual(rejected.events,[]);
 }
});
test('Bet bounds, negotiation, cancellation and low funds expose explicit actions',()=>{
 assert.deepEqual(diceActions(createDiceSession({gold:9})),[]);
 for(const amount of [0,9,101,NaN,10.5])assert.equal(applyDiceCommand(createDiceSession({gold:100}),{id:'bad',revision:0,type:'BET',amount}).ok,false);
 const seen=new Set();
 for(let seed=1;seed<=300;seed++){
  let s=createDiceSession({gold:100,seed});s=apply(s,'BET',{amount:90});seen.add(s.phase);
  if(s.phase==='offer'){
   assert.equal(s.gold,100);assert.equal(apply(s,'EXIT').gold,100);
   assert.equal(apply(s,'ACCEPT').gold,100-Math.min(s.proposal,100));
   const counter=apply(s,'REFUSE');assert.ok(counter.stake>=90&&counter.stake<=100);assert.equal(counter.gold,100-counter.stake);
  }
 }
 assert.deepEqual(seen,new Set(['offer','turn']));
});
test('Die selection uses stable identity, toggles before reroll, and stays locked after committing',()=>{
 let s=enterPlayer(createDiceSession({gold:1000,seed:42}));s=apply(s,'ROLL');
 const die=s.hands[0].dice[3];s=apply(s,'TOGGLE_HOLD',{dieId:die.id});s=apply(s,'TOGGLE_HOLD',{dieId:die.id});assert.equal(s.hands[0].pending.length,0);
 s=apply(s,'TOGGLE_HOLD',{dieId:die.id});s=apply(s,'ROLL');
 assert.equal(s.hands[0].dice.find(d=>d.id===die.id).face,die.face);assert.equal(s.hands[0].rolls,2);
 const bad=applyDiceCommand(s,command(s,'TOGGLE_HOLD',{dieId:die.id}));assert.equal(bad.ok,false);assert.equal(bad.state,s);
 s=apply(s,'ROLL');assert.equal(s.hands[0].rolls,3);assert.equal(s.hands[0].finished,true);
});
test('Keeping all five dice finishes without an extra roll; confirming early also progresses',()=>{
 let s=apply(enterPlayer(createDiceSession({gold:1000,seed:31})),'ROLL');
 for(const d of s.hands[0].dice)s=apply(s,'TOGGLE_HOLD',{dieId:d.id});
 s=apply(s,'ROLL');assert.equal(s.hands[0].rolls,1);assert.equal(s.hands[0].finished,true);
 let early=apply(enterPlayer(createDiceSession({gold:1000,seed:31})),'ROLL');early=apply(early,'FINISH_TURN');assert.equal(early.hands[0].rolls,1);assert.equal(early.hands[0].finished,true);
});
test('Save during hold selection preserves both reversible selection and committed dice identity',()=>{
 let s=apply(enterPlayer(createDiceSession({gold:1000,seed:182})),'ROLL');const first=s.hands[0].dice[0].id;
 s=apply(s,'TOGGLE_HOLD',{dieId:first});const a=apply(s,'ROLL'),b=apply(restoreDiceSession(saveDiceSession(s)),'ROLL');assert.deepEqual(a,b);
 const second=a.hands[0].dice.find(d=>d.id!==first).id,selected=apply(a,'TOGGLE_HOLD',{dieId:second});
 assert.deepEqual(apply(selected,'ROLL'),apply(restoreDiceSession(saveDiceSession(selected)),'ROLL'));
});
test('1000 seeded rounds finish in bounded actions and restore identically at every boundary',()=>{
 const stages=new Set();
 for(let seed=1;seed<=1000;seed++){
  let s=createDiceSession({gold:2000,seed}),n=0;
  while(s.phase!=='settled'){
   assert.ok(++n<20,'state machine stalled');stages.add(s.phase);
   let type,extra={};
   if(s.phase==='betting'){type='BET';extra={amount:11};}
   else if(s.phase==='offer')type=seed%2?'ACCEPT':'REFUSE';
   else type=s.turn?'ADVANCE':'ROLL';
   const cmd=command(s,type,extra),a=applyDiceCommand(s,cmd),b=applyDiceCommand(restoreDiceSession(saveDiceSession(s)),cmd);
   assert.equal(a.ok,true,a.error);assert.deepEqual(a,b);s=a.state;
  }
  assert.equal(s.gold,2000-s.stake+s.result.payout);assert.equal(s.turnsCompleted,3);
  assert.ok(s.hands.every(h=>h.rolls>=1&&h.rolls<=3));
  assert.deepEqual(restoreDiceSession(saveDiceSession(s)),s);
  const next=apply(s,'NEXT_ROUND');assert.equal(next.round,2);assert.equal(next.turn,s.starter);assert.equal(next.gold,s.gold);assert.equal(next.phase,'betting');
 }
 assert.deepEqual(stages,new Set(['betting','offer','turn']));
});
test('Corrupt saves reject invalid dice, duplicate ids, stale payout, impossible phase and schema',()=>{
 const settled=complete(enterPlayer(createDiceSession({gold:1000,seed:5})));
 for(const change of [s=>s.version=2,s=>s.rng=0,s=>s.hands[0].dice[0].face=8,s=>s.hands[0].dice[0].id=s.hands[0].dice[1].id,s=>s.result.payout++,s=>s.turnsCompleted=2,s=>s.phase='betting']){
  const bad=structuredClone(settled);change(bad);assert.throws(()=>restoreDiceSession(JSON.stringify(bad)));
 }
 assert.throws(()=>restoreDiceSession('{'));
});
test('Production dice modules have no filesystem, executable, emulator or input-simulation imports',()=>{
 for(const file of ['dice-rules.mjs','dice-session.mjs']){
  const source=fs.readFileSync(new URL('./core/'+file,import.meta.url),'utf8');
  for(const match of source.matchAll(/(?:import|from)\s*['"]([^'"]+)['"]/g))assert.ok(match[1].startsWith('./'),'unexpected runtime dependency: '+match[1]);
  assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|eval|setTimeout|setInterval)\s*\(/);
 }
});
