import test from 'node:test';import assert from 'node:assert/strict';import {openingRuns,StoryPlayer,data} from './story-playthrough.mjs';import {GameRecords} from './core/game-records.mjs';
test('All six actual Korean opening scripts advance to chapter one with world mutations and saves at every dialogue',()=>{
 const players=openingRuns(),gold=[1000,0,10300,5000,5000,4000],shipType=[5,10,10,5,5,5],crew=[0,120,150,0,10,0];
 for(let i=0;i<6;i++){const p=players[i];assert.equal(p.state.section,1,'chapter '+i);assert.equal(p.state.subsection,0);assert.equal(p.host.gold(),gold[i]);const ships=p.host.ships();assert.equal(ships.length,1);assert.equal(ships[0].type,shipType[i]);assert.equal(ships[0].crew,crew[i]);assert.equal(ships[0].captain.id,i);assert.ok(p.transcript.length>35);assert.equal(p.transcript.filter(t=>/\$[drns]/.test(t.body)).length,0);assert.equal(p.host.mates().length,i===0?3:1);}
 assert.equal(players[1].host.get(3,1,49)&15,6);assert.equal(players[1].host.ships()[0].goods[0].id,31);assert.equal(players[4].host.get(2,0,4,2),0);
});
test('Name changes remain complete in story text and full ship names survive save/load',()=>{
 const p=new StoryPlayer(3);p.host.setProtagonist(3,{firstName:'바다를 사랑하는 항해자',lastName:'김'});p.visit(33,7);
 assert.ok(p.transcript.some(t=>t.body.includes('바다를 사랑하는 항해자')));const ship=p.host.ships()[0];p.host.writeText(p.host.reference(10,ship.instance,0),'푸른 바다를 건너는 메르카토르호');const restored=new GameRecords(data,JSON.parse(JSON.stringify(p.host.snapshot())));assert.equal(restored.ships()[0].name,'푸른 바다를 건너는 메르카토르호');
});
test('Story cargo mutates actual slots atomically, query and unload return real quantities',()=>{
 const p=new StoryPlayer(4);p.visit(8,3);p.visit(8,1);const free=p.host.freeCargo();assert.ok(free>0);p.host.loadGoods(11,free);assert.equal(p.host.freeCargo(),0);assert.equal(p.host.unloadGoods(11,0),free);
 const before=p.host.snapshot();assert.throws(()=>p.host.loadGoods(12,1));assert.deepEqual(p.host.snapshot(),before);assert.equal(p.host.unloadGoods(11,free+10),free);assert.equal(p.host.unloadGoods(11,0),0);
});
test('Repeated mate joins cannot duplicate the roster or reset assigned duty',()=>{const p=new StoryPlayer(0);p.visit(0,7);p.host.set(3,69,46,3);p.host.joinSailor(69);assert.equal(p.host.mates().filter(id=>id===69).length,1);assert.equal(p.host.get(3,69,46),3);});
