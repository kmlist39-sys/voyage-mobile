import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {analysisDirectory} from './paths.mjs';
import {movementPoints,turningRate,movementCost,boardingKills,cannonDamage,duelDamage,npcDuelEquipment,npcDuelMove,firepower,challengeChance} from './core/combat-rules.mjs';
const oracle=JSON.parse(fs.readFileSync(path.join(analysisDirectory,'oracle/combat.json')));
function recorded(list){let at=0;return {draw:n=>{const r=list[at++];assert.ok(r,'unexpected random draw');assert.equal(n,r.bound);return r.value;},done:()=>assert.equal(at,list.length)};}
test('1500 Korean movement/turn/cost cases match independent battle rules',()=>{for(const c of oracle.movement){assert.equal(movementPoints(c.input),c.movementPoints);assert.equal(turningRate(c.input),c.turnRate);assert.equal(movementCost(c.input),c.stepCost);}});
for(const [key,fn] of [['boarding',boardingKills],['cannon',cannonDamage],['duel',duelDamage]])test(`${oracle[key].length} Korean ${key} functions match with exact random call order`,()=>{for(const c of oracle[key]){const r=recorded(c.random);assert.equal(fn(c.input,r.draw),c.result,JSON.stringify(c));r.done();}});
test('Gun ranges and minimum broadside distance are enforced',()=>{assert.deepEqual([1,2,3,4,5,6].map(d=>firepower(7,d)),[0,200,180,160,140,0]);assert.equal(firepower(2,3),0);});
test('NPC duel equipment and move probabilities respect each family',()=>{
 assert.deepEqual(npcDuelEquipment(0,0),{armor:20,weapon:15,family:2});assert.deepEqual(npcDuelEquipment(26,24),{armor:40,weapon:30,family:3});
 for(let family=0;family<4;family++){const count=[0,0,0];for(let r=0;r<10;r++)count[npcDuelMove({attacking:true,family},r)]++;assert.deepEqual(count,[[3,4,3],[6,2,2],[2,6,2],[2,2,6]][family]);}
 assert.equal(challengeChance(50,60,20),.5);assert.equal(challengeChance(60,60,0),1);assert.equal(challengeChance(50,60,10),0);
});
