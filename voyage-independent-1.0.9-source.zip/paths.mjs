import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {homedir} from 'node:os';

export const packageDirectory=path.dirname(fileURLToPath(import.meta.url));
export const analysisDirectory=path.join(packageDirectory,'analysis');
export const originalDirectory=process.env.UW2_ORIGINAL_DIR||path.resolve(packageDirectory,'../original/Uncharted Waters 2 Korean Edition');
export const referenceDirectory=process.env.UW2_REFERENCE_DIR||path.resolve(packageDirectory,'../research');
export const archivePath=process.env.UW2_ARCHIVE_PATH||path.join(homedir(),'Downloads/Uncharted Waters 2 Korean Edition.zip');
