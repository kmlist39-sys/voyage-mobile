import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
import {analysisDirectory} from './paths.mjs';import {consumeDaily,consumeResource,departureCheck} from './core/voyage-supplies.mjs';
const oracle=JSON.parse(fs.readFileSync(path.join(analysisDirectory,'oracle/consumption.json')));
test('2000 original food and water fleet passes match, including legacy donor bug',()=>{
 for(const c of oracle.cases){const actual=consumeDaily(c.ships,c.ration,c.ashore,{legacyDonorHealth:true}).ships.map(({crew,food,water,health})=>({crew,food,water,health}));assert.deepEqual(actual,c.result,JSON.stringify(c));}
});
test('Supply sharing updates the receiving crew health without unsigned crew wipeout',()=>{
 const ships=[{crew:100,food:2000,water:2000,health:0,captain:{leadership:0}},{crew:100,food:0,water:0,health:100,captain:{leadership:100}}];
 const fixed=consumeResource(ships,'food',100,false).ships,legacy=consumeResource(ships,'food',100,false,{legacyDonorHealth:true}).ships;
 assert.equal(fixed[1].crew,100);assert.equal(legacy[1].crew,0);assert.equal(fixed[1].health,100);assert.equal(ships[0].food,2000);
});
test('Ashore halves consumption; no partial-donor refill; departure rejects missing navigation crew',()=>{
 const s={crew:100,food:1,water:101,health:100,navigationPercent:100,captain:{leadership:100}};
 assert.equal(consumeResource([s],'water',100,true).ships[0].water,50);
 const p=consumeResource([s,{...s,food:1000}],'food',100,false).ships;assert.equal(p[1].food,899);
 assert.equal(departureCheck([{...s,food:100}]).ok,true);assert.equal(departureCheck([{...s,food:100,navigationPercent:0}]).ok,false);
});
