import test from 'node:test';import assert from 'node:assert/strict';
import {data} from './game-fixtures.mjs';import {VoyageGame} from './core/game.mjs';
const command=(g,type,args={})=>g.command({id:'flagship-'+g.state.revision,type,...args});
function fleet(){const g=new VoyageGame(data);g.host.setProtagonist(3);g.state.mode='town';g.state.building=2;g.host.setGold(1000000);g.host.createPendingShip(5);g.host.commissionShip('첫 번째 배');g.host.joinSailor(69);g.host.set(15,0,0,5);command(g,'BUY_SHIP',{stock:0,name:'두 번째 배'});g.host.writeShip({...g.ship(0),crew:30,water:400,food:400,shot:11});return g;}
test('Buying a second ship then changing flagship preserves hulls, crew, cargo and one admiral across save, departure and battle',()=>{
 let g=fleet();const own=g.captain.id,oldCaptain=g.ship(1).captain.id,physical=g.ships.map(({captain,...ship})=>ship),funds=g.host.gold();
 command(g,'ASSIGN_CAPTAIN',{slot:1,sailor:own});assert.equal(g.ship(1).captain.id,own);assert.equal(g.ship(0).captain.id,oldCaptain);assert.equal(g.host.get(3,own,46),1);assert.equal(g.host.get(3,oldCaptain,46),2);assert.deepEqual(g.ships.map(({captain,...ship})=>ship),physical);assert.equal(g.host.gold(),funds);
 g=new VoyageGame(data,g.snapshot());assert.equal(g.ships.find(s=>s.captain.id===own).name,'두 번째 배');
 command(g,'TRANSFER_CREW',{from:0,to:1,quantity:15});command(g,'TRANSFER_CARGO',{from:0,to:1,kind:'water',quantity:20});command(g,'TRANSFER_CARGO',{from:0,to:1,kind:'food',quantity:20});g.state.building=3;command(g,'SAIL');assert.equal(g.state.mode,'sea');assert.equal(g.ships.filter(s=>s.captain.id===own).length,1);
 g.beginBattle(15);assert.equal(g.state.battle.player,'p1');assert.equal(g.state.battle.units.find(s=>s.id==='p1').name,'두 번째 배');assert(g.state.battle.units.find(s=>s.id==='p1').flagship);assert(!g.state.battle.units.find(s=>s.id==='p0').flagship);
});
test('Switching back retains unique assignments; the new flagship is protected from sale and transfer is blocked at sea',()=>{
 const g=fleet(),own=g.captain.id;command(g,'ASSIGN_CAPTAIN',{slot:1,sailor:own});let before=g.snapshot();assert.throws(()=>command(g,'SELL_SHIP',{slot:1}),/기함/);assert.deepEqual(g.snapshot(),before);
 command(g,'ASSIGN_CAPTAIN',{slot:0,sailor:own});assert.equal(g.ship(0).captain.id,own);assert.equal(new Set(g.ships.map(s=>s.captain.id)).size,2);
 g.state.mode='sea';before=g.snapshot();assert.throws(()=>command(g,'ASSIGN_CAPTAIN',{slot:1,sailor:own}),/정박/);assert.deepEqual(g.snapshot(),before);
});
