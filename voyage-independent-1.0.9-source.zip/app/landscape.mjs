import {contours,traceContours,periodicCell,deterministicNoise as noise} from './terrain-geometry.mjs';
const canvas=(w,h=w)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;};
const CELL=24,CHUNK=16,PAD=3;
export class Landscape{
 constructor(art){this.art=art;this.patterns=new Map();this.chunks=new Map();}
 texture(g,index,tint,alpha=.25){
  const key=index+':'+tint+':'+alpha;let c=this.patterns.get(key);
  if(!c){const sw=this.art.naturalWidth/4,sh=this.art.naturalHeight/4,span=144;c=canvas(span*2);const p=c.getContext('2d');
   for(let y=0;y<2;y++)for(let x=0;x<2;x++){p.save();p.translate(x*span+(x?span:0),y*span+(y?span:0));p.scale(x?-1:1,y?-1:1);p.drawImage(this.art,(index%4)*sw+14,Math.floor(index/4)*sh+14,sw-28,sh-28,0,0,span,span);p.restore();}
   p.fillStyle=tint;p.globalAlpha=alpha;p.fillRect(0,0,c.width,c.height);this.patterns.set(key,c);
  }return g.createPattern(c,'repeat');
 }
 water(g,w,h,ox,oy,sx,sy,time=0,harbor=false){
  const gradient=g.createLinearGradient(0,0,w*.35,h);gradient.addColorStop(0,harbor?'#245d68':'#174a61');gradient.addColorStop(.55,harbor?'#267680':'#205f75');gradient.addColorStop(1,harbor?'#174854':'#103c54');g.fillStyle=gradient;g.fillRect(0,0,w,h);
  const ripples=this.texture(g,4,'#205c70',.45);ripples.setTransform(new DOMMatrix().translate(ox+Math.sin(time*.18)*5,oy+time*.4%288).scale(sx/CELL,sy/CELL));g.save();g.globalAlpha=harbor?.11:.13;g.fillStyle=ripples;g.fillRect(0,0,w,h);g.restore();
  // Broad, sparse currents, continuous in world space: no repeated water tiles.
  const left=Math.floor(-ox/sx/3)*3,top=Math.floor(-oy/sy/2)*2;g.lineCap='round';
  for(let y=top;y<(h-oy)/sy+2;y+=2)for(let x=left;x<(w-ox)/sx+3;x+=3){const n=noise(periodicCell(x),y),px=ox+(x+n*2)*sx,py=oy+(y+noise(y,x))*sy,drift=Math.sin(time*.65+n*8)*sx*.14;
   g.strokeStyle=`rgba(168,218,218,${.08+n*.08})`;g.lineWidth=1;g.beginPath();g.moveTo(px-sx*.45+drift,py);g.bezierCurveTo(px-sx*.1+drift,py-sy*.09,px+sx*.12+drift,py+sy*.1,px+sx*.5+drift,py);g.stroke();
  }
 }
 shore(g,loops,scale,offsetX,offsetY,landFill,{harbor=false}={}){
  traceContours(g,loops,scale,offsetX,offsetY);g.lineJoin='round';
  // Depth bands stay on the water side after the land fill covers their inside.
  for(let i=16;i>=1;i--){g.strokeStyle=i>8?'#45a09d0c':'#91c4b51a';g.lineWidth=i*.105*scale;g.stroke();}
  g.fillStyle=landFill;g.fill('evenodd');
  g.save();g.clip('evenodd');g.strokeStyle='#344d3d45';g.lineWidth=scale*.38;g.stroke();g.strokeStyle=harbor?'#bba681':'#d6c393';g.lineWidth=scale*(harbor?.18:.22);g.stroke();g.strokeStyle='#eee3bbb0';g.lineWidth=scale*.045;g.stroke();g.restore();
 }
 seaChunk(world,cx,cy){
  const wx=periodicCell(cx*CHUNK),wy=cy*CHUNK,key=wx+','+wy;if(this.chunks.has(key)){const old=this.chunks.get(key);this.chunks.delete(key);this.chunks.set(key,old);return old;}
  const left=wx-PAD,top=wy-PAD,span=CHUNK+PAD*2,c=canvas(span*CELL),g=c.getContext('2d');
  const loops=contours((x,y)=>world.tile(x,y)>=52,left,top,span,span);
  const grass=this.texture(g,0,'#6d7955',.53);grass.setTransform(new DOMMatrix().translate(-left*CELL,-top*CELL));
  this.shore(g,loops,CELL,left,top,grass);
  // Soft interior variation is unrelated to the old tile code, avoiding checkerboards.
  traceContours(g,loops,CELL,left,top);g.save();g.clip('evenodd');
  for(let y=top-4;y<top+span+4;y+=4)for(let x=left-4;x<left+span+4;x+=4){const n=noise(periodicCell(x),y),px=(x-left)*CELL,py=(y-top)*CELL,r=CELL*(2+n*2),a=g.createRadialGradient(px,py,0,px,py,r);a.addColorStop(0,n>.5?'#bbc08a30':'#263e2b24');a.addColorStop(1,'#47634400');g.fillStyle=a;g.fillRect(px-r,py-r,r*2,r*2);}g.restore();
  const out=canvas(CHUNK*CELL);out.getContext('2d').drawImage(c,PAD*CELL,PAD*CELL,out.width,out.height,0,0,out.width,out.height);this.chunks.set(key,out);while(this.chunks.size>16)this.chunks.delete(this.chunks.keys().next().value);return out;
 }
 sea(g,world,w,h,view,time){const {ox,oy,sx,sy}=view;this.water(g,w,h,ox,oy,sx,sy,time);const left=Math.floor(-ox/sx/CHUNK),top=Math.floor(-oy/sy/CHUNK),right=Math.floor((w-ox)/sx/CHUNK),bottom=Math.floor((h-oy)/sy/CHUNK),key=[left,top,right,bottom].join(',');
  // Join cached chunks at integer texture coordinates before scaling. Separate
  // drawImage calls leave hairline water seams at fractional camera positions.
  if(this.seaComposite?.key!==key){const image=canvas((right-left+1)*CHUNK*CELL,(bottom-top+1)*CHUNK*CELL),p=image.getContext('2d');for(let y=top;y<=bottom;y++)for(let x=left;x<=right;x++)p.drawImage(this.seaChunk(world,x,y),(x-left)*CHUNK*CELL,(y-top)*CHUNK*CELL);this.seaComposite={key,image};}
  const image=this.seaComposite.image;g.drawImage(image,ox+left*CHUNK*sx,oy+top*CHUNK*sy,image.width/CELL*sx,image.height/CELL*sy);
 }
 town(layout){const surface=Uint8Array.from(atob(layout.surface),c=>c.charCodeAt(0)),c=canvas(96*CELL),g=c.getContext('2d'),get=(x,y)=>surface[Math.max(0,Math.min(95,y))*96+Math.max(0,Math.min(95,x))],region=fn=>contours((x,y)=>fn(get(x,y)),0,0,96,96);
  this.water(g,c.width,c.height,0,0,CELL,CELL,0,true);const land=region(k=>k!==4);this.shore(g,land,CELL,0,0,this.texture(g,0,'#58704b',.28),{harbor:true});
  traceContours(g,land,CELL);g.save();g.clip('evenodd');
  for(const [kind,index,tint,alpha]of [[1,1,'#aa9471',.24],[2,2,'#9c967c',.5]]){
   const shape=region(k=>k===kind);traceContours(g,shape,CELL);g.strokeStyle=kind===1?'#b19b7380':'#8a8d6e75';g.lineWidth=CELL*.36;g.stroke();g.fillStyle=this.texture(g,index,tint,alpha);g.fill('evenodd');g.strokeStyle=kind===1?'#c8b28b4d':'#a9a28855';g.lineWidth=CELL*.09;g.stroke();
  }
  // Door aprons and contact shadows blend buildings into the ground plane.
  for(const b of layout.objects){const x=b.cx*CELL,y=b.base*CELL,r=b.w*CELL*.56;
   g.save();g.translate(x,y);g.scale(1,.34);const a=g.createRadialGradient(0,0,0,0,0,r);a.addColorStop(0,'#b6a78680');a.addColorStop(.68,'#a69d7c38');a.addColorStop(1,'#a69d7c00');g.fillStyle=a;g.fillRect(-r,-r,r*2,r*2);g.restore();
   g.save();g.translate(x,y);g.scale(1,.28);const shade=g.createRadialGradient(0,0,r*.1,0,0,r);shade.addColorStop(0,'#293a2a75');shade.addColorStop(1,'#293a2a00');g.fillStyle=shade;g.fillRect(-r,-r,r*2,r*2);g.restore();
   if(b.facility){const dx=(b.x+1)*CELL,dy=(b.y+2.4)*CELL;g.save();g.beginPath();g.ellipse(dx,dy,CELL*1.05,CELL*.75,0,0,Math.PI*2);g.fillStyle=this.texture(g,2,'#b7aa8a',.5);g.fill();g.restore();}
  }
  // Fine verge details are kept off the road and entrance tile centres.
  for(let y=1;y<95;y++)for(let x=1;x<95;x++){if(get(x,y)!==0||![get(x-1,y),get(x+1,y),get(x,y-1),get(x,y+1)].some(k=>k===1||k===2))continue;const n=noise(x,y);if(n<.3)continue;const px=(x+.2+n*.6)*CELL,py=(y+.3+noise(y,x)*.4)*CELL;g.fillStyle=n>.7?'#73855488':'#d6c69b77';g.beginPath();g.ellipse(px,py,1+n*2,.7+n,0,0,Math.PI*2);g.fill();}
  g.restore();c.waterSurface=surface;return c;
 }
 townRipples(g,surface,w,h,{ox,oy,sx,sy},time){g.lineWidth=1;g.lineCap='round';for(let y=Math.max(1,Math.floor(-oy/sy/3)*3);y<Math.min(94,(h-oy)/sy);y+=3)for(let x=Math.max(1,Math.floor(-ox/sx/3)*3);x<Math.min(94,(w-ox)/sx);x+=3){if(surface[y*96+x]!==4||surface[y*96+x-1]!==4||surface[y*96+x+1]!==4)continue;const n=noise(x,y),a=.05+Math.max(0,Math.sin(time*.8+n*12))*.12,px=ox+(x+.5)*sx,py=oy+(y+n)*sy;g.strokeStyle='rgba(196,229,221,'+a+')';g.beginPath();g.moveTo(px-sx*.45,py);g.quadraticCurveTo(px,py-sy*.08,px+sx*.45,py);g.stroke();}}
}
