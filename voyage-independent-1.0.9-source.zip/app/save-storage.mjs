// Keep the synchronous save API, but compress repeated routes/record bytes before
// using WebView's small localStorage quota. Legacy JSON saves remain readable.
const CLEAR=256, END=257, FIRST=258, LIMIT=65535, MAX_BYTES=32*1024*1024;
function packRoutes(key,value){
 if(key!=='route'||!Array.isArray(value)||value.length<20||!value.every(p=>p&&Object.keys(p).every(k=>['x','y','heading'].includes(k))&&Number.isInteger(p.x)&&p.x>=0&&p.x<65536&&Number.isInteger(p.y)&&p.y>=0&&p.y<65536&&(p.heading===undefined||Number.isInteger(p.heading)&&p.heading>=-1&&p.heading<=15)))return value;
 let bytes='';for(const p of value)bytes+=String.fromCharCode(p.x&255,p.x>>>8,p.y&255,p.y>>>8,p.heading===undefined?255:p.heading+1);
 return {$voyageRoute:btoa(bytes)};
}
function unpackRoutes(key,value){if(key!=='route'||!value?.$voyageRoute)return value;const s=atob(value.$voyageRoute);if(s.length%5)throw new Error('항로 저장 손상');const route=[];for(let i=0;i<s.length;i+=5){const p={x:s.charCodeAt(i)|(s.charCodeAt(i+1)<<8),y:s.charCodeAt(i+2)|(s.charCodeAt(i+3)<<8)},h=s.charCodeAt(i+4);if(h!==255)p.heading=h-1;route.push(p);}return route;}
export function encodeRecord(record){
 const bytes=new TextEncoder().encode(JSON.stringify(record,packRoutes)),codes=[CLEAR];
 let dict=new Map(),next=FIRST,word='';
 for(const byte of bytes){const ch=String.fromCharCode(byte),both=word+ch;
  if(dict.has(both)){word=both;continue;}
  if(word)codes.push(word.length===1?word.charCodeAt(0):dict.get(word));
  if(word){if(next<LIMIT)dict.set(both,next++);else{codes.push(CLEAR);dict=new Map();next=FIRST;}}
  word=ch;
 }
 if(word)codes.push(word.length===1?word.charCodeAt(0):dict.get(word));codes.push(END);
 let binary='';for(let i=0;i<codes.length;i+=4096){const chunk=[];for(const c of codes.slice(i,i+4096))chunk.push(c&255,c>>>8);binary+=String.fromCharCode(...chunk);}
 return JSON.stringify({storage:1,codec:'lzw16',data:btoa(binary)});
}
export function decodeRecord(text){
 const value=JSON.parse(text);if(value?.storage!==1)return value;
 if(value.codec!=='lzw16'||typeof value.data!=='string')throw new Error('저장 형식 오류');
 const binary=atob(value.data);if(binary.length%2)throw new Error('저장 길이 오류');
 let dict=[],next=FIRST,previous='',size=0,ended=false;const chunks=[];
 for(let i=0;i<binary.length;i+=2){const code=binary.charCodeAt(i)|(binary.charCodeAt(i+1)<<8);
  if(code===CLEAR){dict=[];next=FIRST;previous='';continue;}if(code===END){ended=true;break;}
  const word=code<256?String.fromCharCode(code):dict[code]??(code===next&&previous?previous+previous[0]:null);
  if(word===null)throw new Error('저장 데이터 손상');size+=word.length;if(size>MAX_BYTES)throw new Error('저장 데이터 크기 초과');chunks.push(word);
  if(previous&&next<LIMIT)dict[next++]=previous+word[0];previous=word;
 }
 if(!ended)throw new Error('저장 데이터 중단');const raw=chunks.join('');return JSON.parse(new TextDecoder().decode(Uint8Array.from(raw,c=>c.charCodeAt(0))),unpackRoutes);
}
export function readRecord(storage,key){for(const suffix of ['', '-backup']){try{const r=decodeRecord(storage.getItem(key+suffix));if(r?.format===2&&r.snapshot?.version===2)return r;}catch{}}return null;}
export function writeRecord(storage,key,record){
 const packed=encodeRecord(record),old=readRecord(storage,key);
 // setItem is atomic: a failed write preserves the previous primary record.
 storage.setItem(key,packed);
 if(storage.getItem(key)!==packed)throw new Error('기록을 다시 읽을 수 없습니다.');
 if(old){try{storage.setItem(key+'-backup',encodeRecord(old));}catch{/* A backup must never prevent or misreport a successful primary save. */}}
 return true;
}
