export const SEA_ZOOMS=[14,20,28,40];
export const SEA_ZOOM_NAMES=['아주 넓게','넓게','보통','가깝게'];
export function seaScale(zoom=1){return SEA_ZOOMS[Math.max(0,Math.min(SEA_ZOOMS.length-1,Number.isInteger(zoom)?zoom:1))];}
export function seaSpriteSizes(scale){return {player:Math.max(38,scale*2.4),fleet:Math.max(30,scale*1.65),port:Math.max(26,scale*1.25),hit:44};}
