// Continuous contours through cell-edge midpoints. Tile centres keep their
// original land/water classification, including one-cell channels and islands.
const CASES=[[],[[3,0]],[[0,1]],[[3,1]],[[1,2]],[[3,0],[1,2]],[[0,2]],[[3,2]],[[2,3]],[[2,0]],[[0,1],[2,3]],[[2,1]],[[1,3]],[[1,0]],[[0,3]],[]];
export function contours(sample,left,top,width,height){
 const edges=[],adj=new Map(),key=p=>p.join(','),add=(a,b)=>{const id=edges.length;edges.push([a,b]);for(const p of [a,b]){const k=key(p);if(!adj.has(k))adj.set(k,[]);adj.get(k).push(id);}};
 for(let y=top-1;y<top+height;y++)for(let x=left-1;x<left+width;x++){
  const inside=(a,b)=>a>=left&&b>=top&&a<left+width&&b<top+height&&sample(a,b);
  const code=(inside(x,y)?1:0)|(inside(x+1,y)?2:0)|(inside(x+1,y+1)?4:0)|(inside(x,y+1)?8:0);
  const p=[[2*x+2,2*y+1],[2*x+3,2*y+2],[2*x+2,2*y+3],[2*x+1,2*y+2]];
  for(const [a,b]of CASES[code])add(p[a],p[b]);
 }
 const used=new Uint8Array(edges.length),loops=[];
 for(let start=0;start<edges.length;start++){if(used[start])continue;let id=start,current=edges[id][0];const first=key(current),loop=[];
  do{used[id]=1;loop.push(current.map(n=>n/2));const e=edges[id],next=key(e[0])===key(current)?e[1]:e[0];current=next;if(key(current)===first)break;id=adj.get(key(current)).find(i=>!used[i]);}while(id!==undefined);
  if(loop.length>2)loops.push(loop);
 }
 return loops;
}
export function traceContours(ctx,loops,scale=1,offsetX=0,offsetY=0){
 ctx.beginPath();for(const p of loops){if(!p.length)continue;const last=p.at(-1);ctx.moveTo(((last[0]+p[0][0])/2-offsetX)*scale,((last[1]+p[0][1])/2-offsetY)*scale);
  for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];ctx.quadraticCurveTo((a[0]-offsetX)*scale,(a[1]-offsetY)*scale,((a[0]+b[0])/2-offsetX)*scale,((a[1]+b[1])/2-offsetY)*scale);}ctx.closePath();
 }
}
export function periodicCell(x,width=2160){return ((x%width)+width)%width;}
export function deterministicNoise(x,y){const n=Math.sin(x*127.1+y*311.7)*43758.5453;return n-Math.floor(n);}
