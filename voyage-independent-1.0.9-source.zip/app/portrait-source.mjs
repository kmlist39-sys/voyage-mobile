export function validPortrait(id){return Number.isInteger(id)&&id>=0&&id<128?id:null;}
export function sailorPortrait(host,id){return validPortrait(host.get(3,id,26,2));}
export function dialoguePortrait(pane,building){const id=validPortrait(pane.character);return id!==null?{kind:'person',id}:Number.isInteger(building)&&building>=0&&building<12?{kind:'vendor',id:building}:{kind:'none'};}
