if(!globalThis.structuredClone)globalThis.structuredClone=x=>JSON.parse(JSON.stringify(x));
if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{value:function(n){return this[n<0?this.length+n:n];}});
if(!Array.prototype.findLast)Object.defineProperty(Array.prototype,'findLast',{value:function(fn){for(let i=this.length-1;i>=0;i--)if(fn(this[i],i,this))return this[i];}});
if(!Array.prototype.findLastIndex)Object.defineProperty(Array.prototype,'findLastIndex',{value:function(fn){for(let i=this.length-1;i>=0;i--)if(fn(this[i],i,this))return i;return -1;}});
if(!Array.prototype.toSorted)Object.defineProperty(Array.prototype,'toSorted',{value:function(fn){return this.slice().sort(fn);}});
if(!CanvasRenderingContext2D.prototype.roundRect)CanvasRenderingContext2D.prototype.roundRect=function(x,y,w,h,r){r=Math.min(Number(r)||0,w/2,h/2);this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y+h,x,y,r);this.arcTo(x,y,x+w,y,r);this.closePath();};
