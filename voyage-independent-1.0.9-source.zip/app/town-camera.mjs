const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export const TOWN_ZOOMS=[.8,1,1.3,1.65];
export const TOWN_ZOOM_NAMES=['아주 넓게','넓게','보통','가까이'];
export function townTileSize(width,height,level=1){
 const base=width<height?17:width<600?18:20;
 return base*TOWN_ZOOMS[clamp(Number.isInteger(level)?level:1,0,TOWN_ZOOMS.length-1)];
}
export function townProjection(width,height,focus,level=1,top=54,bottom=64){
 const sx=townTileSize(width,height,level),sy=sx*.82;
 const centerY=top+Math.max(0,height-top-bottom)/2;
 const ox=clamp(width/2-focus.x*sx,Math.min(0,width-96*sx),0);
 const oy=clamp(centerY-focus.y*sy,Math.min(top,height-bottom-96*sy),top);
 return {mode:'town',ox,oy,sx,sy};
}
