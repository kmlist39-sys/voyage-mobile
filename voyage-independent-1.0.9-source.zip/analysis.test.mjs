import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {analysisDirectory} from './paths.mjs';
import {shipSpeed,fleetSpeed,legacyLoadFactor,intendedLoadFactor,windRegion} from './rule-model.mjs';
import {cargoUsed,supplyUnitPrice,maximumSupplyLoad,maximumSupplyUnload,changeSupplies} from './supply-model.mjs';
const root=analysisDirectory+'/';
const read=name=>JSON.parse(fs.readFileSync(root+name));
test('All working original files match the user-supplied ZIP',()=>{
 const m=read('source-manifest.json');assert.equal(m.files.length,61);assert(m.files.every(f=>f.zipMatch));assert.equal(m.files.reduce((s,f)=>s+f.bytes,0),m.totalBytes);
});
test('Korean save stride accounts exactly for all ten slots',()=>{
 const s=read('save-layout.json');assert.equal(s.slotBytes,33340);assert.equal(s.totalBytes,s.headerBytes+10*s.slotBytes);assert.equal(s.sailorRecordBytes,50);
});
test('All 120 sailor records have complete Korean names and valid attributes',()=>{
 const s=read('data/sailors.json');assert.equal(s.length,120);for(const p of s){assert(p.firstName);assert(p.lastName);assert(!/[�\x00]/.test(p.firstName+p.lastName));assert(Object.values(p.attributes).every(n=>n>=0&&n<=100));assert(p.fleet<70||p.fleet>=254);}
 assert.deepEqual(s.slice(0,6).map(p=>p.firstName),['조안','카탈리나','옷토','에르네스트','피에트로','알']);
 assert.equal(s[2].age,25);assert.equal(s.filter(p=>p.englishTailEqual).length,119);
});
test('25 ship models preserve the source stats, names and crew limits',()=>{
 const s=read('data/ships.json');assert.equal(s.length,25);for(const p of s){assert(p.name&&!p.name.includes('�'));assert(p.capacity>0);assert(p.minimumCrew>0);assert(p.sailType<8);assert(p.usedGuns<=p.maximumGuns);}
 assert.equal(s[11].name,'지벡');assert.equal(s[11].capacity,600);assert.equal(s[11].tacking,80);assert.equal(s[11].power,70);
});
test('Every port refers to a valid town and all doors remain inside it',()=>{
 const ports=read('data/ports.json');assert.equal(ports.length,130);for(const p of ports){assert(p.x>=0&&p.x<2160);assert(p.y>=0&&p.y<1080);assert(p.map<=100);assert(p.tileset<7);assert(p.name&&!p.name.includes('�'));for(const b of p.buildings){assert(b.x>=0&&b.x<96&&b.y>=0&&b.y<96);}}
 assert.equal(ports[0].name,'리스본');assert(ports.slice(100).every(p=>p.map===100&&p.tileset===3));
});
test('All 130 port coordinates resolve to the corresponding world-map marker',()=>{
 const maps=[0,1,2].map(i=>fs.readFileSync(root+'data/world-'+i+'.bin'));
 for(const p of read('data/ports.json')){const tile=maps[Math.floor(p.x/720)][p.y*720+p.x%720];assert.equal(tile,p.id<100?0x74:0x78,'port '+p.id+' '+p.name);}
});
test('Town maps and world maps have no missing rows or columns',()=>{
 const t=read('data/town-maps.json');assert.equal(t.maps.length,101);assert(t.maps.every(m=>Buffer.from(m.dataBase64,'base64').length===96*96));for(let i=0;i<3;i++)assert.equal(fs.statSync(root+'data/world-'+i+'.bin').size,720*1080);
});
test('All market and shop references point to defined goods/items',()=>{
 const goods=read('data/goods.json'),markets=read('data/markets.json');assert.equal(goods.length,46);assert(goods.every(g=>g.category>=0&&g.category<10&&!g.name.includes('�')));assert.equal(markets.length,13);for(const m of markets){assert.equal(m.salePrices.length,46);for(const b of m.buy)assert(b.good<46);}
 for(const p of read('data/ports.json').filter(p=>p.id<100)){assert(p.market<13);assert(p.rates.length===10);for(const i of p.shop)assert(i<100);}
});
test('Item text uses the Korean 124-byte stride without broken multibyte characters',()=>{
 const a=read('data/items.json');assert.equal(a.length,100);assert(a.every(i=>!i.name.includes('�')&&!i.description.includes('�')));assert(a[1].description.startsWith('길이 ８０'));assert(a[2].description.startsWith('길이 １미터'));
});
test('Discovery texts do not include their picture byte as a leading character',()=>{
 const a=read('data/discoveries.json');assert.equal(a.length,100);
 assert(a.every(d=>!/[\x00-\x09\x0B-\x1F�]/.test(d.description)));
 assert.equal(a[0].picture,57);assert(a[0].description.startsWith('중앙에 환상열석'));assert(a[1].description.startsWith('고대 이집트'));
 assert(a.slice(0,98).every(d=>d.name&&d.picture<99));
});
test('All 61 menus decode every choice and consume the exact record',()=>{
 const a=read('data/menus.json');assert.equal(a.length,61);for(const m of a){assert.equal(m.rows.length,m.count);assert.equal(m.consumedBytes,m.bytes);assert(m.rows.every(s=>!s.includes('�')));}
 assert.deepEqual(a[0].rows.map(s=>s.replaceAll(' ','')),['예금','출금','대출','상환']);assert.equal(a[15].rows[3],'항해자와대화');
});
test('Korean VM dispatcher record starts agree with every decoded table',()=>{
 const a=read('record-layout.json');assert.equal(a.records.length,20);assert.equal(a.references.length,878);
 assert(a.references.every(r=>r.fieldWithinRecord&&r.indexInRange!==false));
 const tables={sailors:'sailors',namedCharacters:'named-characters',pubCharacters:'pub-characters',fleets:'fleets',ports:'ports',portEconomies:'ports',markets:'markets',discoveries:'discoveries',items:'items'};
 for(const [key,file] of Object.entries(tables)){
  const r=a.records.find(x=>x.key===key),data=read('data/'+file+'.json').slice(0,r.count);
  for(const [index,item] of data.entries()){const s=key==='portEconomies'?item.metadataSource:item.source;assert.equal(s.offset,r.slotOffset+index*r.recordBytes,key+' '+index);assert.equal(s.length,r.recordBytes);}
 }
 assert.equal(read('save-layout.json').portMetadataOffset,23884);
});
test('Reviewed static findings identify Korean executable evidence and retain runtime gaps',()=>{
 const a=read('static-evidence.json');assert.equal(a.rules.length,8);assert(a.rules.every(r=>r.status==='korean-static-reviewed'&&!r.runtimeDifferentialVerified));
 assert.equal(read('item-message-layout.json').recordStride,124);
});
const supplies={water:19,food:29,lumber:3,shot:4,goods:[{id:1,quantity:5},...Array.from({length:4},()=>({id:255,quantity:999}))]};
test('Cargo truncates food and water separately and ignores empty goods slots',()=>{
 assert.equal(cargoUsed(supplies),15);assert.equal(maximumSupplyUnload(supplies,'water'),1);assert.equal(maximumSupplyUnload(supplies,'food'),2);
});
test('Supply limits account for free water, funds, and occupied cargo independently',()=>{
 assert.deepEqual(['water','food','lumber','shot'].map(k=>supplyUnitPrice(k,100)),[0,30,135,180]);
 assert.equal(maximumSupplyLoad(supplies,20,0,'water',100),5);
 assert.equal(maximumSupplyLoad(supplies,20,89,'food',100),2);
 assert.equal(maximumSupplyLoad(supplies,20,99999,'shot',100),5);
 assert.equal(maximumSupplyLoad(supplies,15,99999,'food',100),0);
});
test('Supply operations preserve fractional stock and unload gives no refund',()=>{
 const loaded=changeSupplies(supplies,20,89,'food',2,100,'load');assert.equal(loaded.supplies.food,49);assert.equal(loaded.gold,29);assert.equal(supplies.food,29);
 const unloaded=changeSupplies(loaded.supplies,20,29,'food',4,100,'unload');assert.equal(unloaded.supplies.food,9);assert.equal(unloaded.gold,29);
 assert.throws(()=>changeSupplies(supplies,20,89,'food',3,100,'load'),RangeError);
 assert.throws(()=>changeSupplies(supplies,20,89,'water',2,100,'unload'),RangeError);
});
for(let id=0;id<7;id++)test('Story '+id+': valid instruction boundaries, destinations and message references',()=>{
 const s=read('stories/SNR'+id+'.json'),all=s.sections.flatMap(s=>s.instructions),offsets=new Set(all.map(i=>i.offset));
 assert(all.length>0);assert(all.every(i=>i.kind!=='invalid'));
 for(const section of s.sections){for(const edge of section.controlFlowEdges)assert(offsets.has(edge.to),'destination '+edge.to);for(const ins of section.instructions)assert.equal(ins.rawHex.length/2,ins.endOffset-ins.offset);for(const run of section.dialogueRuns)for(const line of run.lines)if(line.generalMessageIndex===undefined)assert(line.messageId>=0&&line.messageId<s.messages.length);}
 assert(s.messages.every(m=>!m.body.includes('�')));
});
const wind=read('data/wind-current.json'),table=wind.sailWind;
const ship={sailType:5,tacking:90,power:75,minimumCrew:10,capacity:120,crew:30,navigationPercent:50,load:60,oared:false,captain:{navigationLevel:5,seamanship:60}};
test('Speed reference: north 12, east 15, south 10; east at wind 3 is 22',()=>{
 assert.deepEqual([0,2,4].map(h=>shipSpeed(ship,ship.captain,{direction:0,speed:2},h,table)),[12,15,10]);assert.equal(shipSpeed(ship,ship.captain,{direction:0,speed:3},2,table),22);
});
test('Fleet is limited by its slowest ship; calm distinguishes sails and oars',()=>{
 const slower={...ship,power:40};assert.equal(fleetSpeed([ship,slower],{direction:0,speed:2},2,table),fleetSpeed([slower],{direction:0,speed:2},2,table));assert.equal(fleetSpeed([ship],{direction:0,speed:0},0,table),0);assert(fleetSpeed([{...ship,oared:true}],{direction:0,speed:0},0,table)>0);assert.equal(fleetSpeed([],{direction:0,speed:2},0,table),0);
});
test('Documented 16-bit cargo overflow is explicit, not silently built into a corrected model',()=>{
 assert.equal(legacyLoadFactor(327,600),126);assert.equal(legacyLoadFactor(328,600),150);assert.equal(intendedLoadFactor(328,600),126);
 assert.equal(legacyLoadFactor(250,120),150);assert.equal(intendedLoadFactor(250,120),0);
});
test('Wind grid uses all three world parts, correct seasons and edge bounds',()=>{
 assert.equal(windRegion(0,0,4,wind).region,0);assert.equal(windRegion(2159,1079,9,wind).region,449);assert.equal(windRegion(720,0,3,wind).region,10);assert.deepEqual(windRegion(0,0,10,wind).wind,wind.tables[1][0]);assert.throws(()=>windRegion(2160,0,1,wind));assert.throws(()=>windRegion(0,1080,1,wind));
});
