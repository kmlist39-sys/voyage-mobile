import test from 'node:test';import assert from 'node:assert/strict';import {createDuel,duelActions,applyDuelCommand} from './core/duel-session.mjs';import {npcDuelEquipment} from './core/combat-rules.mjs';
test('1000 duels finish within 20 exchanges and replay identically after each saved choice',()=>{
 for(let seed=1;seed<=1000;seed++){const c={swordplay:40+seed%61,battleLevel:seed%41,...npcDuelEquipment(seed%41,seed%41)},d={swordplay:40+(seed*7)%61,battleLevel:seed*3%41,...npcDuelEquipment(seed*5%41,seed*3%41)};let s=createDuel({challenger:c,defender:d,seed,player:seed%2});
  while(s.phase==='choice'){const cmd={id:`${seed}-${s.exchange}`,type:'MOVE',move:(seed+s.exchange)%3,revision:s.revision};assert.equal(duelActions(s).length,3);const a=applyDuelCommand(s,cmd),b=applyDuelCommand(JSON.parse(JSON.stringify(s)),cmd);assert.deepEqual(a,b);assert.equal(applyDuelCommand(a.state,cmd).state,a.state);assert.ok(a.state.balance>=0&&a.state.balance<=200);s=a.state;}
  assert.ok(s.exchange<=20);assert.equal(duelActions(s).length,0);
 }
});
test('Bad duel input cannot advance exchange, random state or balance',()=>{const c={swordplay:80,battleLevel:20,weapon:25,family:2,armor:30},s=createDuel({challenger:c,defender:c});const before=JSON.stringify(s);assert.throws(()=>applyDuelCommand(s,{id:'bad',type:'MOVE',move:3,revision:0}));assert.equal(JSON.stringify(s),before);});
