// Independent real-time naval combat. Simulation uses a fixed 25 ms step so
// touch input, projectiles and saved battles do not depend on display frame rate.
import {random,validateCommand,commitCommand} from './random.mjs';
import {GUNS,cannonDamage,boardingKills} from './combat-rules.mjs';
export const BATTLE_STEP=.025, DUEL_RANGE=2.6;
export const alive=u=>!!u&&!u.left&&u.crew>0&&u.durability>0;
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export const gunRange=u=>u.guns>0?(GUNS[u.gunType]?.range??0)*2+3:0;
export function cannonStatus(u){return !alive(u)?'전투 불가':!u.guns||!GUNS[u.gunType]?.range?'대포 미장착':u.shot<=0?'포탄 없음':u.reload>0?'재장전 중':'발사 준비';}
export function realtimeBattle(original){
 if(original.realtime)return original;
 const s=structuredClone(original);s.realtime=true;s.version=2;s.elapsed=0;s.accumulator=0;s.projectiles=[];s.effects=[];s.projectileId=0;s.target=null;s.startTick=s.tick;s.arenaId=s.rng+':'+s.terrain.reduce((a,v,i)=>(a+(v?i:0))>>>0,0);
 for(const u of s.units){u.y+=u.x%2*.5;u.angle=u.heading*Math.PI/3-Math.PI/2;u.aim=u.angle;u.reload=u.id===s.player?0:1.5;u.boardingReload=0;u.duelCooldown=0;}
 if(['command','attack','ai'].includes(s.phase)||s.outcome===1){s.phase='active';s.outcome=null;}s.actor=s.player;return s;
}
export function nearbyFlagship(s){const u=s.units.find(u=>u.id===s.player);return s.units.filter(t=>alive(t)&&t.team!==u.team&&t.flagship&&distance(u,t)<=DUEL_RANGE).sort((a,b)=>distance(u,a)-distance(u,b))[0]??null;}
function finish(s,outcome){s.phase='finished';s.outcome=outcome;s.pendingDuel=null;}
function checkResult(s){const own=s.units.find(u=>u.id===s.player),enemy=s.units.find(u=>u.main&&u.flagship&&u.team!==own.team);if(!alive(own))finish(s,own.left?3:5);else if(!alive(enemy))finish(s,enemy?.left?2:4);else if(s.elapsed>=900)finish(s,1);}
function navigable(s,x,y){if(x<.6||y<.6||x>s.width-1.6||y>s.height-1.6)return false;const col=Math.round(x),row=Math.round(y-(col%2)*.5);return !s.terrain[row*s.width+col];}
function move(s,u,dx,dy,dt){const length=Math.hypot(dx,dy);if(length<.01)return;dx/=length;dy/=length;const angle=Math.atan2(dy,dx),delta=Math.atan2(Math.sin(angle-u.angle),Math.cos(angle-u.angle));u.angle+=Math.max(-dt*3.8,Math.min(dt*3.8,delta));u.heading=(Math.round((u.angle+Math.PI/2)*3/Math.PI)%6+6)%6;
 const speed=(.9+u.power/65)*(u.crew>0?1:0),step=speed*dt*Math.min(1,length),x=u.x+dx*step,y=u.y+dy*step,free=(a,b)=>navigable(s,a,b)&&!s.units.some(t=>t.id!==u.id&&alive(t)&&Math.hypot(a-t.x,b-t.y)<1.05);
 if(free(x,y)){u.x=x;u.y=y;}else if(free(x,u.y))u.x=x;else if(free(u.x,y))u.y=y;
}
function shoot(s,u,angle,events){if(cannonStatus(u)!=='발사 준비')return false;
 u.shot--;u.reload=Math.max(.8,1.8-u.guns/180);u.aim=angle;const range=gunRange(u);
 s.projectiles.push({id:++s.projectileId,source:u.id,team:u.team,x:u.x,y:u.y,dx:Math.cos(angle),dy:Math.sin(angle),travel:0,range});events.push({type:'SHOT_FIRED',ship:u.id,remaining:u.shot});return true;
}
function segmentDistance(px,py,ax,ay,bx,by){const dx=bx-ax,dy=by-ay,t=Math.max(0,Math.min(1,((px-ax)*dx+(py-ay)*dy)/(dx*dx+dy*dy||1)));return {distance:Math.hypot(px-ax-t*dx,py-ay-t*dy),t};}
function projectiles(s,dt,events){const keep=[];for(const p of s.projectiles){const step=Math.min(13*dt,p.range-p.travel),nx=p.x+p.dx*step,ny=p.y+p.dy*step;
 const hit=s.units.filter(u=>u.team!==p.team&&alive(u)).map(u=>({u,...segmentDistance(u.x,u.y,p.x,p.y,nx,ny)})).filter(h=>h.distance<.72).sort((a,b)=>a.t-b.t)[0];
 if(hit){const source=s.units.find(u=>u.id===p.source),target=hit.u,c=source.captain,power=Math.min(200,(GUNS[source.gunType]?.strength??1)*Math.max(5,12-Math.ceil((p.travel+step)/2)));
  const damage=Math.min(target.durability,cannonDamage({...source,...c,firepower:power,gunnery:!!(c.skills&4)},n=>random(s,n))),crewLost=Math.min(target.crew,Math.floor(damage/3));target.durability-=damage;target.crew-=crewLost;
  s.effects.push({x:target.x,y:target.y,life:.55,hit:true});events.push({type:'CANNON',source:source.id,target:target.id,damage,crewLost});events.push({type:'BATTLE_EXPERIENCE',captain:c.id,amount:alive(target)?10:10*target.maximumDurability});
 }else if(!navigable(s,nx,ny)||p.travel+step>=p.range){s.effects.push({x:nx,y:ny,life:.35,hit:false});}else{p.x=nx;p.y=ny;p.travel+=step;keep.push(p);}}
 s.projectiles=keep;
}
function npcStep(s,u,dt,events){const targets=s.units.filter(t=>alive(t)&&t.team!==u.team).sort((a,b)=>distance(u,a)-distance(u,b)),t=targets.find(t=>t.id===u.orders?.target)??targets[0];if(!t)return;
 const d=distance(u,t),armed=u.guns>0&&u.shot>0&&!!GUNS[u.gunType]?.range,desired=armed?gunRange(u)*.65:1.35,dx=t.x-u.x,dy=t.y-u.y;u.aim=Math.atan2(dy,dx);
 if(u.orders?.strategy==='flee'){const edges=[{x:.7,y:u.y},{x:s.width-1.7,y:u.y},{x:u.x,y:.7},{x:u.x,y:s.height-1.7}].sort((a,b)=>distance(u,a)-distance(u,b));move(s,u,edges[0].x-u.x,edges[0].y-u.y,dt);if(distance(u,edges[0])<1)u.left=true;return;}
 if(d>desired)move(s,u,dx,dy,dt);else if(armed&&d<desired*.65)move(s,u,-dx,-dy,dt);
 if(armed&&d<=gunRange(u))shoot(s,u,u.aim,events);
 else if(!armed&&d<1.8&&u.boardingReload<=0){u.boardingReload=2.5;const hit=Math.min(t.crew,boardingKills({...u,swordplay:u.captain.swordplay},n=>random(s,n)));t.crew-=hit;events.push({type:'BOARDING',source:u.id,target:t.id,crewLost:hit,counterLost:0});}
}
function step(s,input,events){const dt=BATTLE_STEP;s.elapsed+=dt;s.tick=(s.startTick+Math.floor(s.elapsed/20))%72;
 for(const u of s.units){u.reload=Math.max(0,u.reload-dt);u.boardingReload=Math.max(0,u.boardingReload-dt);u.duelCooldown=Math.max(0,u.duelCooldown-dt);}
 const u=s.units.find(u=>u.id===s.player);move(s,u,input.x??0,input.y??0,dt);
 const target=s.units.find(t=>t.id===s.target&&alive(t));if(Number.isFinite(input.aim)){u.aim=input.aim;s.target=null;}else if(target)u.aim=Math.atan2(target.y-u.y,target.x-u.x);
 if(input.fire)shoot(s,u,u.aim,events);
 for(const other of s.units)if(other.id!==s.player&&alive(other))npcStep(s,other,dt,events);
 projectiles(s,dt,events);s.effects=s.effects.map(e=>({...e,life:e.life-dt})).filter(e=>e.life>0);checkResult(s);
}
export function advanceRealtime(state,dt,input={}){if(!state.realtime||state.phase!=='active')return {state,events:[]};if(!Number.isFinite(dt)||dt<0||dt>1)throw new RangeError('Invalid battle delta');for(const k of ['x','y'])if(input[k]!==undefined&&(!Number.isFinite(input[k])||Math.abs(input[k])>1))throw new RangeError('Invalid battle input');
 const s=structuredClone(state),events=[];s.accumulator+=dt;while(s.accumulator+1e-9>=BATTLE_STEP&&s.phase==='active'){s.accumulator-=BATTLE_STEP;step(s,input,events);}if(events.length)s.revision++;return {state:s,events};
}
export function realtimeCommand(state,c){if(!validateCommand(state,c))return {state,events:[]};const s=structuredClone(state),events=[],u=s.units.find(u=>u.id===s.player);
 if(c.type==='DUEL_RESULT'){if(s.phase!=='duel'||![0,1,null].includes(c.winner)||!Number.isFinite(c.balance))throw new Error('일기토 결과를 확인해 주세요.');const t=s.units.find(u=>u.id===s.pendingDuel.target);s.duelBalance=c.balance;s.pendingDuel=null;if(c.winner===0){if(t.main)finish(s,6);else{t.crew=0;s.phase='active';}}else if(c.winner===1)finish(s,7);else{s.phase='active';u.duelCooldown=5;}}
 else {if(s.phase!=='active')throw new Error('현재는 전투 명령을 내릴 수 없습니다.');switch(c.type){
  case 'FIRE':{if(cannonStatus(u)!=='발사 준비')throw new Error(cannonStatus(u));if(c.angle!==undefined&&!Number.isFinite(c.angle))throw new Error('조준 방향을 확인하세요.');const t=s.units.find(t=>t.id===s.target&&alive(t));shoot(s,u,c.angle??(t?Math.atan2(t.y-u.y,t.x-u.x):u.aim),events);break;}
  case 'TARGET':{const t=s.units.find(t=>t.id===c.target&&alive(t)&&t.team!==u.team);if(!t)throw new Error('적선을 선택하세요.');s.target=t.id;u.aim=Math.atan2(t.y-u.y,t.x-u.x);break;}
  case 'CHALLENGE':{const t=s.units.find(t=>t.id===c.target);if(!alive(t)||t.team===u.team||!t.flagship||distance(u,t)>DUEL_RANGE)throw new Error('적 대장선 가까이 접근하세요.');if(u.duelCooldown>0)throw new Error('잠시 후 다시 신청하세요.');s.pendingDuel={source:u.id,target:t.id,balance:s.lastDuelOpponent===t.id?s.duelBalance:100};s.lastDuelOpponent=t.id;s.duelBalance=s.pendingDuel.balance;s.phase='duel';break;}
  case 'ESCAPE':if(Math.min(u.x,u.y,s.width-1-u.x,s.height-1-u.y)>2.5)throw new Error('전장 가장자리까지 이동하세요.');u.left=true;finish(s,3);break;
  case 'SURRENDER':finish(s,9);break;
  case 'ORDER':{const t=s.units.find(t=>t.id===c.ship&&t.team===u.team&&t.id!==u.id);if(!alive(t)||!['pack','fightBack','flee'].includes(c.orders?.strategy))throw new Error('아군 함선과 전술을 선택하세요.');t.orders=structuredClone(c.orders);break;}
  default:throw new Error('실시간 해전 명령이 아닙니다.');
 }}commitCommand(s,c.id);return {state:s,events};
}
