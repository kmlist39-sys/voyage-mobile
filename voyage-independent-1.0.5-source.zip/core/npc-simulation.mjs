import {npcHome,npcArrive} from './npc-port-actions.mjs';
import {seaDistance} from './npc-navigation.mjs';
const active=(h,f)=>f>=0&&f<70&&(h.get(8,f,41)&1)&&h.get(8,f,42)<120;
const position=(h,f)=>({x:h.get(8,f,0,2),y:h.get(8,f,2,2)});
const flags=(h,f)=>h.get(8,f,41);
export function fleetStrength(h,f){let total=0;for(let i=0;i<10;i++)if((h.get(8,f,51+i*9)&48)===16)total+=h.get(8,f,45+i*9);return Math.floor((total+4)/5);}
function damage(h,f,n){for(let i=9;i>=0&&n>0;i--){const at=43+i*9;if((h.get(8,f,at+8)&48)!==16)continue;const old=h.get(8,f,at+2),d=Math.min(old,n);h.set(8,f,at+2,old-d);n-=d;if(old===d)h.set(8,f,at+8,0);}if(fleetStrength(h,f)===0){const id=h.get(8,f,42);h.set(8,f,41,flags(h,f)&~1);h.set(3,id,44,255);h.set(3,id,45,h.get(8,f,38));h.set(3,id,46,0);if(h.get(3,id,27)&192)h.set(3,id,49,h.get(3,id,49)&~32);}}
export function npcBattle(h,data,a,b,rng){if(!active(h,a)||!active(h,b)||a===h.fleetId()||b===h.fleetId()||(flags(h,a)|flags(h,b))&64)return false;
 if(rng(150)<h.captain(h.get(8,b,42)).seamanship){if(h.get(8,a,27)!==7)npcHome(h,data,a);return false;}
 const sa=fleetStrength(h,a),sb=fleetStrength(h,b);damage(h,a,Math.floor(sb/10));damage(h,b,Math.floor(sa/10));
 for(const [winner,loser] of [[a,b],[b,a]])if(active(h,winner)&&!active(h,loser)){h.set(8,winner,36,Math.min(60000,h.get(8,winner,36,2)+Math.floor(h.get(8,loser,36,2)/5)),2);h.set(8,loser,36,0,2);const cargo=h.get(8,loser,33);if(cargo!==255){h.set(8,winner,33,cargo);h.set(8,winner,34,Math.min(1000,Math.floor(h.get(8,loser,34,2)/5)),2);}}
 const na=Math.floor(a/10),nb=Math.floor(b/10);if(na<6&&nb<6&&na!==nb)for(const [n,m] of [[na,nb],[nb,na]])h.set(0,n,11+m,Math.max(0,h.get(0,n,11+m)-2-rng(2)));
 for(const f of [a,b])if(active(h,f)&&h.get(8,f,27)!==7)npcHome(h,data,f);return true;
}
export function updateNpcFleets(game,rng){const h=game.host,state=game.state,own=h.fleetId(),tick=game.calendar.tick;let plans=0;
 for(let id=0;id<70;id++){
  if(id===own||!active(h,id)||(tick+id)%4||flags(h,id)&16)continue;let order=h.get(8,id,27),target=h.get(8,id,28),goal,targetFleet=-1;const pos=position(h,id),script=!!(flags(h,id)&64);
  if([4,5,6,7,8,10].includes(order)){
   targetFleet=order===4?own:target<120?h.get(3,target,44):-1;
   if(!active(h,targetFleet)||targetFleet===id){if(script)continue;npcHome(h,game.data,id);delete state.npcPaths[id];order=0;target=h.get(8,id,28);}
   else if(!script&&[5,6].includes(order)&&flags(h,targetFleet)&16&&h.get(8,targetFleet,39)>0){npcHome(h,game.data,id);delete state.npcPaths[id];order=0;target=h.get(8,id,28);}
   else goal=position(h,targetFleet);
  }
  if(!goal)goal=game.data.ports[target];if(!goal)continue;
  const separation=seaDistance(pos,goal);
  if(order===8&&separation<7)continue;
  if([3,9].includes(order)&&separation<6){
   const hostile=Array.from({length:70},(_,i)=>i).find(f=>active(h,f)&&f!==id&&!(flags(h,f)&16)&&Math.floor(f/10)!==Math.floor(id/10)&&seaDistance(pos,position(h,f))<10&&(Math.floor(f/10)===6||h.get(0,Math.floor(id/10),11+Math.floor(f/10))<30));
   if(hostile!==undefined){h.set(8,id,27,5);h.set(8,id,28,h.get(8,hostile,42));delete state.npcPaths[id];}continue;
  }
  if([4,5,6,7].includes(order)&&separation<4&&!(flags(h,targetFleet)&16)){
   if(targetFleet===own){if(state.mode==='sea'&&state.sea.cooldown===0&&!state.wait&&!state.spoils){game.encounter(id);return;}}
   else if(tick>=18&&tick<=53)npcBattle(h,game.data,id,targetFleet,rng);continue;
  }
  let plan=state.npcPaths[id];if(plan&&(!Number.isInteger(plan.index)||plan.order!==order||plan.target!==target||seaDistance({x:plan.goalX,y:plan.goalY},goal)>8))plan=null;
  if(plan&&!plan.route.length&&plan.retry!==tick)continue;if(!plan||plan.index>=plan.route.length){if(plans>=1)continue;plans++;const route=game.navigator.route(pos,goal);plan=state.npcPaths[id]={order,target,goalX:goal.x,goalY:goal.y,index:0,route:route??[],retry:tick};if(!route?.length){if([0,1,2].includes(order)&&separation<8)npcArrive(h,id,rng);continue;}}
  const next=plan.route[plan.index++];if(next){h.set(8,id,0,next.x,2);h.set(8,id,2,next.y,2);h.set(8,id,26,next.heading<0?8:next.heading);}
  if(plan.index>=plan.route.length&&[0,1,2].includes(order))npcArrive(h,id,rng);
 }
}
export function dailySailors(h,data,rng){
 for(let id=6;id<120;id++){if(!(h.get(3,id,49)&32)||h.get(3,id,44)!==255||h.get(3,id,46)!==0||h.mates().includes(id))continue;const p=h.get(3,id,45);if(p>=100||rng(30)!==0)continue;const nearby=data.ports.slice(0,100).filter(n=>n.id!==p&&n.id<42===(p<42)&&seaDistance(n,data.ports[p])<220);if(nearby.length)h.set(3,id,45,nearby[rng(nearby.length)].id);}
}
