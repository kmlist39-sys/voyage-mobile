import {contours} from './terrain-geometry.mjs';
import {alive,gunRange} from './core/realtime-battle.mjs';
export function drawRealtime(p,game){const b=game.state.battle,g=p.ctx,u=b.units.find(n=>n.id===b.player),size=Math.min(32,p.w/16),sy=size*.8,ox=p.w/2-u.x*size,oy=p.h*.5-u.y*sy;p.view={mode:'battle',ox,oy,sx:size,sy};p.landscape.water(g,p.w,p.h,ox,oy,size,sy,p.time);
 if(p.arenaId!==b.arenaId){p.arenaId=b.arenaId;const c=document.createElement('canvas');c.width=b.width*12;c.height=b.height*12;const ctx=c.getContext('2d'),loops=contours((x,y)=>!!b.terrain[y*b.width+x],0,0,b.width,b.height);p.landscape.shore(ctx,loops,12,0,0,'#788363');p.arena=c;}if(p.arena)g.drawImage(p.arena,ox,oy,b.width*size,b.height*sy);
 g.save();g.strokeStyle='#d6c99a77';g.lineWidth=1;g.setLineDash([4,7]);g.strokeRect(ox+.5*size,oy+.5*sy,(b.width-2)*size,(b.height-2)*sy);g.restore();
 const px=ox+u.x*size,py=oy+u.y*sy,range=gunRange(u);g.save();g.strokeStyle=u.shot?'#f4d598b0':'#bbb8aa80';g.setLineDash([5,6]);g.lineWidth=1.5;g.beginPath();g.moveTo(px,py);g.lineTo(px+Math.cos(u.aim)*range*size,py+Math.sin(u.aim)*range*sy);g.stroke();g.restore();
 const labels=[];for(const unit of b.units.filter(alive).sort((a,c)=>a.y-c.y)){const x=ox+unit.x*size,y=oy+unit.y*sy,width=Math.max(32,size*2),enemy=unit.team!==u.team,isTarget=unit.id===b.target;
  if(x<18||x>p.w-18||y<100||y>p.h-115){if(enemy&&unit.flagship){const xx=Math.max(60,Math.min(p.w-60,x)),yy=Math.max(120,Math.min(p.h-135,y));labels.push({x:xx,y:yy,text:'⚑ 적 대장선 '+(x<0?'◀':x>p.w?'▶':y<100?'▲':'▼'),enemy:true});p.hits.push({kind:'battle-unit',id:unit.id,x:xx-55,y:yy-22,w:110,h:44});}continue;}
  if(isTarget||unit.flagship){g.strokeStyle=enemy?'#ffad87':'#e9e2a2';g.lineWidth=isTarget?2.5:1.5;g.beginPath();g.ellipse(x,y+4,width*.54,width*.25,0,0,Math.PI*2);g.stroke();}
  const heading=(Math.round((unit.angle+Math.PI/2)/(Math.PI/4))%8+8)%8;p.drawShip(x,y,heading,width);
  g.fillStyle='#0c2029';g.fillRect(x-width*.4,y+8,width*.8,5);g.fillStyle=enemy?'#ef9977':'#9ccfae';g.fillRect(x-width*.4,y+8,width*.8*Math.min(1,unit.durability/unit.maximumDurability),5);
  labels.push({x,y:y+27,text:unit.flagship?(enemy?'⚑ 적 대장선':'⚑ 내 대장선')+' · '+unit.crew+'명':unit.crew+'명',enemy});p.hits.push({kind:'battle-unit',id:unit.id,x:x-Math.max(22,width*.5),y:y-width*.8,w:Math.max(44,width),h:width+28});
 }
 for(const shot of b.projectiles){const x=ox+shot.x*size,y=oy+shot.y*sy;g.strokeStyle='#ffdd9a';g.lineWidth=2;g.beginPath();g.moveTo(x-shot.dx*size*.35,y-shot.dy*sy*.35);g.lineTo(x,y);g.stroke();g.fillStyle='#fff0bd';g.beginPath();g.arc(x,y,3,0,Math.PI*2);g.fill();}
 for(const e of b.effects){const x=ox+e.x*size,y=oy+e.y*sy,r=(1-e.life+.1)*size*.8;g.save();g.globalAlpha=Math.min(1,e.life*2);g.fillStyle=e.hit?'#ffc26b':'#c7e4df';g.beginPath();g.ellipse(x,y,r,r*.7,0,0,Math.PI*2);g.fill();g.restore();}
 g.font='600 11px system-ui';g.textAlign='center';const placed=[];for(const l of labels){const w=g.measureText(l.text).width+12;const lx=Math.max(w/2+4,Math.min(p.w-w/2-4,l.x));let ly=l.y;for(const offset of [0,22,-22,44,-44,66,-66]){const y=l.y+offset;if(y<115||y>p.h-110)continue;if(!placed.some(r=>lx-w/2<r.x+r.w&&lx+w/2>r.x&&y-13<r.y+20&&y+7>r.y)){ly=y;break;}}placed.push({x:lx-w/2,y:ly-13,w});g.fillStyle='#10272df2';g.beginPath();g.roundRect(lx-w/2,ly-13,w,20,4);g.fill();g.fillStyle=l.enemy?'#ffcfaf':'#fff1c3';g.fillText(l.text,lx,ly+1);}
}



