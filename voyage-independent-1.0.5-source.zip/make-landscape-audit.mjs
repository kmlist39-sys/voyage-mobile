import fs from 'node:fs';import './make-screen-audit.mjs';
const root=import.meta.dirname;
const extra=`
qa.addEventListener('click',()=>document.getElementById('landscape-result')?.remove());
qa.append(button('조작 재개',()=>{paused=false;status.textContent='실제 입력으로 조작 중';}));
qa.append(button('항해 풍경',()=>{readyGame();closeModal();for(const s of game.ships)game.host.writeShip({...s,crew:20,navigationPercent:100,food:400,water:400});game.departed();game.state.wait=null;dirty=true;painter.view=null;render();paused=true;status.textContent='항해 풍경 · '+portPick.selectedOptions[0].textContent;}));
qa.append(button('풍경 전체 검사',async()=>{const results={towns:0,ports:0,errors:[],townRenderMs:[],seaRenderMs:[],chunkCacheLimit:16};const started=performance.now();
 for(let id=0;id<101;id++){const t=performance.now(),c=painter.townGround(id);if(c.width!==2304||c.height!==2304)results.errors.push('ground-size:'+id);results.townRenderMs.push(performance.now()-t);results.towns++;if(id%4===0){status.textContent='지면 '+id;await new Promise(r=>setTimeout(r,0));}}
 for(const p of data.ports){const t=performance.now();for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++)painter.landscape.seaChunk(data.world,Math.floor(p.x/16)+x,Math.floor(p.y/16)+y);if(painter.landscape.chunks.size>16)results.errors.push('cache-limit');results.seaRenderMs.push(performance.now()-t);results.ports++;await new Promise(r=>setTimeout(r,0));}
 results.durationMs=performance.now()-started;results.maxTownMs=Math.max(...results.townRenderMs);results.maxSeaAreaMs=Math.max(...results.seaRenderMs);delete results.townRenderMs;delete results.seaRenderMs;const pre=node('pre','',JSON.stringify(results,null,2));pre.id='landscape-result';pre.style.cssText='position:fixed;inset:70px 20px 70px;background:#132d31;padding:16px;overflow:auto;z-index:9999;font-size:12px';document.getElementById('landscape-result')?.remove();document.body.append(pre);status.textContent='풍경 검사 완료';
}));
qa.append(button('풍경 성능 검사',async()=>{readyGame();closeModal();for(const s of game.ships)game.host.writeShip({...s,crew:20,navigationPercent:100,food:400,water:400});game.departed();game.state.wait=null;paused=true;render();painter.view=null;painter.frame(game,1000,.016);const samples=[];for(let i=0;i<120;i++){const start=performance.now();painter.frame(game,1000+i*16,.016);samples.push(performance.now()-start);if(i%10===0)await new Promise(r=>setTimeout(r,0));}samples.sort((a,b)=>a-b);const pre=node('pre','',JSON.stringify({frames:120,viewport:[innerWidth,innerHeight],p95Ms:samples[114],maxMs:samples.at(-1),cacheEntries:painter.landscape.chunks.size},null,2));pre.id='landscape-result';pre.style.cssText='position:fixed;inset:70px 20px 70px;background:#132d31;padding:16px;overflow:auto;z-index:9999;font-size:12px';document.body.append(pre);}));
`;
fs.appendFileSync(root+'/qa/audit-app.mjs',extra);
console.log('Landscape fixtures available in audit toolbar.');
